import React, { useState } from 'react';
import { ScreenId } from '../../types';
import { Sparkles, X, ArrowRight, Layers, Search, LayoutGrid, Stethoscope, FileText, Building2 } from 'lucide-react';

interface AllScreensModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeScreen: ScreenId;
  setActiveScreen: (screen: ScreenId) => void;
}

const SCREENS: {
  id: ScreenId;
  num: number;
  title: string;
  subtitle: string;
  iconBg: string;
  tag: string;
  category: 'Patient Care' | 'Medical Records & AI' | 'Hospital Operations';
}[] = [
  {
    id: 'welcome',
    num: 1,
    title: 'Welcome Screen',
    subtitle: 'Healthcare illustration, AI Mascot, Slogan, Login & Account',
    iconBg: 'from-blue-600 to-cyan-500',
    tag: 'Intro',
    category: 'Patient Care'
  },
  {
    id: 'healthCheck',
    num: 2,
    title: 'AI Health Check',
    subtitle: 'Text/Voice Symptom Checker, Priority Levels & AI Confidence',
    iconBg: 'from-cyan-500 to-teal-400',
    tag: 'AI Triage',
    category: 'Patient Care'
  },
  {
    id: 'dashboard',
    num: 3,
    title: 'Smart Dashboard',
    subtitle: 'AI Health Score, Live Queue position, Medication & Vitals',
    iconBg: 'from-indigo-600 to-blue-500',
    tag: 'Overview',
    category: 'Patient Care'
  },
  {
    id: 'booking',
    num: 4,
    title: 'Smart Appointment Booking',
    subtitle: 'AI Doctor Recommendations, Slot Picker & Fee details',
    iconBg: 'from-blue-500 to-indigo-600',
    tag: 'Booking',
    category: 'Patient Care'
  },
  {
    id: 'queueTracker',
    num: 5,
    title: 'Live Queue Tracker',
    subtitle: 'Interactive timeline, Patients ahead, Delay prediction',
    iconBg: 'from-teal-500 to-emerald-400',
    tag: 'Live Queue',
    category: 'Patient Care'
  },
  {
    id: 'wallet',
    num: 6,
    title: 'Digital Health Wallet',
    subtitle: 'Medical records, Consultation summaries, Prescriptions & QR Check-in',
    iconBg: 'from-purple-600 to-indigo-500',
    tag: 'Records',
    category: 'Medical Records & AI'
  },
  {
    id: 'aiAssistant',
    num: 7,
    title: 'AI Health Assistant',
    subtitle: 'Voice & text AI Chatbot, Prescriptions & Diet guidance',
    iconBg: 'from-cyan-400 to-blue-600',
    tag: 'AI Chat',
    category: 'Medical Records & AI'
  },
  {
    id: 'analytics',
    num: 8,
    title: 'Hospital Analytics',
    subtitle: 'Patient volume, Waiting times, Doctor utilization & AI charts',
    iconBg: 'from-indigo-500 to-cyan-500',
    tag: 'Analytics',
    category: 'Hospital Operations'
  },
  {
    id: 'profile',
    num: 9,
    title: 'Profile & Settings',
    subtitle: 'Personal profile, Wearables sync, Voice settings & Privacy',
    iconBg: 'from-slate-600 to-slate-800',
    tag: 'Settings',
    category: 'Medical Records & AI'
  },
];

export const AllScreensModal: React.FC<AllScreensModalProps> = ({
  isOpen,
  onClose,
  activeScreen,
  setActiveScreen,
}) => {
  const [modalCategory, setModalCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  if (!isOpen) return null;

  const filteredScreens = SCREENS.filter((s) => {
    const matchesCategory = modalCategory === 'All' || s.category === modalCategory;
    const query = searchQuery.toLowerCase();
    const matchesQuery = !query || 
      s.title.toLowerCase().includes(query) ||
      s.subtitle.toLowerCase().includes(query) ||
      s.tag.toLowerCase().includes(query);
    return matchesCategory && matchesQuery;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xl animate-fade-in">
      <div className="relative w-full max-w-2xl max-h-[85vh] bg-slate-900 border border-cyan-500/30 rounded-3xl p-5 sm:p-6 text-white shadow-2xl shadow-cyan-950/80 flex flex-col overflow-hidden">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-white tracking-tight flex items-center gap-2">
                All 9 Application Screens
                <Sparkles className="w-4 h-4 text-cyan-400" />
              </h2>
              <p className="text-xs text-slate-400">
                MediFlow AI – Smart Hospital Assistant (2026 Edition)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Navigation Tabs & Search */}
        <div className="py-3 space-y-2 border-b border-slate-800">
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar text-xs">
            {[
              { id: 'All', label: 'All Screens (9)', icon: LayoutGrid },
              { id: 'Patient Care', label: 'Patient Care', icon: Stethoscope },
              { id: 'Medical Records & AI', label: 'Records & AI', icon: FileText },
              { id: 'Hospital Operations', label: 'Hospital Ops', icon: Building2 },
            ].map((tab) => {
              const TabIcon = tab.icon;
              const isCatActive = modalCategory === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setModalCategory(tab.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition-all ${
                    isCatActive
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-md shadow-cyan-500/20'
                      : 'bg-slate-800/80 text-slate-400 border border-slate-700/60 hover:text-white'
                  }`}
                >
                  <TabIcon className="w-3.5 h-3.5" />
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search screen title, feature or tag..."
              className="w-full pl-9 pr-4 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400 transition-all"
            />
          </div>
        </div>

        {/* Screens Grid */}
        <div className="flex-1 overflow-y-auto py-3 pr-1 space-y-2.5">
          {filteredScreens.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs">
              No screens matched your search or category filter.
            </div>
          ) : (
            filteredScreens.map((s) => {
              const isSelected = activeScreen === s.id;
              return (
                <button
                  key={s.id}
                  onClick={() => {
                    setActiveScreen(s.id);
                    onClose();
                  }}
                  className={`w-full p-3.5 rounded-2xl border text-left transition-all duration-200 flex items-center justify-between group ${
                    isSelected
                      ? 'bg-gradient-to-r from-cyan-950/80 to-slate-900 border-cyan-400 shadow-lg shadow-cyan-500/20'
                      : 'bg-slate-800/60 border-slate-700/60 hover:border-cyan-500/40 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-3.5">
                    <div
                      className={`w-10 h-10 rounded-xl bg-gradient-to-br ${s.iconBg} flex items-center justify-center text-white font-extrabold text-sm shadow-md shrink-0`}
                    >
                      {s.num}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                          {s.title}
                        </h3>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800 text-cyan-300 border border-cyan-500/20">
                          {s.tag}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">
                        {s.subtitle}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {isSelected && (
                      <span className="text-[11px] font-bold text-cyan-400 px-2 py-0.5 rounded-md bg-cyan-500/10 border border-cyan-500/30">
                        Active
                      </span>
                    )}
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 group-hover:translate-x-1 transition-all" />
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 text-center text-xs text-slate-400 flex justify-between items-center">
          <span>Tip: Tap any screen card to jump instantly</span>
          <span className="font-mono text-[10px] text-cyan-400">{filteredScreens.length} of 10 screens shown</span>
        </div>

      </div>
    </div>
  );
};

