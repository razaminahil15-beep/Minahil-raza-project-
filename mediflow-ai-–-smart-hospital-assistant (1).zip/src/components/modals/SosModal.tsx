import React, { useState } from 'react';
import { ShieldAlert, Ambulance, Phone, CheckCircle2, X } from 'lucide-react';

interface SosModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SosModal: React.FC<SosModalProps> = ({ isOpen, onClose }) => {
  const [dispatched, setDispatched] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md bg-slate-900 border border-rose-500/40 rounded-2xl p-6 text-white shadow-2xl shadow-rose-900/50">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700"
        >
          <X className="w-5 h-5" />
        </button>

        {!dispatched ? (
          <div className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-rose-500/20 border-2 border-rose-500 flex items-center justify-center animate-pulse">
              <ShieldAlert className="w-8 h-8 text-rose-500" />
            </div>

            <h2 className="text-xl font-black text-rose-400 tracking-tight">
              EMERGENCY SOS DISPATCH
            </h2>
            <p className="text-xs text-slate-300 mt-2">
              Triggering SOS immediately notifies MediFlow Hospital Emergency Response Team, dispatches autonomous ambulance, and overrides triage queue priority.
            </p>

            <div className="my-5 p-3 rounded-xl bg-rose-950/50 border border-rose-500/30 text-left text-xs space-y-1.5 text-slate-200">
              <div className="flex justify-between">
                <span className="text-slate-400">Target Hospital:</span>
                <span className="font-semibold text-rose-300">MediFlow North Emergency Wing</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">GPS Telemetry:</span>
                <span className="font-mono text-cyan-300">Lat 37.7749, Long -122.4194</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">AI Priority:</span>
                <span className="font-extrabold text-rose-400">CRITICAL LEVEL 1</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={onClose}
                className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition-all"
              >
                Cancel
              </button>
              <button
                onClick={() => setDispatched(true)}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-xs shadow-lg shadow-rose-600/40 border border-rose-400/50 flex items-center justify-center gap-2 transition-all transform hover:scale-105"
              >
                <Ambulance className="w-4 h-4" />
                DISPATCH AMBULANCE
              </button>
            </div>
          </div>
        ) : (
          <div className="text-center py-4">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-emerald-500/20 border-2 border-emerald-500 flex items-center justify-center">
              <CheckCircle2 className="w-9 h-9 text-emerald-400" />
            </div>

            <h2 className="text-xl font-bold text-emerald-400">
              Ambulance En Route!
            </h2>
            <p className="text-xs text-slate-300 mt-2">
              Unit <span className="font-mono text-cyan-300 font-bold">#MED-AMB-09</span> dispatched. ETA: <span className="font-extrabold text-amber-400">3 minutes</span>.
            </p>

            <div className="my-5 p-4 rounded-xl bg-slate-800/80 border border-emerald-500/30 text-xs space-y-2 text-left">
              <p className="text-emerald-300 font-semibold">
                ✓ Priority Queue Position: #1 Override Active
              </p>
              <p className="text-slate-300">
                ✓ Dr. Elena Rostova notified & Trauma Bay 2 prepared.
              </p>
            </div>

            <div className="flex gap-2">
              <a
                href="tel:911"
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold text-xs flex items-center justify-center gap-1.5"
              >
                <Phone className="w-4 h-4" /> Call ER Line
              </a>
              <button
                onClick={() => {
                  setDispatched(false);
                  onClose();
                }}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
              >
                Done
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
