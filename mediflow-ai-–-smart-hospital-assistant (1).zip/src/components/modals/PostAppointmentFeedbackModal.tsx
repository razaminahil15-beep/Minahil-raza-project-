import React, { useState } from 'react';
import { Appointment, DoctorFeedback } from '../../types';
import { saveDoctorFeedbackToFirestore } from '../../services/firestoreService';
import { notificationService } from '../../services/notificationService';
import { Star, X, Check, HeartHandshake, Sparkles, Building, Clock, ThumbsUp, MessageSquare, ShieldCheck, Award } from 'lucide-react';

interface PostAppointmentFeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointment: Appointment;
  onFeedbackSubmitted?: (updatedAppointment: Appointment) => void;
}

const FEEDBACK_TAG_OPTIONS = [
  'Punctual & On-Time',
  'Empathetic & Caring',
  'Clear Diagnosis',
  'Listened Carefully',
  'Clean & Safe Facility',
  'Gentle Examination',
  'Helpful AI Pre-Check',
  'Detailed Prescription',
];

export const PostAppointmentFeedbackModal: React.FC<PostAppointmentFeedbackModalProps> = ({
  isOpen,
  onClose,
  appointment,
  onFeedbackSubmitted,
}) => {
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [facilityRating, setFacilityRating] = useState<number>(5);
  const [hoverFacilityRating, setHoverFacilityRating] = useState<number>(0);
  const [waitTimeRating, setWaitTimeRating] = useState<string>('Just as expected');
  const [selectedTags, setSelectedTags] = useState<string[]>([
    'Punctual & On-Time',
    'Empathetic & Caring',
    'Clear Diagnosis',
  ]);
  const [feedbackText, setFeedbackText] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);

  if (!isOpen) return null;

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const getRatingLabel = (stars: number) => {
    switch (stars) {
      case 1:
        return 'Needs Improvement';
      case 2:
        return 'Fair Experience';
      case 3:
        return 'Good & Satisfactory';
      case 4:
        return 'Very Good Care';
      case 5:
        return 'Exceptional Care & Treatment!';
      default:
        return 'Select a rating';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const feedbackObj: DoctorFeedback = {
      appointmentId: appointment.id,
      doctorName: appointment.doctorName,
      doctorSpecialty: appointment.doctorSpecialty,
      hospitalName: appointment.hospitalName,
      rating,
      facilityRating,
      waitTimeRating,
      feedbackText: feedbackText.trim() || 'Great consultation with Dr. ' + appointment.doctorName,
      tags: selectedTags,
      submittedAt: new Date().toISOString(),
    };

    // Save to Firestore
    await saveDoctorFeedbackToFirestore(feedbackObj);

    // Update appointment object
    const updatedApt: Appointment = {
      ...appointment,
      status: 'Completed',
      rating,
      facilityRating,
      waitTimeRating,
      feedbackText: feedbackText.trim(),
      feedbackTags: selectedTags,
      feedbackSubmitted: true,
      ratedAt: new Date().toISOString(),
    };

    if (onFeedbackSubmitted) {
      onFeedbackSubmitted(updatedApt);
    }

    // Trigger push notification
    notificationService.addNotification({
      title: 'Feedback Received',
      message: `Thank you! Your ${rating}-star review for ${appointment.doctorName} has been recorded.`,
      type: 'system',
      priority: 'low',
      metadata: {
        doctorName: appointment.doctorName,
      },
    });

    setIsSubmitting(false);
    setIsSuccess(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-900 border border-cyan-500/30 rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-cyan-950/40 to-slate-900 border-b border-cyan-500/20 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-400 p-0.5 shadow-lg shadow-amber-500/30 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <Star className="w-5 h-5 text-amber-400 fill-amber-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-widest text-amber-400">
                <Sparkles className="w-3 h-3 text-amber-300" /> Post-Appointment Review
              </div>
              <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                Rate Consultation Experience
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 space-y-5 overflow-y-auto custom-scrollbar flex-1">
          {isSuccess ? (
            /* Success View */
            <div className="py-8 px-4 text-center space-y-4 animate-scaleUp">
              <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 p-1 shadow-2xl shadow-emerald-500/40 flex items-center justify-center">
                <div className="w-full h-full bg-slate-950 rounded-full flex items-center justify-center">
                  <Check className="w-10 h-10 text-emerald-400 stroke-[3]" />
                </div>
              </div>

              <div className="space-y-1">
                <span className="inline-block px-3 py-1 rounded-full text-xs font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Rating Submitted Successfully
                </span>
                <h3 className="text-xl font-black text-white">Thank You for Your Feedback!</h3>
                <p className="text-xs text-slate-300 max-w-sm mx-auto leading-relaxed">
                  Your rating and detailed feedback for <strong className="text-cyan-300">{appointment.doctorName}</strong> has been saved. Your inputs help us continuously enhance patient care quality.
                </p>
              </div>

              {/* Rating Card Summary */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-emerald-500/30 text-left space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Doctor Rating:</span>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-4 h-4 ${
                          star <= rating ? 'text-amber-400 fill-amber-400' : 'text-slate-700'
                        }`}
                      />
                    ))}
                    <span className="text-xs font-bold text-amber-400 ml-1">({rating}/5)</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Facility Rating:</span>
                  <span className="font-bold text-emerald-300">{facilityRating} / 5 Stars</span>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Wait Time Satisfaction:</span>
                  <span className="font-bold text-cyan-300">{waitTimeRating}</span>
                </div>

                {selectedTags.length > 0 && (
                  <div className="pt-1 flex flex-wrap gap-1">
                    {selectedTags.map((tag) => (
                      <span key={tag} className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                        ✓ {tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <button
                onClick={onClose}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/30 transition-all transform hover:scale-[1.02] active:scale-98"
              >
                Return to Dashboard
              </button>
            </div>
          ) : (
            /* Rating Form */
            <form onSubmit={handleSubmit} className="space-y-5">
              
              {/* Doctor Info Card */}
              <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-cyan-500/30 flex items-center gap-3">
                <img
                  src={appointment.doctorAvatar}
                  alt={appointment.doctorName}
                  className="w-12 h-12 rounded-xl object-cover border border-cyan-400/40 shadow-md shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-extrabold text-white truncate">{appointment.doctorName}</h3>
                    <span className="px-2 py-0.5 rounded-md text-[9px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shrink-0">
                      Completed
                    </span>
                  </div>
                  <p className="text-xs text-cyan-400 font-medium truncate">{appointment.doctorSpecialty}</p>
                  <p className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5 truncate">
                    <Building className="w-3 h-3 text-slate-500 shrink-0" /> {appointment.hospitalName}
                  </p>
                </div>
              </div>

              {/* 1. Primary Doctor Care Rating (5-Stars) */}
              <div className="space-y-2 text-center p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
                <label className="block text-xs font-black uppercase tracking-wider text-slate-300">
                  How would you rate Dr. {appointment.doctorName.split(',')[0]}?
                </label>

                <div className="flex items-center justify-center gap-2 py-2">
                  {[1, 2, 3, 4, 5].map((star) => {
                    const active = star <= (hoverRating || rating);
                    return (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(0)}
                        className="p-1 transition-all transform hover:scale-125 focus:outline-none"
                        title={`${star} Stars`}
                      >
                        <Star
                          className={`w-7 h-7 sm:w-8 sm:h-8 transition-colors ${
                            active
                              ? 'text-amber-400 fill-amber-400 filter drop-shadow-[0_0_8px_rgba(251,191,36,0.6)]'
                              : 'text-slate-700 hover:text-amber-400/60'
                          }`}
                        />
                      </button>
                    );
                  })}
                </div>

                <div className="text-xs font-bold text-amber-400 tracking-tight">
                  {getRatingLabel(hoverRating || rating)}
                </div>
              </div>

              {/* 2. Facility & Wait Time Ratings Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Hospital Cleanliness Rating */}
                <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-1.5">
                  <label className="block text-[11px] font-bold text-slate-300 flex items-center justify-between">
                    <span>Clinic & Staff Cleanliness</span>
                    <span className="text-emerald-400 font-extrabold">{hoverFacilityRating || facilityRating}/5</span>
                  </label>
                  <div className="flex items-center justify-between px-1 py-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setFacilityRating(star)}
                        onMouseEnter={() => setHoverFacilityRating(star)}
                        onMouseLeave={() => setHoverFacilityRating(0)}
                        className="p-0.5 focus:outline-none"
                      >
                        <Star
                          className={`w-4 h-4 ${
                            star <= (hoverFacilityRating || facilityRating)
                              ? 'text-emerald-400 fill-emerald-400'
                              : 'text-slate-700'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Wait Time Experience */}
                <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-1.5">
                  <label className="block text-[11px] font-bold text-slate-300 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-cyan-400" /> Wait Time Satisfaction
                  </label>
                  <select
                    value={waitTimeRating}
                    onChange={(e) => setWaitTimeRating(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 text-xs text-cyan-300 font-semibold rounded-xl p-2 focus:border-cyan-400 focus:outline-none"
                  >
                    <option value="Shorter than expected">⚡ Shorter than expected</option>
                    <option value="Just as expected">✅ Just as expected</option>
                    <option value="Slightly delayed">⏳ Slightly delayed</option>
                    <option value="Too long wait time">⚠️ Longer wait time</option>
                  </select>
                </div>
              </div>

              {/* 3. Quick Highlight Tags */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <ThumbsUp className="w-3.5 h-3.5 text-cyan-400" /> What stood out during your visit?
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {FEEDBACK_TAG_OPTIONS.map((tag) => {
                    const isSelected = selectedTags.includes(tag);
                    return (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => toggleTag(tag)}
                        className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all border ${
                          isSelected
                            ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/60 shadow-md shadow-cyan-500/20'
                            : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200'
                        }`}
                      >
                        {isSelected ? '✓ ' : '+ '}
                        {tag}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 4. Written Feedback Comments */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-cyan-400" /> Detailed Written Review (Optional)
                </label>
                <textarea
                  value={feedbackText}
                  onChange={(e) => setFeedbackText(e.target.value)}
                  placeholder={`Write your thoughts on Dr. ${appointment.doctorName}'s care, treatment advice, or clinic service...`}
                  rows={3}
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-2xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all resize-none"
                />
              </div>

              {/* Modal Action Footer */}
              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-all"
                >
                  Remind Later
                </button>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/30 flex items-center justify-center gap-2 transition-all transform hover:scale-[1.02] active:scale-98 disabled:opacity-50"
                >
                  <Star className="w-4 h-4 fill-slate-950" />
                  {isSubmitting ? 'Saving Review...' : 'Submit Doctor Review'}
                </button>
              </div>

            </form>
          )}
        </div>

      </div>
    </div>
  );
};
