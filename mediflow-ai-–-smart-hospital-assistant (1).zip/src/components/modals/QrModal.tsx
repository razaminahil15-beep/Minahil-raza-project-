import React, { useState } from 'react';
import { QrCode, Sparkles, Check, X, ShieldCheck } from 'lucide-react';

interface QrModalProps {
  isOpen: boolean;
  onClose: () => void;
  tokenNumber?: string;
  doctorName?: string;
  department?: string;
}

export const QrModal: React.FC<QrModalProps> = ({
  isOpen,
  onClose,
  tokenNumber = 'A-104',
  doctorName = 'Dr. Sarah Vance',
  department = 'Cardiology',
}) => {
  const [scanned, setScanned] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-sm bg-slate-900 border border-cyan-500/40 rounded-3xl p-6 text-white shadow-2xl shadow-cyan-900/50 text-center">
        
        {/* Close Button */}
        <button
          onClick={() => {
            setScanned(false);
            onClose();
          }}
          className="absolute top-4 right-4 p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center justify-center gap-2 mb-2 text-cyan-400 font-bold text-xs uppercase tracking-wider">
          <Sparkles className="w-4 h-4" />
          MediFlow Hospital Fast-Check-In
        </div>

        <h2 className="text-xl font-extrabold text-white">
          Digital Check-In QR
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Scan at any MediFlow Smart Kiosk or Gate to bypass the reception desk.
        </p>

        {/* Holographic QR Code Box */}
        <div className="my-6 p-5 rounded-2xl bg-slate-950 border-2 border-cyan-500/50 shadow-inner relative group overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/10 via-blue-500/10 to-transparent pointer-events-none" />
          
          {/* Animated Hologram Scan Line */}
          {!scanned && (
            <div className="absolute top-0 left-0 right-0 h-1 bg-cyan-400 shadow-[0_0_15px_#00F2FE] animate-[bounce_2s_infinite]" />
          )}

          {/* Canvas SVG QR Code Graphic */}
          <div className="w-44 h-44 mx-auto bg-white p-3 rounded-xl flex items-center justify-center shadow-lg">
            <div className="grid grid-cols-5 gap-1.5 w-full h-full p-1 bg-slate-900 rounded">
              {Array.from({ length: 25 }).map((_, i) => (
                <div
                  key={i}
                  className={`rounded-sm transition-colors ${
                    (i * 7) % 3 === 0 || i === 0 || i === 4 || i === 20 || i === 24
                      ? 'bg-cyan-400 shadow-sm shadow-cyan-400'
                      : i % 2 === 0
                      ? 'bg-blue-600'
                      : 'bg-slate-800'
                  }`}
                />
              ))}
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between text-xs px-2">
            <span className="text-slate-400 font-medium">Token ID:</span>
            <span className="font-mono text-cyan-300 font-bold text-sm tracking-widest">{tokenNumber}</span>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-left mb-5 space-y-1">
          <p className="text-slate-300"><span className="text-slate-400">Doctor:</span> <strong className="text-white">{doctorName}</strong></p>
          <p className="text-slate-300"><span className="text-slate-400">Department:</span> <strong className="text-cyan-300">{department}</strong></p>
          <p className="text-slate-300 flex items-center gap-1 mt-1 text-[11px] text-emerald-400">
            <ShieldCheck className="w-3.5 h-3.5" /> Biometrically Encrypted Pass
          </p>
        </div>

        {!scanned ? (
          <button
            onClick={() => setScanned(true)}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs tracking-wider uppercase shadow-lg shadow-cyan-500/30 flex items-center justify-center gap-2 transition-all transform hover:scale-[1.02]"
          >
            <QrCode className="w-4 h-4" /> Simulate Kiosk Scanner Tap
          </button>
        ) : (
          <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-center gap-2 animate-bounce">
            <Check className="w-4 h-4 text-emerald-400" />
            Check-In Confirmed! Queue Position #3 Active.
          </div>
        )}

      </div>
    </div>
  );
};
