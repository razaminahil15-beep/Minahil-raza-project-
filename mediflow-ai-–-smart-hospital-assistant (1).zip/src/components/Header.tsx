import React from 'react';
import { ScreenId } from '../types';
import { Activity, Smartphone, Monitor, ShieldAlert, Sparkles, ChevronDown, ChevronLeft, ChevronRight, Moon, Sun, User, LogOut, LogIn, Bell } from 'lucide-react';

interface HeaderProps {
  activeScreen: ScreenId;
  setActiveScreen: (screen: ScreenId) => void;
  isMobileFrame: boolean;
  setIsMobileFrame: (val: boolean) => void;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
  onOpenSos: () => void;
  onOpenNotifications?: () => void;
  unreadNotificationsCount?: number;
  currentUser: any;
  onOpenAuth: () => void;
  onSignOut: () => void;
}

export const SEQUENTIAL_SCREENS: ScreenId[] = [
  'welcome',          // Screen 1
  'healthCheck',      // Screen 2
  'dashboard',        // Screen 3
  'booking',          // Screen 4
  'queueTracker',     // Screen 5
  'wallet',           // Screen 6
  'aiAssistant',      // Screen 7
  'analytics',        // Screen 8
  'profile',          // Screen 9
];

const SCREENS_GROUPS = [
  {
    label: 'Patient Care & Triage (Screens 1–5)',
    screens: [
      { id: 'welcome', title: 'Screen 1: Welcome' },
      { id: 'healthCheck', title: 'Screen 2: AI Health Check' },
      { id: 'dashboard', title: 'Screen 3: Smart Dashboard' },
      { id: 'booking', title: 'Screen 4: Smart Booking' },
      { id: 'queueTracker', title: 'Screen 5: Live Queue Tracker' },
    ]
  },
  {
    label: 'Medical Records & AI Assistant (Screens 6–7)',
    screens: [
      { id: 'wallet', title: 'Screen 6: Digital Medical History' },
      { id: 'aiAssistant', title: 'Screen 7: AI Health Assistant' },
    ]
  },
  {
    label: 'Hospital Ops & Settings (Screens 8–9)',
    screens: [
      { id: 'analytics', title: 'Screen 8: Hospital Analytics' },
      { id: 'profile', title: 'Screen 9: Profile & Settings' },
    ]
  }
];

export const Header: React.FC<HeaderProps> = ({
  activeScreen,
  setActiveScreen,
  isMobileFrame,
  setIsMobileFrame,
  isDarkMode,
  setIsDarkMode,
  onOpenSos,
  onOpenNotifications,
  unreadNotificationsCount = 0,
  currentUser,
  onOpenAuth,
  onSignOut,
}) => {
  const currentIndex = SEQUENTIAL_SCREENS.indexOf(activeScreen);
  const prevScreen = currentIndex > 0 ? SEQUENTIAL_SCREENS[currentIndex - 1] : null;
  const nextScreen = currentIndex < SEQUENTIAL_SCREENS.length - 1 ? SEQUENTIAL_SCREENS[currentIndex + 1] : null;

  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-slate-900/80 border-b border-cyan-500/20 text-white shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-2">
        
        {/* Left: Branding & Status */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 shadow-lg shadow-cyan-500/30 p-0.5 shrink-0">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Activity className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-400 rounded-full border-2 border-slate-900 shadow-sm shadow-emerald-400" />
          </div>

          <div className="hidden sm:block">
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-lg tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-blue-200 to-indigo-300">
                MediFlow AI
              </span>
              <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                <Sparkles className="w-2.5 h-2.5 mr-1 text-cyan-300" /> 2026 AI
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium hidden lg:block">
              Smart Hospital Assistant & Queue Engine
            </p>
          </div>
        </div>

        {/* Center: Sequential Screen Navigation Stepper & Dropdown */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Previous Screen Button */}
          <button
            onClick={() => prevScreen && setActiveScreen(prevScreen)}
            disabled={!prevScreen}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 disabled:opacity-30 disabled:cursor-not-allowed border border-cyan-500/30 transition-all flex items-center justify-center shadow-md active:scale-95"
            title={prevScreen ? `Previous: Screen ${currentIndex}` : 'First Screen'}
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Sequential Dropdown */}
          <div className="relative inline-block text-left">
            <select
              value={activeScreen}
              onChange={(e) => setActiveScreen(e.target.value as ScreenId)}
              className="appearance-none bg-slate-800/90 text-cyan-300 hover:text-white border border-cyan-500/30 hover:border-cyan-400 font-bold text-xs sm:text-sm py-2 pl-3 pr-8 rounded-xl shadow-inner focus:outline-none focus:ring-2 focus:ring-cyan-400 cursor-pointer transition-all max-w-[180px] sm:max-w-none truncate"
            >
              {SCREENS_GROUPS.map((group) => (
                <optgroup key={group.label} label={group.label} className="bg-slate-900 text-cyan-400 font-extrabold">
                  {group.screens.map((screen) => (
                    <option key={screen.id} value={screen.id} className="bg-slate-900 text-white font-normal py-1">
                      {screen.title}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-cyan-400 absolute right-2.5 top-2.5 pointer-events-none" />
          </div>

          {/* Next Screen Button */}
          <button
            onClick={() => nextScreen && setActiveScreen(nextScreen)}
            disabled={!nextScreen}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 disabled:opacity-30 disabled:cursor-not-allowed border border-cyan-500/30 transition-all flex items-center justify-center shadow-md active:scale-95"
            title={nextScreen ? `Next: Screen ${currentIndex + 2}` : 'Last Screen'}
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Right: Actions (Phone Mode Toggle, SOS, Dark Mode) */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Emergency SOS Button */}
          <button
            onClick={onOpenSos}
            className="relative group flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-red-600 hover:from-red-500 hover:to-rose-500 text-white font-extrabold text-xs shadow-lg shadow-rose-600/40 border border-rose-400/40 transition-all transform hover:scale-105 active:scale-95"
            title="Emergency SOS Dispatch"
          >
            <span className="absolute -inset-0.5 rounded-xl bg-rose-500/50 blur-sm animate-pulse pointer-events-none" />
            <ShieldAlert className="w-4 h-4 animate-bounce relative z-10 text-white" />
            <span className="hidden md:inline relative z-10 tracking-wider">SOS</span>
            <span className="relative z-10 w-2 h-2 rounded-full bg-white animate-ping" />
          </button>

          {/* Push Notification Bell Button */}
          {onOpenNotifications && (
            <button
              onClick={onOpenNotifications}
              className="relative p-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-cyan-500/50 text-slate-300 hover:text-cyan-300 transition-all"
              title="Push Notification Center"
            >
              <Bell className="w-4 h-4 text-cyan-400" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-black flex items-center justify-center animate-pulse border border-slate-900 shadow-md">
                  {unreadNotificationsCount > 9 ? '9+' : unreadNotificationsCount}
                </span>
              )}
            </button>
          )}

          {/* View Mode Toggle: Phone Frame vs Desktop View */}
          <button
            onClick={() => setIsMobileFrame(!isMobileFrame)}
            className={`p-2 rounded-xl border text-xs font-medium transition-all flex items-center gap-1.5 ${
              isMobileFrame
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-md shadow-cyan-500/20'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
            title={isMobileFrame ? 'Switch to Expanded Desktop Layout' : 'Switch to 2026 Mobile Phone View'}
          >
            {isMobileFrame ? (
              <>
                <Smartphone className="w-4 h-4 text-cyan-400" />
                <span className="hidden xl:inline">Phone View</span>
              </>
            ) : (
              <>
                <Monitor className="w-4 h-4 text-slate-300" />
                <span className="hidden xl:inline">Studio View</span>
              </>
            )
            }
          </button>

          {/* Dark / Light Toggle */}
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 hover:text-cyan-300 transition-all"
            title="Toggle Atmosphere Theme"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-400" />}
          </button>

          {/* Firebase Account Auth Status Button */}
          {currentUser && !currentUser.isAnonymous ? (
            <div className="flex items-center gap-1.5 pl-1">
              <button
                onClick={() => setActiveScreen('profile')}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-bold hover:border-cyan-400 transition-all"
                title={`Signed in as ${currentUser.email}`}
              >
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="max-w-[80px] sm:max-w-[100px] truncate">{currentUser.displayName || currentUser.email?.split('@')[0]}</span>
              </button>
              <button
                onClick={onSignOut}
                className="p-2 rounded-xl bg-slate-800 hover:bg-rose-950/80 border border-slate-700 hover:border-rose-500/50 text-slate-400 hover:text-rose-300 transition-all"
                title="Sign Out of Firebase"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-md shadow-cyan-500/30 transition-all transform hover:scale-105 active:scale-95"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign In</span>
            </button>
          )}
        </div>

      </div>
    </header>
  );
};

