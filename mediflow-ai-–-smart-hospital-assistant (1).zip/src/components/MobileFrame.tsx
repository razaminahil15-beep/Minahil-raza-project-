import React from 'react';
import { ScreenId } from '../types';
import { Wifi, Signal, Battery, Clock } from 'lucide-react';
import { BottomNav } from './BottomNav';

interface MobileFrameProps {
  children: React.ReactNode;
  activeScreen: ScreenId;
  setActiveScreen: (screen: ScreenId) => void;
  isMobileFrame: boolean;
  onOpenAllScreens: () => void;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({
  children,
  activeScreen,
  setActiveScreen,
  isMobileFrame,
  onOpenAllScreens,
}) => {
  const now = new Date();
  const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  if (!isMobileFrame) {
    // Studio / Full Screen Desktop View
    return (
      <div className="w-full max-w-7xl mx-auto min-h-[calc(100vh-4rem)] p-2 sm:p-6 flex flex-col justify-between relative">
        <div className="flex-1 w-full bg-slate-900/80 backdrop-blur-2xl border border-cyan-500/20 rounded-3xl overflow-hidden shadow-2xl relative">
          {children}
        </div>
        <div className="mt-4">
          <BottomNav
            activeScreen={activeScreen}
            setActiveScreen={setActiveScreen}
            onOpenAllScreens={onOpenAllScreens}
          />
        </div>
      </div>
    );
  }

  // Mobile Smartphone View (2026 Glass Phone Frame)
  return (
    <div className="py-6 flex items-center justify-center min-h-[calc(100vh-4rem)]">
      <div className="relative w-full max-w-[410px] h-[840px] bg-slate-950 rounded-[50px] p-3 shadow-[0_0_60px_rgba(0,242,254,0.2)] border-[3px] border-slate-800 flex flex-col overflow-hidden ring-1 ring-cyan-500/30">
        
        {/* Dynamic Island / Camera Notch */}
        <div className="absolute top-5 left-1/2 -translate-x-1/2 w-28 h-5 bg-slate-950 border border-slate-800 rounded-full z-40 flex items-center justify-between px-3 shadow-md">
          <div className="w-2.5 h-2.5 rounded-full bg-slate-800 border border-slate-700" />
          <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
        </div>

        {/* Status Bar */}
        <div className="w-full h-8 px-6 pt-1 flex items-center justify-between text-[11px] font-semibold text-slate-300 z-30 select-none">
          <span className="font-mono text-cyan-300 font-bold">{timeString}</span>
          <div className="flex items-center gap-1.5 text-slate-400">
            <Signal className="w-3 h-3 text-cyan-400" />
            <span className="text-[10px] font-mono text-cyan-300 font-bold">5G</span>
            <Wifi className="w-3 h-3 text-cyan-400" />
            <Battery className="w-3.5 h-3.5 text-emerald-400" />
          </div>
        </div>

        {/* Screen Content Container */}
        <div className="flex-1 w-full overflow-y-auto rounded-[38px] bg-slate-950 relative scrollbar-thin scrollbar-thumb-slate-800">
          {children}
        </div>

        {/* Bottom Nav inside frame */}
        <div className="w-full rounded-b-[38px] overflow-hidden">
          <BottomNav
            activeScreen={activeScreen}
            setActiveScreen={setActiveScreen}
            onOpenAllScreens={onOpenAllScreens}
          />
        </div>

        {/* Home Indicator Bar */}
        <div className="w-32 h-1 bg-slate-700 rounded-full mx-auto my-1 z-40 opacity-60" />

      </div>
    </div>
  );
};
