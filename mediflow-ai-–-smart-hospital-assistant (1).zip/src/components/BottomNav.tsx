import React from 'react';
import { ScreenId } from '../types';
import { Home, Stethoscope, CalendarCheck, Clock, FileBadge, MessageSquareCode, Layers } from 'lucide-react';

interface BottomNavProps {
  activeScreen: ScreenId;
  setActiveScreen: (screen: ScreenId) => void;
  onOpenAllScreens: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeScreen,
  setActiveScreen,
  onOpenAllScreens,
}) => {
  const primaryTabs: {
    id: ScreenId;
    label: string;
    icon: React.FC<{ className?: string }>;
    badge?: string;
  }[] = [
    { id: 'dashboard', label: 'Home', icon: Home },
    { id: 'healthCheck', label: 'AI Check', icon: Stethoscope },
    { id: 'booking', label: 'Book', icon: CalendarCheck },
    { id: 'queueTracker', label: 'Queue', icon: Clock, badge: 'Live' },
    { id: 'wallet', label: 'History', icon: FileBadge },
    { id: 'aiAssistant', label: 'AI Chat', icon: MessageSquareCode },
  ];

  return (
    <nav className="w-full backdrop-blur-2xl bg-slate-900/95 border-t border-cyan-500/20 px-1.5 sm:px-3 py-1.5 flex items-center justify-around text-slate-400 select-none z-30 shadow-2xl">
      {primaryTabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeScreen === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => setActiveScreen(tab.id)}
            className={`flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-2xl transition-all duration-200 relative group ${
              isActive
                ? 'text-cyan-300 font-extrabold bg-cyan-500/10 border border-cyan-500/30'
                : 'hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            {/* Active Top Ambient Bar */}
            {isActive && (
              <span className="absolute -top-1.5 w-7 h-1 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-400 rounded-full shadow-md shadow-cyan-400/80 animate-pulse" />
            )}

            {/* Icon with optional live badge */}
            <div className="relative">
              <Icon className={`w-4 h-4 sm:w-5 sm:h-5 transition-all duration-200 ${
                isActive ? 'scale-110 text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.6)]' : 'text-slate-400 group-hover:text-cyan-200'
              }`} />
              
              {tab.badge && (
                <span className="absolute -top-1.5 -right-2.5 px-1 py-0.2 text-[8px] font-black bg-emerald-500 text-slate-950 rounded-full border border-slate-900 animate-pulse">
                  {tab.badge}
                </span>
              )}
            </div>

            <span className={`text-[10px] mt-1 font-semibold tracking-tight whitespace-nowrap transition-colors ${
              isActive ? 'text-cyan-300 font-bold' : 'text-slate-400'
            }`}>
              {tab.label}
            </span>
          </button>
        );
      })}

      {/* Grid Launcher Modal Toggle */}
      <button
        onClick={onOpenAllScreens}
        className="flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-2xl text-slate-400 hover:text-cyan-300 hover:bg-slate-800/50 transition-all group"
        title="All Screens Launcher (9 Screens)"
      >
        <div className="p-1 rounded-lg bg-gradient-to-tr from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 text-cyan-400 group-hover:scale-105 transition-transform">
          <Layers className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </div>
        <span className="text-[10px] mt-1 font-bold text-cyan-300 tracking-tight whitespace-nowrap">
          More (9)
        </span>
      </button>
    </nav>
  );
};

