import React, { useEffect, useState } from 'react';
import { AppNotification, ScreenId } from '../types';
import { notificationService } from '../services/notificationService';
import { 
  Bell, 
  X, 
  ChevronRight, 
  Clock, 
  Zap, 
  AlertTriangle, 
  Calendar, 
  Bot, 
  CheckCircle2, 
  Volume2
} from 'lucide-react';

interface NotificationToastBannerProps {
  latestPushNotification: AppNotification | null;
  onClearToast: () => void;
  setActiveScreen: (screen: ScreenId) => void;
}

export const NotificationToastBanner: React.FC<NotificationToastBannerProps> = ({
  latestPushNotification,
  onClearToast,
  setActiveScreen,
}) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (latestPushNotification) {
      setVisible(true);
      // Auto dismiss after 6 seconds
      const timer = setTimeout(() => {
        setVisible(false);
        setTimeout(onClearToast, 300); // Allow fade out transition
      }, 6500);

      return () => clearTimeout(timer);
    } else {
      setVisible(false);
    }
  }, [latestPushNotification]);

  if (!latestPushNotification || !visible) return null;

  const handleAction = () => {
    notificationService.markAsRead(latestPushNotification.id);
    if (latestPushNotification.actionScreen) {
      setActiveScreen(latestPushNotification.actionScreen);
    }
    setVisible(false);
    onClearToast();
  };

  const getTypeStyle = () => {
    switch (latestPushNotification.type) {
      case 'queue_update':
        return {
          bg: 'from-cyan-950/95 via-slate-900 to-slate-950',
          border: 'border-cyan-400/80',
          glow: 'shadow-cyan-500/30',
          icon: <Zap className="w-5 h-5 text-cyan-300 animate-bounce" />,
          badge: 'QUEUE STATUS UPDATE',
          badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40'
        };
      case 'appointment_reminder':
        return {
          bg: 'from-amber-950/95 via-slate-900 to-slate-950',
          border: 'border-amber-400/80',
          glow: 'shadow-amber-500/30',
          icon: <Calendar className="w-5 h-5 text-amber-300 animate-pulse" />,
          badge: 'APPOINTMENT APPROACHING',
          badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-400/40'
        };
      case 'triage_alert':
        return {
          bg: 'from-rose-950/95 via-slate-900 to-slate-950',
          border: 'border-rose-400/80',
          glow: 'shadow-rose-500/30',
          icon: <AlertTriangle className="w-5 h-5 text-rose-400 animate-bounce" />,
          badge: 'TRIAGE PRIORITY ALERT',
          badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-400/40'
        };
      default:
        return {
          bg: 'from-slate-900 via-slate-900 to-slate-950',
          border: 'border-blue-500/60',
          glow: 'shadow-blue-500/20',
          icon: <Bell className="w-5 h-5 text-blue-400" />,
          badge: 'SYSTEM PUSH ALERT',
          badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-400/40'
        };
    }
  };

  const style = getTypeStyle();

  return (
    <div className="fixed top-20 right-3 left-3 sm:left-auto sm:right-6 z-50 max-w-sm w-full animate-bounce-short">
      <div className={`p-4 rounded-3xl bg-gradient-to-br ${style.bg} border-2 ${style.border} text-white shadow-2xl ${style.glow} backdrop-blur-xl relative overflow-hidden transition-all duration-300 transform scale-100 hover:scale-[1.02]`}>
        
        {/* Top Progress Line Timer */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-slate-800">
          <div className="h-full bg-cyan-400 animate-shrink-width" style={{ animationDuration: '6.5s' }} />
        </div>

        <div className="flex items-start justify-between gap-3 pt-1">
          {/* Left Icon Badge */}
          <div className="p-2.5 rounded-2xl bg-slate-900/90 border border-slate-700/80 shrink-0 shadow-md">
            {style.icon}
          </div>

          {/* Content */}
          <div className="flex-1 space-y-1">
            <div className="flex items-center gap-2">
              <span className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wider border ${style.badgeColor}`}>
                {style.badge}
              </span>
              <span className="text-[10px] text-slate-400 font-mono ml-auto">Now</span>
            </div>

            <h4 className="text-xs font-black text-white leading-snug">
              {latestPushNotification.title}
            </h4>

            <p className="text-[11px] text-slate-300 leading-normal line-clamp-2">
              {latestPushNotification.message}
            </p>

            {/* Quick Action Button */}
            <div className="pt-2 flex items-center gap-2">
              <button
                onClick={handleAction}
                className="px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-[11px] uppercase tracking-wider flex items-center gap-1 shadow-md shadow-cyan-500/20 transition-all"
              >
                <span>View Details</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => {
                  notificationService.markAsRead(latestPushNotification.id);
                  setVisible(false);
                  onClearToast();
                }}
                className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-bold transition-colors"
              >
                Dismiss
              </button>
            </div>
          </div>

          {/* Close X */}
          <button
            onClick={() => {
              setVisible(false);
              onClearToast();
            }}
            className="p-1 rounded-full text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
