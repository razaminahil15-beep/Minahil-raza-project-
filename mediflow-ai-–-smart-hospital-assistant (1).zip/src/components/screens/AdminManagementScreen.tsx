import React, { useState, useEffect } from 'react';
import { ScreenId, Doctor, Appointment } from '../../types';
import { INITIAL_DOCTORS, HOSPITALS_OVERFLOW } from '../../data/mockData';
import { signInUser, signOutUser } from '../../services/authService';
import { 
  subscribeAllAppointments, 
  adminSaveAppointment, 
  adminUpdateAppointmentStatus, 
  adminDeleteAppointment 
} from '../../services/firestoreService';
import { 
  Sparkles, 
  Cpu, 
  Users, 
  Clock, 
  ShieldAlert, 
  RefreshCw, 
  Building2, 
  CheckCircle2, 
  XCircle, 
  Plus, 
  Search, 
  Trash2, 
  Edit3, 
  Lock, 
  LogIn, 
  Key, 
  LogOut, 
  Filter, 
  Calendar, 
  MapPin, 
  User, 
  Check, 
  AlertCircle,
  X,
  DollarSign,
  UserCheck
} from 'lucide-react';

interface AdminManagementScreenProps {
  setActiveScreen: (screen: ScreenId) => void;
  currentUser?: any;
  onOpenAuth?: () => void;
}

const DEFAULT_ADMIN_EMAIL = 'razaminahil15@gmail.com';
const DEFAULT_ADMIN_PASS = 'mini12345678_9';

const INITIAL_MOCK_BOOKINGS: (Appointment & { patientName?: string; patientEmail?: string })[] = [
  {
    id: 'apt-2026-901',
    patientName: 'Sarah Jenkins',
    patientEmail: 'sarah.j@example.com',
    doctorName: 'Dr. Sarah Vance',
    doctorSpecialty: 'Cardiologist',
    doctorAvatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=200',
    hospitalName: 'St. Jude Medical Center',
    roomNumber: 'Suite 304 - Pod A',
    date: 'Today, Jul 25',
    time: '10:30 AM',
    tokenNumber: 'A-102',
    status: 'In Queue',
    queuePosition: 2,
    estimatedWaitMins: 14,
  },
  {
    id: 'apt-2026-902',
    patientName: 'Michael Chang',
    patientEmail: 'm.chang@example.com',
    doctorName: 'Dr. Marcus Thorne',
    doctorSpecialty: 'Neurologist',
    doctorAvatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=200',
    hospitalName: 'MediFlow Central Hospital',
    roomNumber: 'Room 210 - East Wing',
    date: 'Today, Jul 25',
    time: '11:15 AM',
    tokenNumber: 'B-205',
    status: 'In Queue',
    queuePosition: 4,
    estimatedWaitMins: 28,
  },
  {
    id: 'apt-2026-903',
    patientName: 'Elena Rostova',
    patientEmail: 'elena.r@example.com',
    doctorName: 'Dr. Emily Chen',
    doctorSpecialty: 'Pediatric Specialist',
    doctorAvatar: 'https://images.unsplash.com/photo-1594824813566-8885577e7d5a?auto=format&fit=crop&q=80&w=200',
    hospitalName: 'Childrens Hope Pavilion',
    roomNumber: 'Pediatrics Suite 12',
    date: 'Today, Jul 25',
    time: '09:00 AM',
    tokenNumber: 'P-101',
    status: 'Completed',
    queuePosition: 0,
    estimatedWaitMins: 0,
  }
];

export const AdminManagementScreen: React.FC<AdminManagementScreenProps> = ({
  setActiveScreen,
  currentUser,
  onOpenAuth,
}) => {
  // Login Form state
  const [adminEmailInput, setAdminEmailInput] = useState(DEFAULT_ADMIN_EMAIL);
  const [adminPasswordInput, setAdminPasswordInput] = useState(DEFAULT_ADMIN_PASS);
  const [authError, setAuthError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Admin Portal State
  const [activeTab, setActiveTab] = useState<'Bookings' | 'Doctors' | 'Capacity' | 'LoadBalancing' | 'Routing' | 'Revenue'>('Bookings');
  const [doctors, setDoctors] = useState<Doctor[]>(INITIAL_DOCTORS);
  const [reassigning, setReassigning] = useState(false);
  const [emergencyOverrideActive, setEmergencyOverrideActive] = useState(false);

  // Bookings state
  const [bookings, setBookings] = useState<(Appointment & { patientName?: string; patientEmail?: string })[]>(INITIAL_MOCK_BOOKINGS);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'In Queue' | 'Completed' | 'Cancelled'>('All');

  // Booking Modal State (Create / Edit)
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBookingId, setEditingBookingId] = useState<string | null>(null);
  
  // Form fields
  const [formPatientName, setFormPatientName] = useState('');
  const [formPatientEmail, setFormPatientEmail] = useState('');
  const [formDoctorName, setFormDoctorName] = useState(INITIAL_DOCTORS[0].name);
  const [formDoctorSpecialty, setFormDoctorSpecialty] = useState(INITIAL_DOCTORS[0].specialty);
  const [formHospital, setFormHospital] = useState(INITIAL_DOCTORS[0].hospitalName);
  const [formRoomNumber, setFormRoomNumber] = useState('Suite 101 - Pod A');
  const [formDate, setFormDate] = useState('Today, Jul 25');
  const [formTime, setFormTime] = useState('02:30 PM');
  const [formTokenNumber, setFormTokenNumber] = useState(`A-${Math.floor(Math.random() * 80 + 100)}`);
  const [formStatus, setFormStatus] = useState<'In Queue' | 'Completed' | 'Cancelled'>('In Queue');
  const [formWaitMins, setFormWaitMins] = useState(15);

  const userEmail = currentUser?.email || currentUser?.user?.email || '';
  const isAdminAuthenticated = userEmail === DEFAULT_ADMIN_EMAIL;

  // Real-time Firestore Sync for Admin Bookings
  useEffect(() => {
    if (!isAdminAuthenticated) return;

    const unsubscribe = subscribeAllAppointments((firestoreAppointments) => {
      if (firestoreAppointments && firestoreAppointments.length > 0) {
        // Merge or replace
        const combined = [...firestoreAppointments];
        // Ensure no duplicate IDs
        INITIAL_MOCK_BOOKINGS.forEach((mock) => {
          if (!combined.some((item) => item.id === mock.id)) {
            combined.push(mock);
          }
        });
        setBookings(combined);
      }
    });

    return () => unsubscribe();
  }, [isAdminAuthenticated]);

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setIsLoggingIn(true);

    try {
      const authResult = await signInUser(adminEmailInput, adminPasswordInput);
      const email = authResult?.user?.email || (authResult as any)?.email;
      if (email !== DEFAULT_ADMIN_EMAIL) {
        setAuthError(`Account signed in, but "${email}" does not have admin privileges. Only ${DEFAULT_ADMIN_EMAIL} is authorized.`);
      }
    } catch (err: any) {
      setAuthError(err?.message || 'Invalid admin credentials. Please check password.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleQuickFillAdmin = () => {
    setAdminEmailInput(DEFAULT_ADMIN_EMAIL);
    setAdminPasswordInput(DEFAULT_ADMIN_PASS);
  };

  const handleOpenAddModal = () => {
    setEditingBookingId(null);
    setFormPatientName('');
    setFormPatientEmail('');
    setFormDoctorName(INITIAL_DOCTORS[0].name);
    setFormDoctorSpecialty(INITIAL_DOCTORS[0].specialty);
    setFormHospital(INITIAL_DOCTORS[0].hospitalName);
    setFormRoomNumber('Suite 302 - Pod B');
    setFormDate('Today, Jul 25');
    setFormTime('02:00 PM');
    setFormTokenNumber(`A-${Math.floor(Math.random() * 80 + 100)}`);
    setFormStatus('In Queue');
    setFormWaitMins(12);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (apt: Appointment & { patientName?: string; patientEmail?: string }) => {
    setEditingBookingId(apt.id);
    setFormPatientName(apt.patientName || 'Patient');
    setFormPatientEmail(apt.patientEmail || 'patient@mediflow.com');
    setFormDoctorName(apt.doctorName);
    setFormDoctorSpecialty(apt.doctorSpecialty);
    setFormHospital(apt.hospitalName);
    setFormRoomNumber(apt.roomNumber);
    setFormDate(apt.date);
    setFormTime(apt.time);
    setFormTokenNumber(apt.tokenNumber);
    setFormStatus(apt.status);
    setFormWaitMins(apt.estimatedWaitMins);
    setIsModalOpen(true);
  };

  const handleSaveBookingForm = async (e: React.FormEvent) => {
    e.preventDefault();
    const docObj = INITIAL_DOCTORS.find((d) => d.name === formDoctorName) || INITIAL_DOCTORS[0];

    const aptToSave: Appointment & { patientName?: string; patientEmail?: string } = {
      id: editingBookingId || `apt-2026-${Math.floor(Math.random() * 8999 + 1000)}`,
      patientName: formPatientName || 'Anonymous Patient',
      patientEmail: formPatientEmail || 'patient@mediflow.com',
      doctorName: formDoctorName,
      doctorSpecialty: formDoctorSpecialty || docObj.specialty,
      doctorAvatar: docObj.avatar,
      hospitalName: formHospital || docObj.hospitalName,
      roomNumber: formRoomNumber,
      date: formDate,
      time: formTime,
      tokenNumber: formTokenNumber,
      status: formStatus,
      queuePosition: formStatus === 'In Queue' ? 3 : 0,
      estimatedWaitMins: formWaitMins,
    };

    // Update state locally
    setBookings((prev) => {
      const idx = prev.findIndex((b) => b.id === aptToSave.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = aptToSave;
        return copy;
      }
      return [aptToSave, ...prev];
    });

    // Save to Firestore
    await adminSaveAppointment(aptToSave);
    setIsModalOpen(false);
  };

  const handleStatusChange = async (id: string, newStatus: 'In Queue' | 'Completed' | 'Cancelled') => {
    setBookings((prev) =>
      prev.map((b) => (b.id === id ? { ...b, status: newStatus } : b))
    );
    await adminUpdateAppointmentStatus(id, newStatus);
  };

  const handleDeleteBooking = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this appointment from the hospital database?')) {
      setBookings((prev) => prev.filter((b) => b.id !== id));
      await adminDeleteAppointment(id);
    }
  };

  const toggleDoctorStatus = (id: string) => {
    setDoctors((prev) =>
      prev.map((doc) => {
        if (doc.id === id) {
          const nextStatus = doc.status === 'Available' ? 'Busy' : doc.status === 'Busy' ? 'Break' : 'Available';
          return { ...doc, status: nextStatus };
        }
        return doc;
      })
    );
  };

  const triggerAiReassignment = () => {
    setReassigning(true);
    setTimeout(() => {
      setReassigning(false);
      setDoctors((prev) =>
        prev.map((d) => ({
          ...d,
          estimatedWaitMins: Math.max(3, Math.floor(d.estimatedWaitMins * 0.7)),
        }))
      );
    }, 1200);
  };

  // Filtered bookings
  const filteredBookings = bookings.filter((apt) => {
    const matchesStatus = statusFilter === 'All' || apt.status === statusFilter;
    const queryLower = searchQuery.toLowerCase();
    const matchesSearch =
      !searchQuery ||
      (apt.patientName && apt.patientName.toLowerCase().includes(queryLower)) ||
      apt.doctorName.toLowerCase().includes(queryLower) ||
      apt.tokenNumber.toLowerCase().includes(queryLower) ||
      apt.hospitalName.toLowerCase().includes(queryLower);
    return matchesStatus && matchesSearch;
  });

  // Metrics
  const totalBookingsCount = bookings.length;
  const inQueueCount = bookings.filter((b) => b.status === 'In Queue').length;
  const completedCount = bookings.filter((b) => b.status === 'Completed').length;
  const cancelledCount = bookings.filter((b) => b.status === 'Cancelled').length;

  // Render Admin Gateway if not authorized
  if (!isAdminAuthenticated) {
    return (
      <div className="min-h-full p-4 sm:p-6 text-white space-y-6 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 pb-20 flex flex-col justify-center">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-black uppercase tracking-wider">
            <Lock className="w-3.5 h-3.5" /> Restricted Admin Portal
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">MediFlow AI Hospital Admin</h1>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Authorized hospital personnel only. Please sign in with administrator credentials to manage live bookings and queue systems.
          </p>
        </div>

        {/* Admin Login Card */}
        <div className="max-w-md mx-auto w-full p-6 rounded-3xl bg-slate-900/90 border border-rose-500/30 shadow-2xl space-y-4">
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-rose-950/40 border border-rose-500/30">
            <ShieldAlert className="w-6 h-6 text-rose-400 shrink-0" />
            <div className="text-xs">
              <strong className="text-rose-200 block font-extrabold">Admin Credential Lock</strong>
              <span className="text-slate-300">Authorized Admin Email: <code className="text-cyan-300 font-bold">{DEFAULT_ADMIN_EMAIL}</code></span>
            </div>
          </div>

          <form onSubmit={handleAdminLogin} className="space-y-3">
            <div>
              <label className="block text-xs font-extrabold text-slate-300 mb-1">Admin Email Address</label>
              <input
                type="email"
                required
                value={adminEmailInput}
                onChange={(e) => setAdminEmailInput(e.target.value)}
                placeholder="razaminahil15@gmail.com"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-rose-500 text-white text-xs font-mono outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-extrabold text-slate-300 mb-1">Admin Security Password</label>
              <input
                type="password"
                required
                value={adminPasswordInput}
                onChange={(e) => setAdminPasswordInput(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-rose-500 text-white text-xs font-mono outline-none"
              />
            </div>

            {authError && (
              <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500 text-rose-200 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{authError}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-rose-600/30 transition-all"
            >
              {isLoggingIn ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <LogIn className="w-4 h-4" />
              )}
              <span>{isLoggingIn ? 'Authenticating Admin...' : 'Sign In To Admin Portal'}</span>
            </button>
          </form>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
            <button
              onClick={handleQuickFillAdmin}
              className="px-3 py-1.5 rounded-xl bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-300 font-bold text-xs flex items-center gap-1 transition-all"
            >
              <Key className="w-3.5 h-3.5" /> Quick Fill Admin Credentials
            </button>
            <span className="text-[10px] text-slate-500 font-mono">ID: {DEFAULT_ADMIN_EMAIL}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-full p-4 sm:p-6 text-white space-y-4 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 pb-20">
      
      {/* Top Admin Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-rose-500/30">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-rose-400 uppercase tracking-widest">
            <Sparkles className="w-4 h-4 text-rose-400" /> Admin Command Center
          </div>
          <h1 className="text-xl font-black text-white tracking-tight flex items-center gap-2">
            Smart Hospital AI Admin
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-xl bg-rose-950/80 border border-rose-500/40 text-rose-300 font-bold text-xs flex items-center gap-1.5">
            <UserCheck className="w-3.5 h-3.5 text-rose-400" />
            <span className="max-w-[140px] truncate">{userEmail}</span>
          </div>
          <button
            onClick={() => signOutUser()}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-rose-900 border border-slate-700 text-slate-300 hover:text-white transition-all"
            title="Sign Out Admin"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Admin Tab Switcher */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {[
          { id: 'Bookings', label: 'All Bookings & Queue' },
          { id: 'Doctors', label: 'Doctor Staff' },
          { id: 'Capacity', label: 'Capacity Rules' },
          { id: 'LoadBalancing', label: 'Load Balancing' },
          { id: 'Routing', label: 'Multi-Hospital' },
          { id: 'Revenue', label: 'Revenue AI' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              activeTab === tab.id
                ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB 1: ALL BOOKINGS MANAGEMENT & QUEUE (MAIN USER REQUEST) */}
      {activeTab === 'Bookings' && (
        <div className="space-y-4">
          
          {/* Action & Filter Header */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2 flex-1">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search patient, doctor, token..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:border-rose-500 outline-none"
                />
              </div>

              {/* Status Filter buttons */}
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                {(['All', 'In Queue', 'Completed', 'Cancelled'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setStatusFilter(st)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all ${
                      statusFilter === st ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {/* Add New Booking Button */}
            <button
              onClick={handleOpenAddModal}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-lg shadow-cyan-500/20 transition-all transform hover:scale-105 active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Booking</span>
            </button>
          </div>

          {/* Metrics Overview Bar */}
          <div className="grid grid-cols-4 gap-2 text-center text-xs">
            <div className="p-2.5 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-bold">Total Bookings</span>
              <strong className="text-white font-mono text-base">{totalBookingsCount}</strong>
            </div>
            <div className="p-2.5 rounded-2xl bg-cyan-950/60 border border-cyan-500/30">
              <span className="text-[10px] text-cyan-300 block font-bold">In Queue</span>
              <strong className="text-cyan-300 font-mono text-base">{inQueueCount}</strong>
            </div>
            <div className="p-2.5 rounded-2xl bg-emerald-950/60 border border-emerald-500/30">
              <span className="text-[10px] text-emerald-300 block font-bold">Completed</span>
              <strong className="text-emerald-300 font-mono text-base">{completedCount}</strong>
            </div>
            <div className="p-2.5 rounded-2xl bg-rose-950/60 border border-rose-500/30">
              <span className="text-[10px] text-rose-300 block font-bold">Cancelled</span>
              <strong className="text-rose-300 font-mono text-base">{cancelledCount}</strong>
            </div>
          </div>

          {/* Bookings List */}
          <div className="space-y-2.5">
            {filteredBookings.length === 0 ? (
              <div className="p-8 text-center rounded-2xl bg-slate-900/50 border border-slate-800 text-slate-400 space-y-2">
                <Search className="w-8 h-8 text-slate-600 mx-auto" />
                <p className="text-xs font-bold">No bookings found matching filter criteria.</p>
                <button
                  onClick={() => { setSearchQuery(''); setStatusFilter('All'); }}
                  className="text-xs text-rose-400 underline font-bold"
                >
                  Clear search filters
                </button>
              </div>
            ) : (
              filteredBookings.map((apt) => (
                <div
                  key={apt.id}
                  className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-all space-y-3 shadow-md"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-2">
                    <div className="flex items-center gap-3">
                      <img
                        src={apt.doctorAvatar || 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=200'}
                        alt={apt.doctorName}
                        className="w-10 h-10 rounded-xl object-cover border border-cyan-500/30 shrink-0"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-extrabold text-white">{apt.patientName || 'Patient'}</h4>
                          <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono text-[10px] font-bold">
                            Token #{apt.tokenNumber}
                          </span>
                        </div>
                        <p className="text-[11px] text-cyan-300 font-semibold">{apt.doctorName} ({apt.doctorSpecialty})</p>
                        <p className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <Building2 className="w-3 h-3 text-slate-500" /> {apt.hospitalName} • {apt.roomNumber}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3">
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 block">{apt.date} @ {apt.time}</span>
                        <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide border ${
                          apt.status === 'Completed'
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                            : apt.status === 'Cancelled'
                            ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                            : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                        }`}>
                          {apt.status}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions Bar for Booking */}
                  <div className="flex items-center justify-between text-xs pt-0.5">
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                      <Clock className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Wait: <strong className="text-cyan-300 font-mono">~{apt.estimatedWaitMins}m</strong></span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {/* Status Quick Toggles */}
                      <button
                        onClick={() => handleStatusChange(apt.id, 'Completed')}
                        className={`p-1.5 rounded-lg border text-[10px] font-bold flex items-center gap-1 transition-all ${
                          apt.status === 'Completed'
                            ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                            : 'bg-slate-800 text-emerald-400 border-emerald-500/30 hover:bg-emerald-950'
                        }`}
                        title="Mark Completed"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Done</span>
                      </button>

                      <button
                        onClick={() => handleStatusChange(apt.id, 'In Queue')}
                        className={`p-1.5 rounded-lg border text-[10px] font-bold flex items-center gap-1 transition-all ${
                          apt.status === 'In Queue'
                            ? 'bg-cyan-500 text-slate-950 border-cyan-400'
                            : 'bg-slate-800 text-cyan-300 border-cyan-500/30 hover:bg-cyan-950'
                        }`}
                        title="Mark In Queue"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Queue</span>
                      </button>

                      <button
                        onClick={() => handleStatusChange(apt.id, 'Cancelled')}
                        className={`p-1.5 rounded-lg border text-[10px] font-bold flex items-center gap-1 transition-all ${
                          apt.status === 'Cancelled'
                            ? 'bg-rose-500 text-white border-rose-400'
                            : 'bg-slate-800 text-rose-400 border-rose-500/30 hover:bg-rose-950'
                        }`}
                        title="Mark Cancelled"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Cancel</span>
                      </button>

                      {/* Edit Booking */}
                      <button
                        onClick={() => handleOpenEditModal(apt)}
                        className="p-1.5 rounded-lg bg-slate-800 border border-slate-700 text-amber-300 hover:bg-amber-950 hover:border-amber-500/50 transition-all"
                        title="Edit Appointment Details"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      {/* Delete Booking */}
                      <button
                        onClick={() => handleDeleteBooking(apt.id)}
                        className="p-1.5 rounded-lg bg-slate-800 border border-slate-700 text-rose-400 hover:bg-rose-950 hover:border-rose-500/50 transition-all"
                        title="Delete Appointment"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 2: Doctor Management */}
      {activeTab === 'Doctors' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-extrabold text-white uppercase tracking-wider">
              Active Medical Staff ({doctors.length} Doctors)
            </h3>
            <button
              onClick={triggerAiReassignment}
              className="px-3 py-1 rounded-xl bg-cyan-500 text-slate-950 font-extrabold text-xs flex items-center gap-1 shadow-md hover:bg-cyan-400"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${reassigning ? 'animate-spin' : ''}`} />
              Auto-Reassign Patients
            </button>
          </div>

          <div className="space-y-2">
            {doctors.map((doc) => (
              <div
                key={doc.id}
                className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <img src={doc.avatar} alt={doc.name} className="w-10 h-10 rounded-xl object-cover border border-slate-700" />
                  <div>
                    <h4 className="font-bold text-white">{doc.name}</h4>
                    <p className="text-[11px] text-cyan-300">{doc.department} • {doc.specialty}</p>
                    <p className="text-[10px] text-slate-400">Load: {doc.currentPatientsCount}/{doc.dailyCapacity} Patients</p>
                  </div>
                </div>

                <div className="text-right space-y-1">
                  <button
                    onClick={() => toggleDoctorStatus(doc.id)}
                    className={`px-2.5 py-1 rounded-xl font-bold text-[10px] border transition-all ${
                      doc.status === 'Available' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : doc.status === 'Busy' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-slate-800 text-slate-400 border-slate-700'
                    }`}
                  >
                    Status: {doc.status}
                  </button>
                  <span className="block text-[10px] text-slate-400 font-mono">Wait: ~{doc.estimatedWaitMins}m</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: Capacity Rules */}
      {activeTab === 'Capacity' && (
        <div className="space-y-3">
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
            <h3 className="text-xs font-extrabold text-cyan-300 uppercase tracking-wide flex items-center gap-1.5">
              <Users className="w-4 h-4 text-cyan-400" /> AI Patient Capacity Guidelines
            </h3>
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 block text-[10px]">General Physician</span>
                <strong className="text-cyan-300 font-mono text-sm">40–50 / day</strong>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 block text-[10px]">Specialist Doctor</span>
                <strong className="text-blue-300 font-mono text-sm">25–35 / day</strong>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 block text-[10px]">Senior Consultant</span>
                <strong className="text-indigo-300 font-mono text-sm">20–30 / day</strong>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: Load Balancing */}
      {activeTab === 'LoadBalancing' && (
        <div className="space-y-3">
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-extrabold text-white uppercase tracking-wide">
                Multi-Doctor Load Distribution
              </h3>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/20 px-2 py-0.5 rounded">
                AI Balanced
              </span>
            </div>

            <div className="space-y-2">
              {doctors.map((doc) => {
                const percent = Math.round((doc.currentPatientsCount / doc.dailyCapacity) * 100);
                return (
                  <div key={doc.id} className="space-y-1">
                    <div className="flex justify-between text-xs text-slate-300">
                      <span>{doc.name} ({doc.department})</span>
                      <span className="font-mono text-cyan-300">{percent}% ({doc.currentPatientsCount}/{doc.dailyCapacity})</span>
                    </div>
                    <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-500 ${
                          percent > 85 ? 'bg-rose-500' : percent > 65 ? 'bg-amber-400' : 'bg-cyan-400'
                        }`}
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: Multi-Hospital Routing */}
      {activeTab === 'Routing' && (
        <div className="space-y-3">
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-extrabold text-white uppercase tracking-wide flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-cyan-400" /> Multi-Hospital AI Routing Engine
              </h3>
              <span className="text-[10px] text-cyan-300 font-bold">3 Facilities Monitored</span>
            </div>

            <div className="space-y-2.5">
              {HOSPITALS_OVERFLOW.map((hosp) => (
                <div
                  key={hosp.id}
                  className={`p-3.5 rounded-2xl border text-xs space-y-1.5 ${
                    hosp.isOvercrowded
                      ? 'bg-rose-950/40 border-rose-500/40'
                      : 'bg-slate-950 border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-white">{hosp.name}</h4>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      hosp.isOvercrowded ? 'bg-rose-500/20 text-rose-400' : 'bg-emerald-500/20 text-emerald-300'
                    }`}>
                      {hosp.isOvercrowded ? 'Overcrowded (88%)' : 'Optimal Capacity'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-300">
                    <span>Distance: {hosp.distanceMiles} mi ({hosp.travelTimeMins} mins travel)</span>
                    <span className="font-mono text-cyan-300">Avg Wait: ~{hosp.avgWaitMins}m</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: Revenue AI */}
      {activeTab === 'Revenue' && (
        <div className="space-y-3">
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/80 to-slate-900 border border-emerald-500/40 space-y-3">
            <h3 className="text-xs font-extrabold text-emerald-300 uppercase tracking-wide flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-emerald-400" /> Hospital AI Revenue & Efficiency Drivers
            </h3>

            <div className="space-y-2 text-xs text-slate-200">
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <span>Smart Scheduling & Slot Optimization</span>
                <strong className="text-emerald-400">+32% Revenue Boost</strong>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <span>Paperwork Automation & Telemedicine Redirect</span>
                <strong className="text-cyan-300">$184,000 / mo Savings</strong>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ADD / EDIT BOOKING MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg p-5 rounded-3xl bg-slate-900 border border-cyan-500/40 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300">
                  <Calendar className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">
                    {editingBookingId ? 'Edit Patient Booking' : 'Add New Hospital Booking'}
                  </h3>
                  <p className="text-[10px] text-cyan-300">Admin Control Panel</p>
                </div>
              </div>

              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveBookingForm} className="space-y-3 text-xs">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-extrabold mb-1">Patient Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Jane Doe"
                    value={formPatientName}
                    onChange={(e) => setFormPatientName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-extrabold mb-1">Patient Email / Contact</label>
                  <input
                    type="email"
                    placeholder="e.g. jane.doe@example.com"
                    value={formPatientEmail}
                    onChange={(e) => setFormPatientEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-extrabold mb-1">Select Doctor</label>
                  <select
                    value={formDoctorName}
                    onChange={(e) => {
                      const name = e.target.value;
                      setFormDoctorName(name);
                      const d = INITIAL_DOCTORS.find((doc) => doc.name === name);
                      if (d) {
                        setFormDoctorSpecialty(d.specialty);
                        setFormHospital(d.hospitalName);
                      }
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none focus:border-cyan-500"
                  >
                    {INITIAL_DOCTORS.map((doc) => (
                      <option key={doc.id} value={doc.name}>
                        {doc.name} ({doc.specialty})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-extrabold mb-1">Specialty</label>
                  <input
                    type="text"
                    value={formDoctorSpecialty}
                    onChange={(e) => setFormDoctorSpecialty(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-extrabold mb-1">Hospital / Medical Center</label>
                  <input
                    type="text"
                    value={formHospital}
                    onChange={(e) => setFormHospital(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-extrabold mb-1">Room / Suite Number</label>
                  <input
                    type="text"
                    value={formRoomNumber}
                    onChange={(e) => setFormRoomNumber(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-300 font-extrabold mb-1">Date</label>
                  <input
                    type="text"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none focus:border-cyan-500 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-extrabold mb-1">Time Slot</label>
                  <input
                    type="text"
                    value={formTime}
                    onChange={(e) => setFormTime(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none focus:border-cyan-500 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-extrabold mb-1">Token #</label>
                  <input
                    type="text"
                    value={formTokenNumber}
                    onChange={(e) => setFormTokenNumber(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-cyan-300 font-mono font-bold outline-none focus:border-cyan-500 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-extrabold mb-1">Queue Status</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none focus:border-cyan-500"
                  >
                    <option value="In Queue">In Queue</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-extrabold mb-1">Est. Wait (Minutes)</label>
                  <input
                    type="number"
                    value={formWaitMins}
                    onChange={(e) => setFormWaitMins(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold hover:bg-slate-700"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-cyan-500/30"
                >
                  <Check className="w-4 h-4" />
                  <span>{editingBookingId ? 'Update Booking' : 'Save Booking'}</span>
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
};
