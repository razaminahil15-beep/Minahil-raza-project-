import React, { useState } from 'react';
import { ScreenId, Doctor, Appointment } from '../../types';
import { INITIAL_DOCTORS } from '../../data/mockData';
import { Sparkles, Star, MapPin, Clock, DollarSign, Search, CheckCircle2, Calendar, ShieldCheck, ArrowRight, UserCheck, LogIn, AlertCircle } from 'lucide-react';

interface BookingScreenProps {
  setActiveScreen: (screen: ScreenId) => void;
  onBookAppointment: (appointment: Appointment) => void;
  currentUser?: any;
  onOpenAuth?: () => void;
}

export const BookingScreen: React.FC<BookingScreenProps> = ({
  setActiveScreen,
  onBookAppointment,
  currentUser,
  onOpenAuth,
}) => {
  const [selectedDept, setSelectedDept] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<string>('');
  const [bookingConfirmed, setBookingConfirmed] = useState(false);
  const [showAuthWarning, setShowAuthWarning] = useState(false);

  const departments = ['All', 'Cardiology', 'Neurology', 'Emergency & Trauma', 'Orthopedics', 'Pediatrics'];

  const filteredDoctors = INITIAL_DOCTORS.filter((doc) => {
    const matchesDept = selectedDept === 'All' || doc.department === selectedDept;
    const matchesQuery = doc.name.toLowerCase().includes(searchQuery.toLowerCase()) || doc.specialty.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesDept && matchesQuery;
  });

  const aiTopMatchDoctor = INITIAL_DOCTORS[0]; // Dr. Sarah Vance

  const handleConfirmBooking = (docToBook?: Doctor, slotToBook?: string) => {
    const doctor = docToBook || selectedDoctor;
    const slot = slotToBook || selectedSlot;

    if (!doctor || !slot) return;

    // Require Firebase account sign-in before booking
    if (!currentUser || currentUser.isAnonymous) {
      setShowAuthWarning(true);
      if (onOpenAuth) onOpenAuth();
      return;
    }

    const newApt: Appointment = {
      id: `apt-2026-${Math.floor(Math.random() * 8999 + 1000)}`,
      doctorName: doctor.name,
      doctorSpecialty: doctor.specialty,
      doctorAvatar: doctor.avatar,
      hospitalName: doctor.hospitalName,
      roomNumber: 'Suite 304 - Pod A',
      date: 'Today, Jul 25',
      time: slot,
      tokenNumber: `A-${Math.floor(Math.random() * 80 + 100)}`,
      status: 'In Queue',
      queuePosition: 3,
      estimatedWaitMins: doctor.estimatedWaitMins,
    };

    onBookAppointment(newApt);
    setBookingConfirmed(true);
    setShowAuthWarning(false);
  };

  return (
    <div className="min-h-full p-4 sm:p-6 text-white space-y-4 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 pb-20">
      
      {/* Top Header */}
      <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-widest">
            <Sparkles className="w-4 h-4" /> Screen 4
          </div>
          <h1 className="text-xl font-black text-white tracking-tight">
            Smart Appointment Booking
          </h1>
        </div>
        <span className="px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-xs text-cyan-300 font-semibold">
          AI Auto-Recommendation
        </span>
      </div>

      {/* User Auth Status Banner */}
      {(!currentUser || currentUser.isAnonymous) ? (
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-950/80 via-slate-900 to-amber-950/80 border border-amber-500/50 flex items-center justify-between gap-2 shadow-lg">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center shrink-0">
              <LogIn className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <p className="text-xs font-extrabold text-amber-200">Firebase Sign-In Required for Booking</p>
              <p className="text-[10px] text-amber-300/80">Sign in or create a free patient account to lock in appointment queue tokens.</p>
            </div>
          </div>
          <button
            onClick={onOpenAuth}
            className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs uppercase tracking-wider shrink-0 transition-all shadow-md"
          >
            Sign In / Up
          </button>
        </div>
      ) : (
        <div className="p-3 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-between text-xs text-cyan-200">
          <div className="flex items-center gap-2">
            <UserCheck className="w-4 h-4 text-emerald-400" />
            <span>Authenticated Patient: <strong className="text-white">{currentUser.displayName || currentUser.email}</strong></span>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
            Firebase Linked
          </span>
        </div>
      )}

      {/* AI Top Match Recommendation Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950 via-slate-900 to-blue-950 border-2 border-cyan-400/60 shadow-xl space-y-3 relative overflow-hidden">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-cyan-400 text-slate-950 font-black text-[10px] uppercase tracking-wider">
            <Sparkles className="w-3 h-3" /> 98% AI Match Recommendation
          </div>
          <span className="text-[10px] text-cyan-300 font-bold">Shortest Wait: 8 mins</span>
        </div>

        <div className="flex items-center gap-3">
          <img
            src={aiTopMatchDoctor.avatar}
            alt={aiTopMatchDoctor.name}
            className="w-14 h-14 rounded-2xl object-cover border-2 border-cyan-400"
          />
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-extrabold text-white truncate">
              {aiTopMatchDoctor.name}
            </h3>
            <p className="text-xs text-cyan-300 font-semibold">
              {aiTopMatchDoctor.specialty}
            </p>
            <div className="flex items-center gap-3 text-[11px] text-slate-300 mt-1">
              <span className="flex items-center gap-1 text-amber-400 font-bold">
                <Star className="w-3 h-3 fill-amber-400" /> {aiTopMatchDoctor.rating}
              </span>
              <span>{aiTopMatchDoctor.experienceYears} Yrs Exp</span>
              <span className="text-cyan-300 font-bold">${aiTopMatchDoctor.consultationFee} Fee</span>
            </div>
          </div>
        </div>

        <button
          onClick={() => {
            setSelectedDoctor(aiTopMatchDoctor);
            const slot = aiTopMatchDoctor.availableSlots[0];
            setSelectedSlot(slot);
            handleConfirmBooking(aiTopMatchDoctor, slot);
          }}
          className="w-full py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-md"
        >
          Book Recommended Doctor & Slot ({aiTopMatchDoctor.availableSlots[0]})
        </button>
      </div>

      {/* Search & Department Filters */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search doctor name or medical specialty..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
          />
        </div>

        {/* Department Chips */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {departments.map((dept) => (
            <button
              key={dept}
              onClick={() => setSelectedDept(dept)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedDept === dept
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
              }`}
            >
              {dept}
            </button>
          ))}
        </div>
      </div>

      {/* Doctor Cards List */}
      <div className="space-y-3">
        {filteredDoctors.map((doc) => (
          <div
            key={doc.id}
            className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/40 shadow-lg transition-all space-y-3"
          >
            <div className="flex items-start justify-between">
              <div className="flex gap-3">
                <img
                  src={doc.avatar}
                  alt={doc.name}
                  className="w-12 h-12 rounded-xl object-cover border border-slate-700"
                />
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-white">
                    {doc.name}
                  </h3>
                  <p className="text-[11px] text-cyan-300 font-medium">
                    {doc.specialty}
                  </p>
                  <p className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3 h-3 text-slate-500" />
                    {doc.hospitalName} ({doc.distanceMiles} mi)
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="text-sm font-black text-cyan-300">${doc.consultationFee}</span>
                <span className="block text-[10px] text-slate-400">per visit</span>
              </div>
            </div>

            {/* Metrics & Rating */}
            <div className="grid grid-cols-3 gap-2 p-2 rounded-xl bg-slate-950/80 text-[10px] text-center border border-slate-800">
              <div>
                <span className="text-slate-400 block">Rating</span>
                <span className="font-extrabold text-amber-300 flex items-center justify-center gap-0.5">
                  <Star className="w-2.5 h-2.5 fill-amber-300" /> {doc.rating}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Est. Wait</span>
                <span className="font-extrabold text-cyan-300 flex items-center justify-center gap-0.5">
                  <Clock className="w-2.5 h-2.5 text-cyan-400" /> {doc.estimatedWaitMins}m
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Status</span>
                <span className={`font-extrabold ${doc.status === 'Available' ? 'text-emerald-400' : 'text-amber-300'}`}>
                  {doc.status}
                </span>
              </div>
            </div>

            {/* Time Slot Selector Chips */}
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-slate-400">Available Time Slots Today:</span>
              <div className="flex flex-wrap gap-1.5">
                {doc.availableSlots.map((slot) => {
                  const isSelected = selectedDoctor?.id === doc.id && selectedSlot === slot;
                  return (
                    <button
                      key={slot}
                      onClick={() => {
                        setSelectedDoctor(doc);
                        setSelectedSlot(slot);
                      }}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                        isSelected
                          ? 'bg-cyan-400 text-slate-950 font-bold ring-2 ring-cyan-300'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {slot}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Select & Book Button */}
            <button
              onClick={() => {
                setSelectedDoctor(doc);
                const slotToUse = (selectedDoctor?.id === doc.id && selectedSlot) ? selectedSlot : doc.availableSlots[0];
                setSelectedSlot(slotToUse);
                handleConfirmBooking(doc, slotToUse);
              }}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-cyan-300 font-bold text-xs border border-cyan-500/30 flex items-center justify-center gap-1.5 transition-all"
            >
              <Calendar className="w-3.5 h-3.5" />
              Book Appointment with {doc.name.split(',')[0]}
            </button>
          </div>
        ))}
      </div>

      {/* Booking Confirmation Modal */}
      {bookingConfirmed && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-sm bg-slate-900 border-2 border-cyan-400 rounded-3xl p-6 text-white text-center shadow-2xl">
            <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-9 h-9 text-emerald-400 animate-bounce" />
            </div>

            <h2 className="text-xl font-extrabold text-white">
              Appointment Confirmed!
            </h2>
            <p className="text-xs text-slate-300 mt-1">
              Your spot in the AI predictive queue is locked in.
            </p>

            <div className="my-4 p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-left space-y-1.5">
              <p className="text-slate-300"><span className="text-slate-400">Doctor:</span> <strong className="text-cyan-300">{selectedDoctor?.name}</strong></p>
              <p className="text-slate-300"><span className="text-slate-400">Time Slot:</span> <strong className="text-white">{selectedSlot}</strong></p>
              <p className="text-slate-300"><span className="text-slate-400">Hospital:</span> <strong className="text-slate-200">{selectedDoctor?.hospitalName}</strong></p>
              <p className="text-slate-300"><span className="text-slate-400">Queue Token:</span> <strong className="text-cyan-300 font-mono">A-104 (#3 in line)</strong></p>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => {
                  setBookingConfirmed(false);
                  setActiveScreen('queueTracker');
                }}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-lg shadow-cyan-500/30"
              >
                Track Live Queue (Screen 5) <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
