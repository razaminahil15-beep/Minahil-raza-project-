import React, { useState } from 'react';
import { ScreenId } from '../../types';
import { 
  Sparkles, 
  Shield, 
  ArrowRight, 
  Bot, 
  Globe, 
  CheckCircle2, 
  LogIn, 
  Zap, 
  HeartPulse, 
  Calendar, 
  Activity, 
  ShieldAlert, 
  Lock, 
  ChevronRight, 
  Volume2, 
  TrendingDown
} from 'lucide-react';

interface WelcomeScreenProps {
  setActiveScreen: (screen: ScreenId) => void;
  onOpenQr?: () => void;
  onOpenSos?: () => void;
  currentUser?: any;
  onOpenAuth?: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ 
  setActiveScreen,
  onOpenSos,
  currentUser,
  onOpenAuth
}) => {
  const [selectedLanguage, setSelectedLanguage] = useState('English');
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [isCreateAccount, setIsCreateAccount] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [greetingAudioPlaying, setGreetingAudioPlaying] = useState(false);

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowLoginModal(false);
    setActiveScreen('dashboard');
  };

  const playAiGreeting = () => {
    if (greetingAudioPlaying) {
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
      setGreetingAudioPlaying(false);
      return;
    }
    setGreetingAudioPlaying(true);
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance("Hello Minahil Raza! Welcome to MediFlow AI. Your smart healthcare portal is ready. Skip hospital queues and get instant AI health triage.");
      utterance.pitch = 1.1;
      utterance.rate = 0.95;
      utterance.onend = () => setGreetingAudioPlaying(false);
      utterance.onerror = () => setGreetingAudioPlaying(false);
      window.speechSynthesis.speak(utterance);
    } else {
      setTimeout(() => setGreetingAudioPlaying(false), 3000);
    }
  };

  return (
    <div className="relative min-h-full flex flex-col justify-between p-4 sm:p-6 text-white overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      
      {/* Background Animated Futuristic Glow & Grid Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-900/30 via-slate-950 to-slate-950 pointer-events-none" />
      <div className="absolute top-12 left-1/2 -translate-x-1/2 w-96 h-96 bg-cyan-500/15 rounded-full blur-[100px] pointer-events-none animate-pulse" />
      <div className="absolute bottom-10 right-0 w-80 h-80 bg-blue-600/10 rounded-full blur-[90px] pointer-events-none" />
      <div className="absolute top-1/3 -left-20 w-72 h-72 bg-indigo-600/10 rounded-full blur-[90px] pointer-events-none" />

      {/* Top Header Bar */}
      <div className="relative z-10 flex items-center justify-between gap-2 pb-2">
        {/* Brand Badge */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 border border-cyan-500/40 text-xs font-bold text-cyan-300 shadow-lg shadow-cyan-500/10 backdrop-blur-md">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[11px]">MediFlow AI v4.2</span>
        </div>

        {/* Right Tools: Language & SOS */}
        <div className="flex items-center gap-2">
          {/* Language Selector */}
          <div className="flex items-center gap-1.5 bg-slate-900/90 border border-slate-700/80 rounded-xl px-2.5 py-1 text-xs text-slate-300 backdrop-blur-md">
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="bg-transparent text-xs text-slate-200 focus:outline-none cursor-pointer pr-1 font-medium"
            >
              <option value="English" className="bg-slate-900">English</option>
              <option value="Español" className="bg-slate-900">Español</option>
              <option value="Français" className="bg-slate-900">Français</option>
              <option value="Urdu" className="bg-slate-900">Urdu (اردو)</option>
              <option value="Arabic" className="bg-slate-900">Arabic (العربية)</option>
            </select>
          </div>

          {/* SOS Trigger */}
          {onOpenSos && (
            <button
              onClick={onOpenSos}
              className="p-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/50 text-rose-300 transition-all flex items-center gap-1 text-xs font-extrabold"
              title="Emergency SOS"
            >
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <span className="hidden sm:inline">SOS</span>
            </button>
          )}
        </div>
      </div>

      {/* Hero Welcome Card for Minahil Raza */}
      <div className="relative z-10 my-auto py-2 text-center space-y-4">
        
        {/* User Greeting Pill Banner */}
        <div className="inline-flex items-center gap-3 px-4 py-2 rounded-2xl bg-gradient-to-r from-cyan-950/90 via-slate-900/90 to-blue-950/90 border border-cyan-400/50 text-cyan-200 text-xs font-bold shadow-xl shadow-cyan-500/20 backdrop-blur-md">
          <div className="relative w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-400 to-blue-600 p-0.5 shadow-md">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150"
              alt="Minahil Raza"
              className="w-full h-full object-cover rounded-full"
            />
            <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 rounded-full border border-slate-950 animate-ping" />
            <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 rounded-full border border-slate-950" />
          </div>
          <div className="text-left">
            <div className="text-[10px] text-cyan-400 font-extrabold uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-cyan-300 animate-pulse" /> Verified Patient Account
            </div>
            <span className="text-sm font-black text-white tracking-tight">Hello, Minahil Raza</span>
          </div>
        </div>

        {/* Holographic AI Avatar & Audio Player */}
        <div className="relative inline-block my-2">
          <div className="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-600 blur-xl opacity-50 animate-pulse" />
          
          <div className="relative w-24 h-24 mx-auto rounded-full bg-slate-900 border-2 border-cyan-400/80 p-1 flex items-center justify-center shadow-2xl shadow-cyan-500/50">
            <div className="w-full h-full rounded-full bg-gradient-to-tr from-cyan-950 via-slate-900 to-blue-950 flex flex-col items-center justify-center relative overflow-hidden">
              <Bot className="w-10 h-10 text-cyan-300 animate-bounce" />
              <div className="absolute bottom-1 px-2 py-0.5 rounded-full bg-cyan-500/20 text-[9px] font-extrabold text-cyan-300 border border-cyan-400/40">
                MediBot AI
              </div>
            </div>
          </div>

          {/* Audio Voice Greeting Button */}
          <button
            onClick={playAiGreeting}
            className={`absolute -bottom-1 -right-1 p-2 rounded-full border shadow-xl text-xs font-bold transition-all ${
              greetingAudioPlaying
                ? 'bg-cyan-400 text-slate-950 border-white scale-110 animate-pulse'
                : 'bg-slate-800 text-cyan-300 border-cyan-500/50 hover:bg-slate-700 hover:scale-105'
            }`}
            title="Listen to AI Voice Greeting"
          >
            {greetingAudioPlaying ? <Volume2 className="w-4 h-4 text-slate-950" /> : <HeartPulse className="w-4 h-4 text-cyan-300" />}
          </button>
        </div>

        {/* Hero Main Headline & Slogan */}
        <div className="space-y-2 max-w-md mx-auto">
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white leading-tight">
            Skip the Hospital Queue.<br />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-blue-300 to-indigo-400">
              Smart Healthcare AI.
            </span>
          </h1>
          
          <p className="text-xs sm:text-sm font-semibold text-cyan-200/90 leading-relaxed max-w-sm mx-auto">
            Predictive token allocation, instant AI symptom triage, and real-time hospital wait times in 2026.
          </p>
        </div>

        {/* Live Hospital Telemetry Banner */}
        <div className="p-3 rounded-2xl bg-slate-900/80 border border-cyan-500/30 max-w-xs mx-auto flex items-center justify-between text-xs backdrop-blur-md shadow-lg">
          <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-[11px]">
            <TrendingDown className="w-4 h-4 text-emerald-400" />
            <span>Avg Wait Time: <strong className="font-mono text-white">12 Mins</strong></span>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 font-bold">
            98.4% Accuracy
          </span>
        </div>

        {/* Quick Action Navigation Grid (4 Core Services) */}
        <div className="grid grid-cols-2 gap-2.5 max-w-sm mx-auto pt-2 text-left">
          
          {/* Card 1: Health Checker */}
          <button
            onClick={() => setActiveScreen('healthCheck')}
            className="p-3 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-cyan-950/60 border border-cyan-500/30 hover:border-cyan-400 transition-all space-y-1 group shadow-md"
          >
            <div className="flex items-center justify-between">
              <div className="w-7 h-7 rounded-xl bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 group-hover:scale-110 transition-transform">
                <Bot className="w-4 h-4" />
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-300 transition-colors" />
            </div>
            <h4 className="text-xs font-black text-white group-hover:text-cyan-300 transition-colors">AI Health Triage</h4>
            <p className="text-[10px] text-slate-400 line-clamp-1">Symptom check & doctor match</p>
          </button>

          {/* Card 2: Book Doctor */}
          <button
            onClick={() => setActiveScreen('booking')}
            className="p-3 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-blue-950/60 border border-blue-500/30 hover:border-blue-400 transition-all space-y-1 group shadow-md"
          >
            <div className="flex items-center justify-between">
              <div className="w-7 h-7 rounded-xl bg-blue-500/20 border border-blue-400 flex items-center justify-center text-blue-300 group-hover:scale-110 transition-transform">
                <Calendar className="w-4 h-4" />
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-blue-300 transition-colors" />
            </div>
            <h4 className="text-xs font-black text-white group-hover:text-blue-300 transition-colors">Doctor Booking</h4>
            <p className="text-[10px] text-slate-400 line-clamp-1">Lock queue slots & tokens</p>
          </button>

          {/* Card 3: Live Queue Dashboard */}
          <button
            onClick={() => setActiveScreen('dashboard')}
            className="p-3 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-teal-950/60 border border-teal-500/30 hover:border-teal-400 transition-all space-y-1 group shadow-md"
          >
            <div className="flex items-center justify-between">
              <div className="w-7 h-7 rounded-xl bg-teal-500/20 border border-teal-400 flex items-center justify-center text-teal-300 group-hover:scale-110 transition-transform">
                <Activity className="w-4 h-4" />
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-teal-300 transition-colors" />
            </div>
            <h4 className="text-xs font-black text-white group-hover:text-teal-300 transition-colors">Live Queue Tracker</h4>
            <p className="text-[10px] text-slate-400 line-clamp-1">Real-time room & wait status</p>
          </button>

          {/* Card 4: Health Records Wallet */}
          <button
            onClick={() => setActiveScreen('records')}
            className="p-3 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/60 border border-indigo-500/30 hover:border-indigo-400 transition-all space-y-1 group shadow-md"
          >
            <div className="flex items-center justify-between">
              <div className="w-7 h-7 rounded-xl bg-indigo-500/20 border border-indigo-400 flex items-center justify-center text-indigo-300 group-hover:scale-110 transition-transform">
                <Shield className="w-4 h-4" />
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-indigo-300 transition-colors" />
            </div>
            <h4 className="text-xs font-black text-white group-hover:text-indigo-300 transition-colors">Health Wallet</h4>
            <p className="text-[10px] text-slate-400 line-clamp-1">Digital pass & prescriptions</p>
          </button>

        </div>

      </div>

      {/* Main Bottom Call To Action Section */}
      <div className="relative z-10 space-y-2.5 pt-2 max-w-sm mx-auto w-full">
        
        {/* Primary Giant Action Button */}
        <button
          onClick={() => setActiveScreen('healthCheck')}
          className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-black text-xs sm:text-sm tracking-wide uppercase shadow-xl shadow-cyan-500/30 border border-cyan-300/40 flex items-center justify-center gap-2 transition-all transform hover:scale-[1.02] active:scale-98"
        >
          <Bot className="w-5 h-5 text-slate-950" />
          <span>Launch AI Symptom Triage</span>
          <ArrowRight className="w-4 h-4 text-slate-950 ml-auto" />
        </button>

        {/* Secondary Row: Smart Hospital Patient Dashboard */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveScreen('dashboard')}
            className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-cyan-500/30 text-cyan-300 font-extrabold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md"
          >
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            Patient Dashboard
          </button>
        </div>

        {/* Footer Account Status / Sign In prompt */}
        <div className="pt-1 text-center">
          {currentUser && !currentUser.isAnonymous ? (
            <div className="inline-flex items-center gap-1.5 text-[11px] text-emerald-300 font-bold bg-emerald-950/50 border border-emerald-500/30 px-3 py-1 rounded-full">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Signed In: {currentUser.email || 'Minahil Raza'}</span>
            </div>
          ) : (
            <button
              onClick={() => {
                if (onOpenAuth) onOpenAuth();
                else setShowLoginModal(true);
              }}
              className="text-xs text-slate-400 hover:text-cyan-300 underline font-medium transition-colors inline-flex items-center gap-1"
            >
              <LogIn className="w-3.5 h-3.5 text-cyan-400" />
              Sign in / Create Firebase Account for persistent tokens
            </button>
          )}
        </div>

      </div>

      {/* Auth Modal Fallback */}
      {showLoginModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-sm bg-slate-900 border border-cyan-500/40 rounded-3xl p-6 text-white shadow-2xl space-y-4">
            <div>
              <h3 className="text-base font-black text-white">
                {isCreateAccount ? 'Create MediFlow Account' : 'Sign In to MediFlow AI'}
              </h3>
              <p className="text-xs text-slate-400">
                {isCreateAccount ? 'Sync your health telemetry & priority queue tokens.' : 'Access your digital medical records and appointments.'}
              </p>
            </div>

            <form onSubmit={handleAuthSubmit} className="space-y-3 text-left">
              <div>
                <label className="text-xs font-bold text-slate-300">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="razaminahil15@gmail.com"
                  className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300">Password</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setShowLoginModal(false)}
                  className="text-xs text-slate-400 hover:text-white font-bold"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black text-xs uppercase shadow-md shadow-cyan-500/30"
                >
                  {isCreateAccount ? 'Create Account' : 'Sign In'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
