import React, { useState, useEffect } from 'react';
import { ScreenId, Appointment } from '../../types';
import { INITIAL_APPOINTMENT, DAILY_HEALTH_TIPS } from '../../data/mockData';
import { notificationService } from '../../services/notificationService';
import { Sparkles, Clock, Calendar, QrCode, ShieldAlert, Heart, Activity, Pill, CheckCircle2, ChevronRight, Stethoscope, User, Zap, MessageSquareCode, Bell, Star } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

interface DashboardScreenProps {
  setActiveScreen: (screen: ScreenId) => void;
  onOpenQr: () => void;
  onOpenSos: () => void;
  appointment?: Appointment;
  onOpenFeedback?: () => void;
}

const HEALTH_TELEMETRY = [
  { time: '06:00', bpm: 62, spo2: 99 },
  { time: '08:00', bpm: 68, spo2: 98 },
  { time: '10:00', bpm: 74, spo2: 99 },
  { time: '12:00', bpm: 71, spo2: 99 },
  { time: '14:00', bpm: 69, spo2: 98 },
  { time: '16:00', bpm: 65, spo2: 99 },
];

export const DashboardScreen: React.FC<DashboardScreenProps> = ({
  setActiveScreen,
  onOpenQr,
  onOpenSos,
  appointment = INITIAL_APPOINTMENT,
  onOpenFeedback,
}) => {
  const [medsTaken, setMedsTaken] = useState<{ [key: string]: boolean }>({
    'med-1': true,
    'med-2': false,
  });
  const [streakCount, setStreakCount] = useState(14);
  const [secondsRemaining, setSecondsRemaining] = useState(700); // ~11 mins 40 secs
  const [currentTipIndex, setCurrentTipIndex] = useState(0);

  // Live countdown timer for queue position
  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsRemaining((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatCountdown = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins}m ${secs < 10 ? '0' : ''}${secs}s`;
  };

  const toggleMed = (id: string) => {
    setMedsTaken((prev) => {
      const nextState = !prev[id];
      if (nextState) setStreakCount((s) => s + 1);
      return { ...prev, [id]: nextState };
    });
  };

  return (
    <div className="min-h-full p-4 sm:p-6 text-white space-y-4 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 pb-20">
      
      {/* Top Welcome Bar */}
      <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 p-0.5 shadow-md shadow-cyan-500/30">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150"
              alt="Minahil Raza"
              className="w-full h-full object-cover rounded-full"
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5 text-[11px] font-bold text-cyan-400">
              <Sparkles className="w-3 h-3 text-cyan-300 animate-pulse" /> Smart Dashboard
            </div>
            <h1 className="text-base sm:text-lg font-black text-white tracking-tight">Hello, Minahil Raza</h1>
          </div>
        </div>

        {/* SOS Quick Button with subtle pulsing animation */}
        <button
          onClick={onOpenSos}
          className="relative group px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-rose-600 via-red-600 to-rose-600 border border-rose-400/60 text-white font-extrabold text-xs flex items-center gap-1.5 hover:from-rose-500 hover:to-red-500 transition-all shadow-lg shadow-rose-600/40 hover:scale-105 active:scale-95"
          title="Emergency SOS Dispatch"
        >
          {/* Subtle pulsing ambient halo */}
          <span className="absolute -inset-0.5 rounded-xl bg-rose-500/50 blur-sm animate-pulse pointer-events-none" />
          <ShieldAlert className="w-4 h-4 animate-bounce text-white relative z-10" />
          <span className="relative z-10 font-black tracking-wider">SOS</span>
          <span className="relative z-10 w-2 h-2 rounded-full bg-white animate-ping" />
        </button>
      </div>

      {/* AI Health Score & Live Status Row */}
      <div className="grid grid-cols-2 gap-3">
        
        {/* AI Health Score Circle Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border border-cyan-500/30 shadow-xl flex flex-col items-center justify-center text-center relative overflow-hidden group">
          <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded-full bg-cyan-500/20 text-[9px] font-extrabold text-cyan-300 border border-cyan-400/30">
            EXCELLENT
          </div>

          <div className="relative my-2 w-16 h-16 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="5" className="text-slate-800" fill="transparent" />
              <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="5" className="text-cyan-400" strokeDasharray={175} strokeDashoffset={10} strokeLinecap="round" fill="transparent" />
            </svg>
            <span className="absolute font-mono font-black text-lg text-white">
              94
            </span>
          </div>

          <span className="text-[11px] font-bold text-slate-300">AI Health Score</span>
          <span className="text-[9px] text-slate-400 mt-0.5">+2% from last week</span>
        </div>

        {/* Live Queue Counter Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-950/60 via-slate-900 to-slate-900 border border-cyan-500/40 shadow-xl flex flex-col justify-between relative overflow-hidden">
          <div className="flex items-center justify-between text-xs">
            <span className="font-extrabold text-cyan-300 uppercase tracking-wide flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-cyan-400" /> Live Queue
            </span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-[10px] border border-emerald-500/30">
              Active
            </span>
          </div>

          <div className="my-1">
            <div className="text-2xl font-black text-white flex items-baseline gap-1">
              #3 <span className="text-xs font-normal text-slate-400">in queue</span>
            </div>
            <div className="text-xs font-mono font-extrabold text-amber-300">
              ~{formatCountdown(secondsRemaining)}
            </div>
          </div>

          <button
            onClick={() => setActiveScreen('queueTracker')}
            className="w-full py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30 text-[10px] font-bold flex items-center justify-center gap-1 transition-all"
          >
            Track Live (Screen 5) <ChevronRight className="w-3 h-3" />
          </button>
        </div>

      </div>

      {/* Today's Appointment Card */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/40 shadow-xl space-y-3 relative overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-extrabold text-white">Today's Appointment</span>
            {appointment.feedbackSubmitted && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                <Star className="w-3 h-3 fill-amber-400 text-amber-400" /> Rated {appointment.rating}/5
              </span>
            )}
          </div>
          <button
            onClick={onOpenQr}
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-cyan-500 text-slate-950 font-extrabold text-[11px] shadow-sm hover:bg-cyan-400 transition-all"
          >
            <QrCode className="w-3.5 h-3.5" /> Check-In QR
          </button>
        </div>

        <div className="flex items-center gap-3">
          <img
            src={appointment.doctorAvatar}
            alt={appointment.doctorName}
            className="w-12 h-12 rounded-xl object-cover border border-cyan-500/40"
          />
          <div className="flex-1 min-w-0">
            <h3 className="text-xs sm:text-sm font-bold text-white truncate">
              {appointment.doctorName}
            </h3>
            <p className="text-[11px] text-cyan-300 font-medium truncate">
              {appointment.doctorSpecialty}
            </p>
            <p className="text-[10px] text-slate-400 truncate mt-0.5">
              {appointment.hospitalName} • {appointment.roomNumber}
            </p>
          </div>
        </div>

        <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-400 font-medium">Slot Time: <strong className="text-white">{appointment.time}</strong></span>
          <span className="text-slate-400 font-medium">Token: <strong className="text-cyan-300 font-mono">{appointment.tokenNumber}</strong></span>
        </div>

        {/* Post-Appointment Doctor Feedback CTA */}
        {onOpenFeedback && (
          <div className="pt-1">
            {appointment.feedbackSubmitted ? (
              <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs flex items-center justify-between">
                <span className="flex items-center gap-1.5 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Doctor Review Recorded
                </span>
                <button
                  onClick={onOpenFeedback}
                  className="text-[11px] font-extrabold text-cyan-300 hover:underline"
                >
                  View / Edit
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenFeedback}
                className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-amber-500/20 via-yellow-500/20 to-amber-500/20 border border-amber-500/40 text-amber-300 hover:bg-amber-500/30 font-extrabold text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-98"
              >
                <Star className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
                Rate Consultation & Doctor Experience
              </button>
            )}
          </div>
        )}
      </div>

      {/* Medication Reminders Checklist */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Pill className="w-4 h-4 text-indigo-400" />
            <span className="text-xs font-extrabold text-white">Medication Reminders</span>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] font-bold border border-indigo-500/30">
            🔥 {streakCount} Day Streak
          </span>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => toggleMed('med-1')}
                className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all ${
                  medsTaken['med-1']
                    ? 'bg-emerald-500 border-emerald-400 text-slate-950'
                    : 'bg-slate-900 border-slate-700 text-transparent'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
              </button>
              <div>
                <span className={`font-bold block text-xs ${medsTaken['med-1'] ? 'line-through text-slate-500' : 'text-white'}`}>
                  Amoxicillin 500mg
                </span>
                <span className="text-[10px] text-slate-400">08:00 AM • After Breakfast</span>
              </div>
            </div>
            <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
              {medsTaken['med-1'] ? 'Taken' : 'Due'}
            </span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => toggleMed('med-2')}
                className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all ${
                  medsTaken['med-2']
                    ? 'bg-emerald-500 border-emerald-400 text-slate-950'
                    : 'bg-slate-900 border-slate-700 text-transparent'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
              </button>
              <div>
                <span className={`font-bold block text-xs ${medsTaken['med-2'] ? 'line-through text-slate-500' : 'text-white'}`}>
                  Multivitamin + Zinc
                </span>
                <span className="text-[10px] text-slate-400">08:00 PM • After Dinner</span>
              </div>
            </div>
            <span className="text-[10px] font-semibold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded">
              {medsTaken['med-2'] ? 'Taken' : 'Upcoming'}
            </span>
          </div>
        </div>
      </div>

      {/* Animated Health Statistics Chart */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-2">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 font-bold text-white">
            <Activity className="w-4 h-4 text-cyan-400" /> Vitals Telemetry (Heart Rate BPM)
          </div>
          <span className="text-cyan-300 font-mono text-[11px] font-extrabold">69 avg bpm</span>
        </div>

        <div className="h-28 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={HEALTH_TELEMETRY}>
              <defs>
                <linearGradient id="bpmGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00F2FE" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#00F2FE" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="time" stroke="#64748b" fontSize={10} tickLine={false} />
              <YAxis stroke="#64748b" fontSize={10} domain={[50, 90]} hide />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }}
              />
              <Area type="monotone" dataKey="bpm" stroke="#00F2FE" strokeWidth={2.5} fillOpacity={1} fill="url(#bpmGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Daily AI Health Tip Card */}
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-950/80 to-indigo-950/80 border border-indigo-500/30 text-xs flex items-start gap-2.5">
        <Sparkles className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5 animate-pulse" />
        <div className="flex-1">
          <span className="font-bold text-cyan-300 block mb-0.5">Daily AI Health Tip</span>
          <p className="text-slate-300 leading-snug">
            {DAILY_HEALTH_TIPS[currentTipIndex]}
          </p>
        </div>
        <button
          onClick={() => setCurrentTipIndex((prev) => (prev + 1) % DAILY_HEALTH_TIPS.length)}
          className="text-[10px] text-cyan-400 underline shrink-0 hover:text-white"
        >
          Next Tip
        </button>
      </div>

      {/* Quick Action Grid */}
      <div className="grid grid-cols-4 gap-2 pt-1">
        <button
          onClick={() => setActiveScreen('healthCheck')}
          className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 flex flex-col items-center text-center gap-1 transition-all"
        >
          <Stethoscope className="w-5 h-5 text-cyan-400" />
          <span className="text-[10px] font-bold text-slate-300">Symptom Check</span>
        </button>

        <button
          onClick={() => setActiveScreen('booking')}
          className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 flex flex-col items-center text-center gap-1 transition-all"
        >
          <Calendar className="w-5 h-5 text-blue-400" />
          <span className="text-[10px] font-bold text-slate-300">Book Doctor</span>
        </button>

        <button
          onClick={() => setActiveScreen('wallet')}
          className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 flex flex-col items-center text-center gap-1 transition-all"
        >
          <User className="w-5 h-5 text-indigo-400" />
          <span className="text-[10px] font-bold text-slate-300">Medical History</span>
        </button>

        <button
          onClick={() => setActiveScreen('aiAssistant')}
          className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 flex flex-col items-center text-center gap-1 transition-all"
        >
          <MessageSquareCode className="w-5 h-5 text-teal-400" />
          <span className="text-[10px] font-bold text-slate-300">AI Assistant</span>
        </button>
      </div>

    </div>
  );
};
