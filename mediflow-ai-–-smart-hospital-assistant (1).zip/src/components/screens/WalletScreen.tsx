import React, { useState, useEffect } from 'react';
import { ScreenId, MedicalRecord, ConsultationSummary } from '../../types';
import { INITIAL_MEDICAL_RECORDS, INITIAL_CONSULTATION_SUMMARIES } from '../../data/mockData';
import { fetchUserMedicalRecords, saveMedicalRecordToFirestore } from '../../services/firestoreService';
import { Sparkles, ShieldCheck, QrCode, FileText, Download, Plus, Eye, Lock, CheckCircle2, Cloud, HardDrive, X, Stethoscope, Search, Calendar, UserCheck, Heart, Activity, Pill, Share2, Printer, FileBadge, Check, ChevronRight } from 'lucide-react';

interface WalletScreenProps {
  setActiveScreen: (screen: ScreenId) => void;
  onOpenQr: () => void;
}

export const WalletScreen: React.FC<WalletScreenProps> = ({
  setActiveScreen,
  onOpenQr,
}) => {
  // Main Navigation Tabs: Medical History vs Documents Vault
  const [mainSection, setMainSection] = useState<'medicalHistory' | 'vault'>('medicalHistory');

  // Vault Tab State
  const [activeTab, setActiveTab] = useState<'All' | 'Prescription' | 'Lab Report' | 'Vaccination' | 'Insurance' | 'Scan'>('All');
  const [records, setRecords] = useState<MedicalRecord[]>(INITIAL_MEDICAL_RECORDS);
  const [viewingRecord, setViewingRecord] = useState<MedicalRecord | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<'Prescription' | 'Lab Report' | 'Vaccination' | 'Insurance' | 'Scan'>('Lab Report');

  // Medical History Tab State
  const [consultations, setConsultations] = useState<ConsultationSummary[]>(INITIAL_CONSULTATION_SUMMARIES);
  const [viewingConsultation, setViewingConsultation] = useState<ConsultationSummary | null>(null);
  const [departmentFilter, setDepartmentFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Compile New Report Modal State
  const [showCompileModal, setShowCompileModal] = useState(false);
  const [newDoctorName, setNewDoctorName] = useState('Dr. Sarah Vance, MD');
  const [newDepartment, setNewDepartment] = useState('Cardiology');
  const [newChiefComplaint, setNewChiefComplaint] = useState('Routine bi-annual cardiovascular checkup & ECG review.');
  const [newDiagnosis, setNewDiagnosis] = useState('Normal Sinus Rhythm - Optimal Heart Function');
  const [isCompiling, setIsCompiling] = useState(false);

  useEffect(() => {
    fetchUserMedicalRecords().then((fetched) => {
      if (fetched && fetched.length > 0) {
        setRecords((prev) => {
          const merged = [...fetched];
          prev.forEach((p) => {
            if (!merged.some((m) => m.id === p.id)) {
              merged.push(p);
            }
          });
          return merged;
        });
      }
    });
  }, []);

  const filteredRecords = activeTab === 'All' ? records : records.filter((r) => r.category === activeTab);

  // Filter consultations by department and search query
  const filteredConsultations = consultations.filter((c) => {
    const matchesDept = departmentFilter === 'All' || c.department.toLowerCase().includes(departmentFilter.toLowerCase());
    const query = searchQuery.toLowerCase();
    const matchesQuery = !query || 
      c.doctorName.toLowerCase().includes(query) ||
      c.diagnosis.toLowerCase().includes(query) ||
      c.chiefComplaint.toLowerCase().includes(query) ||
      c.id.toLowerCase().includes(query);
    return matchesDept && matchesQuery;
  });

  const handleAddDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle) return;

    const newDoc: MedicalRecord = {
      id: `rec-${Math.floor(Math.random() * 8999 + 1000)}`,
      title: newTitle,
      category: newCategory,
      date: 'Today, Jul 25, 2026',
      details: 'Digitally uploaded and encrypted via MediFlow Biometric Vault.',
      fileSize: '1.2 MB'
    };

    setRecords([newDoc, ...records]);
    saveMedicalRecordToFirestore(newDoc);
    setNewTitle('');
    setShowAddModal(false);
  };

  // Trigger Download for a Consultation Summary Report
  const downloadConsultationReport = (summary: ConsultationSummary) => {
    const reportText = `===============================================================
MEDIFLOW SMART HOSPITAL NETWORK
DIGITAL CLINICAL CONSULTATION REPORT & MEDICAL HISTORY SUMMARY
===============================================================
Consultation ID: ${summary.id}
Date & Time: ${summary.consultationDate}
Verification Status: VERIFIED & DIGITALLY SIGNED (100% AUTHENTIC)

PATIENT DEMOGRAPHICS:
-------------------
Patient Name: Minahil Raza
Patient ID: #MF-99201-X
Blood Type: O Positive
Allergies: Penicillin
Primary Clinic: MediFlow Central Tech Hospital

ATTENDING CLINICIAN:
-------------------
Doctor: ${summary.doctorName}
Title: ${summary.doctorTitle}
Department: ${summary.department}

CLINICAL PRESENTATION & DIAGNOSIS:
--------------------------------
Chief Complaint: ${summary.chiefComplaint}
Primary Diagnosis: ${summary.diagnosis}

TELEMETRY & VITAL SIGNS:
-----------------------
Blood Pressure: ${summary.vitalSigns.bloodPressure}
Heart Rate: ${summary.vitalSigns.heartRate}
Oxygen Saturation (SpO2): ${summary.vitalSigns.spO2}
Temperature: ${summary.vitalSigns.temperature}

PRESCRIBED MEDICATIONS & REGIMEN:
--------------------------------
${summary.prescribedMedications.map((m, idx) => `${idx + 1}. ${m.name} (${m.dosage})\n   Instructions: ${m.instructions}`).join('\n')}

CLINICAL FINDINGS & EVALUATION NOTES:
------------------------------------
${summary.clinicalNotes}

FOLLOW-UP PLAN & RECOMMENDATIONS:
--------------------------------
${summary.followUpInstructions}

===============================================================
CRYPTOGRAPHIC VERIFICATION CODE: MF-VAULT-${summary.id}-2026
Digitally Signed by ${summary.doctorName} via MediFlow AI Security Node.
===============================================================`;

    const blob = new Blob([reportText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MediFlow_Consultation_Report_${summary.id}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Copy share link helper
  const handleCopyShareLink = (id: string) => {
    navigator.clipboard?.writeText(`https://mediflow-health.app/history/report/${id}`);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  // Compile new consultation summary handler
  const handleCompileReport = (e: React.FormEvent) => {
    e.preventDefault();
    setIsCompiling(true);

    setTimeout(() => {
      const newReport: ConsultationSummary = {
        id: `CONS-2026-${Math.floor(Math.random() * 8999 + 1000)}`,
        consultationDate: 'July 25, 2026 • 09:30 AM',
        doctorName: newDoctorName,
        doctorTitle: 'Attending Specialist & Consultant',
        department: newDepartment,
        doctorAvatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300',
        chiefComplaint: newChiefComplaint,
        diagnosis: newDiagnosis,
        vitalSigns: {
          bloodPressure: '120/80 mmHg',
          heartRate: '70 bpm',
          spO2: '99%',
          temperature: '98.6 °F'
        },
        prescribedMedications: [
          { name: 'Multivitamin Hydration Pack', dosage: '1 Sachet', instructions: 'Dissolve in 500ml water daily morning.' }
        ],
        clinicalNotes: 'Comprehensive digital consultation compiled using AI Vitals Telemetry and verified clinical notes. Patient shows stable hemodynamics.',
        followUpInstructions: 'Follow up in 3 months or as needed for routine wellness tracking.'
      };

      setConsultations([newReport, ...consultations]);
      setIsCompiling(false);
      setShowCompileModal(false);
      setViewingConsultation(newReport);
    }, 1500);
  };

  return (
    <div className="min-h-full p-4 sm:p-6 text-white space-y-4 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 pb-20">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-widest">
            <Sparkles className="w-4 h-4" /> Screen 6
          </div>
          <h1 className="text-xl font-black text-white tracking-tight">
            Medical History & Health Wallet
          </h1>
        </div>
        <button
          onClick={onOpenQr}
          className="px-3 py-1.5 rounded-xl bg-cyan-500 text-slate-950 font-extrabold text-xs flex items-center gap-1 shadow-md shadow-cyan-500/30 hover:bg-cyan-400 transition-all"
        >
          <QrCode className="w-4 h-4" /> Hospital QR Pass
        </button>
      </div>

      {/* Main Mode Toggle: Medical History vs Health Documents Vault */}
      <div className="grid grid-cols-2 gap-2 p-1.5 bg-slate-950 rounded-2xl border border-cyan-500/30">
        <button
          onClick={() => setMainSection('medicalHistory')}
          className={`py-2 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all ${
            mainSection === 'medicalHistory'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <FileBadge className="w-4 h-4" /> Digital Medical History
        </button>

        <button
          onClick={() => setMainSection('vault')}
          className={`py-2 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all ${
            mainSection === 'vault'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-600/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Lock className="w-4 h-4" /> Documents Vault ({records.length})
        </button>
      </div>

      {/* ========================================================================= */}
      {/* SECTION 1: DIGITAL MEDICAL HISTORY TAB */}
      {/* ========================================================================= */}
      {mainSection === 'medicalHistory' && (
        <div className="space-y-4 animate-fade-in">
          
          {/* Medical History Summary Banner */}
          <div className="p-4 rounded-3xl bg-gradient-to-r from-slate-900 via-cyan-950/60 to-slate-900 border border-cyan-500/40 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-2xl bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300">
                  <Stethoscope className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-sm font-black text-white">Consultation Records Archive</h2>
                  <p className="text-[11px] text-cyan-300 font-medium">
                    Verified clinical notes & downloadable generated PDF reports
                  </p>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-extrabold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> {consultations.length} Verified
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 p-2.5 rounded-2xl bg-slate-950 border border-slate-800 text-center text-xs">
              <div>
                <span className="text-[10px] text-slate-400 block">Total Reports</span>
                <strong className="text-white font-mono text-sm">{consultations.length} Summaries</strong>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">Doctor Signatures</span>
                <strong className="text-emerald-400 font-mono text-sm">100% Cryptographic</strong>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">Last Visit</span>
                <strong className="text-cyan-300 font-mono text-xs">Jul 18, 2026</strong>
              </div>
            </div>

            <button
              onClick={() => setShowCompileModal(true)}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all"
            >
              <Plus className="w-4 h-4" /> Compile New Consultation Summary Report
            </button>
          </div>

          {/* Search & Department Filters */}
          <div className="space-y-2">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by doctor, diagnosis, complaint, or ID..."
                className="w-full pl-9 pr-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400 transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>

            <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
              {['All', 'Cardiology', 'Neurology', 'Emergency & Trauma', 'Orthopedics'].map((dept) => (
                <button
                  key={dept}
                  onClick={() => setDepartmentFilter(dept)}
                  className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                    departmentFilter === dept
                      ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                      : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
                  }`}
                >
                  {dept}
                </button>
              ))}
            </div>
          </div>

          {/* List of Past Consultation Cards */}
          <div className="space-y-3">
            {filteredConsultations.length === 0 ? (
              <div className="p-8 rounded-3xl bg-slate-900/50 border border-slate-800 text-center space-y-2">
                <FileBadge className="w-8 h-8 text-slate-600 mx-auto" />
                <h3 className="text-sm font-bold text-slate-300">No Consultation Reports Found</h3>
                <p className="text-xs text-slate-500">Try adjusting your search query or department filter.</p>
              </div>
            ) : (
              filteredConsultations.map((summary) => (
                <div
                  key={summary.id}
                  className="p-4 rounded-3xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 shadow-xl transition-all space-y-3"
                >
                  {/* Top Bar: Doctor Info & Date */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex gap-3 items-center">
                      <img
                        src={summary.doctorAvatar}
                        alt={summary.doctorName}
                        className="w-12 h-12 rounded-2xl object-cover border-2 border-cyan-400/80 shrink-0"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-extrabold text-white">{summary.doctorName}</h3>
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                            {summary.department}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 font-medium">{summary.doctorTitle}</p>
                        <p className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                          <Calendar className="w-3 h-3 text-cyan-400" /> {summary.consultationDate}
                        </p>
                      </div>
                    </div>

                    <span className="text-[10px] font-mono px-2 py-1 rounded-lg bg-slate-950 text-cyan-300 border border-slate-800 shrink-0 font-bold">
                      {summary.id}
                    </span>
                  </div>

                  {/* Diagnosis & Chief Complaint Box */}
                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                    <div className="flex items-center gap-1.5 text-xs text-rose-300 font-extrabold">
                      <Heart className="w-3.5 h-3.5 text-rose-400" /> Diagnosis:
                      <span className="text-white font-bold">{summary.diagnosis}</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      <strong className="text-slate-400 font-semibold">Chief Complaint:</strong> {summary.chiefComplaint}
                    </p>
                  </div>

                  {/* Vitals Telemetry Grid */}
                  <div className="grid grid-cols-4 gap-1.5 p-2 rounded-xl bg-slate-950/80 border border-slate-800/80 text-center text-[11px]">
                    <div>
                      <span className="text-[9px] text-slate-500 block">BP</span>
                      <strong className="text-cyan-300 font-mono">{summary.vitalSigns.bloodPressure}</strong>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-500 block">Heart Rate</span>
                      <strong className="text-emerald-400 font-mono">{summary.vitalSigns.heartRate}</strong>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-500 block">SpO2</span>
                      <strong className="text-blue-400 font-mono">{summary.vitalSigns.spO2}</strong>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-500 block">Temp</span>
                      <strong className="text-amber-300 font-mono">{summary.vitalSigns.temperature}</strong>
                    </div>
                  </div>

                  {/* Prescribed Medications Pill Preview */}
                  <div className="flex items-center gap-1.5 flex-wrap text-xs">
                    <span className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
                      <Pill className="w-3 h-3 text-cyan-400" /> Rx Prescribed:
                    </span>
                    {summary.prescribedMedications.map((m, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded-lg bg-slate-800 text-slate-200 border border-slate-700 text-[10px] font-semibold"
                      >
                        {m.name} ({m.dosage})
                      </span>
                    ))}
                  </div>

                  {/* Card Action Buttons */}
                  <div className="grid grid-cols-3 gap-2 pt-1">
                    <button
                      onClick={() => setViewingConsultation(summary)}
                      className="py-2 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-extrabold text-xs flex items-center justify-center gap-1 transition-all"
                    >
                      <Eye className="w-3.5 h-3.5" /> View Report
                    </button>

                    <button
                      onClick={() => downloadConsultationReport(summary)}
                      className="py-2 px-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs flex items-center justify-center gap-1 shadow-md transition-all"
                    >
                      <Download className="w-3.5 h-3.5" /> Download PDF
                    </button>

                    <button
                      onClick={() => handleCopyShareLink(summary.id)}
                      className="py-2 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center justify-center gap-1 transition-all"
                    >
                      {copiedId === summary.id ? (
                        <span className="text-emerald-400 font-bold flex items-center gap-1"><Check className="w-3.5 h-3.5" /> Copied!</span>
                      ) : (
                        <>
                          <Share2 className="w-3.5 h-3.5" /> Share
                        </>
                      )}
                    </button>
                  </div>

                </div>
              ))
            )}
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* SECTION 2: DOCUMENTS VAULT TAB */}
      {/* ========================================================================= */}
      {mainSection === 'vault' && (
        <div className="space-y-4 animate-fade-in">
          
          {/* Encrypted Vault Header Banner */}
          <div className="p-4 rounded-3xl bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 border border-purple-500/40 shadow-xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-extrabold text-purple-300 uppercase tracking-wide flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-purple-400" /> 256-Bit AES Encrypted Vault
              </span>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-500/30 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> HIPAA Compliant
              </span>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-300 pt-1">
              <div className="flex items-center gap-2">
                <Cloud className="w-4 h-4 text-cyan-400" />
                <span>Cloud Sync Active</span>
              </div>
              <span className="font-mono text-slate-400">12.4 GB / 50 GB Used</span>
            </div>
          </div>

          {/* Filter Tabs & Add Button */}
          <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 no-scrollbar">
            <div className="flex gap-1.5">
              {['All', 'Prescription', 'Lab Report', 'Vaccination', 'Insurance', 'Scan'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                    activeTab === tab
                      ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                      : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <button
              onClick={() => setShowAddModal(true)}
              className="p-2 rounded-xl bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-bold text-xs shrink-0 flex items-center gap-1 shadow-md transition-all"
              title="Upload New Medical Document"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Medical Records Cards */}
          <div className="space-y-3">
            {filteredRecords.map((rec) => (
              <div
                key={rec.id}
                className="p-4 rounded-3xl bg-slate-900/90 border border-slate-800 hover:border-purple-500/40 shadow-lg transition-all space-y-2"
              >
                <div className="flex items-start justify-between">
                  <div className="flex gap-3">
                    <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400 shrink-0">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-xs sm:text-sm font-bold text-white">
                          {rec.title}
                        </h3>
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-slate-800 text-cyan-300 border border-cyan-500/20">
                          {rec.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {rec.date} {rec.doctorName && `• ${rec.doctorName}`}
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono text-slate-500">{rec.fileSize}</span>
                </div>

                <p className="text-xs text-slate-300 bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 leading-relaxed">
                  {rec.details}
                </p>

                <div className="flex gap-2 pt-1">
                  <button
                    onClick={() => setViewingRecord(rec)}
                    className="flex-1 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold text-xs flex items-center justify-center gap-1 transition-all"
                  >
                    <Eye className="w-3.5 h-3.5" /> View Detail
                  </button>
                  <a
                    href="#download"
                    onClick={(e) => {
                      e.preventDefault();
                      alert(`Downloaded encrypted PDF: ${rec.title}`);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-purple-600 hover:text-white text-slate-300 font-bold text-xs flex items-center justify-center gap-1 transition-all"
                  >
                    <Download className="w-3.5 h-3.5" /> PDF
                  </a>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* FULL CLINICAL CONSULTATION SUMMARY REPORT MODAL */}
      {/* ========================================================================= */}
      {viewingConsultation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in overflow-y-auto">
          <div className="relative w-full max-w-lg my-auto bg-slate-900 border border-cyan-500/50 rounded-3xl p-5 sm:p-6 text-white shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            
            {/* Top Close Button */}
            <button
              onClick={() => setViewingConsultation(null)}
              className="absolute top-4 right-4 p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Official Report Header Banner */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950 via-slate-950 to-blue-950 border border-cyan-500/40 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-400">
                    <FileBadge className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white">MediFlow Official Consultation Report</h3>
                    <p className="text-[10px] text-cyan-300">Digitally Verified & Signed Clinical Document</p>
                  </div>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-extrabold">
                  VALID & SIGNED
                </span>
              </div>
            </div>

            {/* Doctor & Patient Info Header */}
            <div className="grid grid-cols-2 gap-3 p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs">
              <div>
                <span className="text-[10px] text-slate-500 block">Attending Specialist</span>
                <strong className="text-white block font-bold">{viewingConsultation.doctorName}</strong>
                <span className="text-[10px] text-cyan-300 block">{viewingConsultation.doctorTitle}</span>
                <span className="text-[10px] text-slate-400 block">{viewingConsultation.department}</span>
              </div>
              <div className="border-l border-slate-800 pl-3">
                <span className="text-[10px] text-slate-500 block">Patient Information</span>
                <strong className="text-white block font-bold">Minahil Raza</strong>
                <span className="text-[10px] text-slate-400 block">ID: #MF-99201-X</span>
                <span className="text-[10px] text-slate-400 block">Date: {viewingConsultation.consultationDate}</span>
              </div>
            </div>

            {/* Chief Complaint & Diagnosis */}
            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-400 font-extrabold uppercase block mb-1">Chief Complaint</span>
                <p className="text-slate-200">{viewingConsultation.chiefComplaint}</p>
              </div>

              <div className="p-3 rounded-2xl bg-rose-950/30 border border-rose-500/40">
                <span className="text-[10px] text-rose-300 font-extrabold uppercase block mb-1">Primary Diagnosis</span>
                <p className="text-white font-bold text-sm">{viewingConsultation.diagnosis}</p>
              </div>
            </div>

            {/* Vital Signs Block */}
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase block">Vitals at Time of Consultation</span>
              <div className="grid grid-cols-4 gap-2 text-center text-xs">
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[9px] text-slate-500 block">Blood Pressure</span>
                  <strong className="text-cyan-300 font-mono">{viewingConsultation.vitalSigns.bloodPressure}</strong>
                </div>
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[9px] text-slate-500 block">Heart Rate</span>
                  <strong className="text-emerald-400 font-mono">{viewingConsultation.vitalSigns.heartRate}</strong>
                </div>
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[9px] text-slate-500 block">SpO2</span>
                  <strong className="text-blue-400 font-mono">{viewingConsultation.vitalSigns.spO2}</strong>
                </div>
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[9px] text-slate-500 block">Temp</span>
                  <strong className="text-amber-300 font-mono">{viewingConsultation.vitalSigns.temperature}</strong>
                </div>
              </div>
            </div>

            {/* Prescribed Medications Regimen */}
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase block">Prescribed Medication Regimen</span>
              <div className="space-y-1.5">
                {viewingConsultation.prescribedMedications.map((med, idx) => (
                  <div key={idx} className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-xs">
                    <div className="flex justify-between items-center font-bold text-white">
                      <span>{med.name}</span>
                      <span className="text-cyan-300 text-[11px] font-mono">{med.dosage}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">{med.instructions}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Clinical Evaluation Notes */}
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs space-y-1">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase block">Physician Clinical Evaluation Notes</span>
              <p className="text-slate-300 leading-relaxed text-[11px]">{viewingConsultation.clinicalNotes}</p>
            </div>

            {/* Follow Up Plan */}
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs space-y-1">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase block">Follow-Up Plan</span>
              <p className="text-slate-300 text-[11px]">{viewingConsultation.followUpInstructions}</p>
            </div>

            {/* Download & Print Controls */}
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => downloadConsultationReport(viewingConsultation)}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all"
              >
                <Download className="w-4 h-4" /> Download Report (.TXT / PDF)
              </button>
              <button
                onClick={() => setViewingConsultation(null)}
                className="py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* COMPILE NEW CONSULTATION SUMMARY REPORT MODAL */}
      {/* ========================================================================= */}
      {showCompileModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-sm bg-slate-900 border border-cyan-500/40 rounded-3xl p-6 text-white shadow-2xl space-y-4">
            
            <button
              onClick={() => setShowCompileModal(false)}
              className="absolute top-4 right-4 p-1 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-cyan-400">
              <Stethoscope className="w-5 h-5" />
              <h3 className="text-base font-extrabold text-white">Compile AI Consultation Report</h3>
            </div>

            <p className="text-xs text-slate-300">
              Generate a verified consultation summary report compiling your recent symptoms and vital telemetry.
            </p>

            <form onSubmit={handleCompileReport} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 font-bold block mb-1">Attending Specialist</label>
                <select
                  value={newDoctorName}
                  onChange={(e) => setNewDoctorName(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none"
                >
                  <option value="Dr. Sarah Vance, MD">Dr. Sarah Vance, MD (Cardiology)</option>
                  <option value="Dr. Alexander Mercer, PhD">Dr. Alexander Mercer, PhD (Neurology)</option>
                  <option value="Dr. Elena Rostova">Dr. Elena Rostova (Emergency)</option>
                  <option value="Dr. Marcus Chen">Dr. Marcus Chen (Orthopedics)</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">Department</label>
                <select
                  value={newDepartment}
                  onChange={(e) => setNewDepartment(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none"
                >
                  <option value="Cardiology">Cardiology</option>
                  <option value="Neurology">Neurology</option>
                  <option value="Emergency & Trauma">Emergency & Trauma</option>
                  <option value="Orthopedics">Orthopedics</option>
                  <option value="General Medicine">General Medicine</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">Chief Complaint</label>
                <input
                  type="text"
                  required
                  value={newChiefComplaint}
                  onChange={(e) => setNewChiefComplaint(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-slate-400 font-bold block mb-1">Primary Diagnosis</label>
                <input
                  type="text"
                  required
                  value={newDiagnosis}
                  onChange={(e) => setNewDiagnosis(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCompileModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isCompiling}
                  className="flex-1 py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-black uppercase flex items-center justify-center gap-1 shadow-md"
                >
                  {isCompiling ? 'Compiling...' : 'Generate & Save'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* Record Detail Modal (Vault) */}
      {viewingRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-sm bg-slate-900 border border-purple-500/40 rounded-3xl p-6 text-white shadow-2xl">
            <button
              onClick={() => setViewingRecord(null)}
              className="absolute top-4 right-4 p-1 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
              {viewingRecord.category}
            </span>
            <h3 className="text-base font-extrabold text-white mt-2">
              {viewingRecord.title}
            </h3>
            <p className="text-xs text-slate-400 mb-3">{viewingRecord.date}</p>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-200 leading-relaxed space-y-2 mb-4">
              <p><strong>Clinical Notes:</strong> {viewingRecord.details}</p>
              <p className="text-[11px] text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Verified by MediFlow Health Network
              </p>
            </div>

            <button
              onClick={() => setViewingRecord(null)}
              className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs"
            >
              Close Record
            </button>
          </div>
        </div>
      )}

      {/* Add Document Modal (Vault) */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-sm bg-slate-900 border border-cyan-500/40 rounded-3xl p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">
              Upload Medical Document
            </h3>
            <form onSubmit={handleAddDocument} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 font-semibold block mb-1">Document Title</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Thyroid Panel Scan 2026"
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-slate-400 font-semibold block mb-1">Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none"
                >
                  <option value="Lab Report">Lab Report</option>
                  <option value="Prescription">Prescription</option>
                  <option value="Scan">Scan</option>
                  <option value="Vaccination">Vaccination</option>
                  <option value="Insurance">Insurance</option>
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-bold"
                >
                  Encrypt & Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};

