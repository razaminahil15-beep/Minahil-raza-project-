import React, { useState, useEffect } from 'react';
import { ScreenId } from '../../types';
import { fetchUserProfileFromFirestore, saveUserProfileToFirestore, UserProfileData } from '../../services/firestoreService';
import { signOutUser } from '../../services/authService';
import { Sparkles, User, ShieldCheck, Watch, Bell, Moon, Lock, Globe, FileCheck, CheckCircle2, Sliders, ChevronRight, Edit2, LogOut, LogIn, Key, Database, Bot, Check } from 'lucide-react';

interface ProfileScreenProps {
  setActiveScreen: (screen: ScreenId) => void;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
  currentUser?: any;
  onOpenAuth?: () => void;
  onSignOut?: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  setActiveScreen,
  isDarkMode,
  setIsDarkMode,
  currentUser,
  onOpenAuth,
  onSignOut,
}) => {
  const [profile, setProfile] = useState<UserProfileData>({
    name: 'Minahil Raza',
    email: 'razaminahil15@gmail.com',
    bloodType: 'O Positive',
    height: '178 cm',
    weight: '72 kg',
    allergies: 'Penicillin'
  });
  const [isEditing, setIsEditing] = useState(false);

  const [assistantName, setAssistantName] = useState<string>(() => {
    return localStorage.getItem('mediflow_assistant_name') || 'Aura Health AI';
  });
  const [editingAssistantName, setEditingAssistantName] = useState(false);
  const [assistantInput, setAssistantInput] = useState(assistantName);
  const [assistantSavedNotice, setAssistantSavedNotice] = useState(false);

  const [wearables, setWearables] = useState({
    appleWatch: true,
    ouraRing: true,
    fitbit: false,
    garmin: false,
  });

  const [notifications, setNotifications] = useState({
    queueAlerts: true,
    pillReminders: true,
    aiHealthTips: true,
  });

  const [generatingReport, setGeneratingReport] = useState(false);
  const [reportGenerated, setReportGenerated] = useState(false);

  useEffect(() => {
    fetchUserProfileFromFirestore().then((data) => {
      if (data) {
        setProfile(data);
      }
    });
  }, []);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await saveUserProfileToFirestore(profile);
    setIsEditing(false);
  };

  const toggleWearable = (key: keyof typeof wearables) => {
    setWearables((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleNotif = (key: keyof typeof notifications) => {
    setNotifications((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleGenerateReport = () => {
    setGeneratingReport(true);
    setTimeout(() => {
      setGeneratingReport(false);
      setReportGenerated(true);
    }, 1800);
  };

  return (
    <div className="min-h-full p-4 sm:p-6 text-white space-y-4 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 pb-20">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-widest">
            <Sparkles className="w-4 h-4" /> Screen 9
          </div>
          <h1 className="text-xl font-black text-white tracking-tight">
            Profile & App Settings
          </h1>
        </div>
        <span className="px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-xs text-cyan-300 font-semibold">
          Biometric Profile
        </span>
      </div>

      {/* Firebase Auth Account Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-slate-900 via-cyan-950/50 to-slate-900 border border-cyan-500/40 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-extrabold text-white">Firebase Project Account</h3>
              <p className="text-[10px] text-cyan-300">Connected: <span className="font-mono text-cyan-200">mediflow-ai-bfd1f</span></p>
            </div>
          </div>

          {currentUser && !currentUser.isAnonymous ? (
            <button
              onClick={onSignOut}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/80 border border-rose-500/40 text-rose-300 text-xs font-bold flex items-center gap-1.5 transition-all"
            >
              <LogOut className="w-3.5 h-3.5" /> Sign Out
            </button>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20 transition-all"
            >
              <LogIn className="w-3.5 h-3.5" /> Sign In / Up
            </button>
          )}
        </div>

        <div className="p-2.5 rounded-2xl bg-slate-950 border border-slate-800 text-[11px] flex items-center justify-between">
          <span className="text-slate-400">Auth Status:</span>
          <span className="font-bold text-emerald-400 flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            {currentUser && !currentUser.isAnonymous ? (currentUser.email || 'Authenticated User') : 'Guest / Anonymous Session'}
          </span>
        </div>
      </div>

      {/* User Profile Card */}
      <div className="p-4 rounded-3xl bg-slate-900/90 border border-cyan-500/40 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200"
              alt={profile.name}
              className="w-14 h-14 rounded-2xl object-cover border-2 border-cyan-400"
            />
            <div>
              <h2 className="text-base font-extrabold text-white">{profile.name}</h2>
              <p className="text-xs text-cyan-300 font-medium">Patient ID: #MF-99201-X</p>
              <p className="text-[10px] text-slate-400">{profile.email}</p>
            </div>
          </div>
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-cyan-400 font-bold text-xs flex items-center gap-1 border border-cyan-500/30 transition-all"
          >
            <Edit2 className="w-3.5 h-3.5" /> Edit
          </button>
        </div>

        {/* Biometric Summary Grid */}
        <div className="grid grid-cols-4 gap-2 p-2.5 rounded-2xl bg-slate-950 border border-slate-800 text-center text-xs">
          <div>
            <span className="text-[10px] text-slate-400 block">Blood Type</span>
            <strong className="text-rose-400 font-mono">{profile.bloodType}</strong>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block">Height</span>
            <strong className="text-white font-mono">{profile.height}</strong>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block">Weight</span>
            <strong className="text-white font-mono">{profile.weight}</strong>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block">Allergies</span>
            <strong className="text-amber-300 font-semibold text-[10px]">{profile.allergies}</strong>
          </div>
        </div>

        {/* Edit Profile Form */}
        {isEditing && (
          <form onSubmit={handleSaveProfile} className="mt-3 p-3 rounded-2xl bg-slate-950 border border-cyan-500/30 space-y-2 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400 block mb-0.5">Full Name</label>
                <input
                  type="text"
                  value={profile.name}
                  onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  className="w-full p-2 rounded-xl bg-slate-900 border border-slate-700 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-0.5">Blood Type</label>
                <input
                  type="text"
                  value={profile.bloodType}
                  onChange={(e) => setProfile({ ...profile, bloodType: e.target.value })}
                  className="w-full p-2 rounded-xl bg-slate-900 border border-slate-700 text-white"
                />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-slate-400 block mb-0.5">Height</label>
                <input
                  type="text"
                  value={profile.height}
                  onChange={(e) => setProfile({ ...profile, height: e.target.value })}
                  className="w-full p-2 rounded-xl bg-slate-900 border border-slate-700 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-0.5">Weight</label>
                <input
                  type="text"
                  value={profile.weight}
                  onChange={(e) => setProfile({ ...profile, weight: e.target.value })}
                  className="w-full p-2 rounded-xl bg-slate-900 border border-slate-700 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-0.5">Allergies</label>
                <input
                  type="text"
                  value={profile.allergies}
                  onChange={(e) => setProfile({ ...profile, allergies: e.target.value })}
                  className="w-full p-2 rounded-xl bg-slate-900 border border-slate-700 text-white"
                />
              </div>
            </div>
            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="flex-1 py-1.5 rounded-xl bg-slate-800 text-slate-300 font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-1.5 rounded-xl bg-cyan-500 text-slate-950 font-bold"
              >
                Save to Firestore
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Monthly Health Report Generator */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border border-indigo-500/40 shadow-xl space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-extrabold text-cyan-300">
            <FileCheck className="w-4 h-4 text-cyan-400" /> Monthly AI Health Report (July 2026)
          </div>
          <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/20 px-2 py-0.5 rounded">
            Ready
          </span>
        </div>

        <p className="text-xs text-slate-300">
          Generate an aggregated PDF certificate combining vitals telemetry, prescription history, and consultation logs.
        </p>

        {!reportGenerated ? (
          <button
            onClick={handleGenerateReport}
            disabled={generatingReport}
            className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md transition-all"
          >
            {generatingReport ? 'Generating Report PDF...' : 'Generate Monthly Digest'}
          </button>
        ) : (
          <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-between">
            <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4" /> Report Download Ready (PDF 2.8 MB)</span>
            <a href="#download" onClick={(e) => { e.preventDefault(); alert("Report downloaded successfully."); }} className="underline text-white">Download</a>
          </div>
        )}
      </div>

      {/* Wearable Device Integrations */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-extrabold text-white flex items-center gap-1.5">
            <Watch className="w-4 h-4 text-cyan-400" /> Connected Wearable Devices
          </span>
          <span className="text-[10px] text-cyan-300 font-mono">Live Telemetry Sync</span>
        </div>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
            <span className="font-semibold text-slate-200">Apple Watch Series 11</span>
            <button
              onClick={() => toggleWearable('appleWatch')}
              className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all ${
                wearables.appleWatch ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {wearables.appleWatch ? 'Synced' : 'Connect'}
            </button>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
            <span className="font-semibold text-slate-200">Oura Ring Gen 4</span>
            <button
              onClick={() => toggleWearable('ouraRing')}
              className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all ${
                wearables.ouraRing ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {wearables.ouraRing ? 'Synced' : 'Connect'}
            </button>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
            <span className="font-semibold text-slate-200">Fitbit Sense 3</span>
            <button
              onClick={() => toggleWearable('fitbit')}
              className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all ${
                wearables.fitbit ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {wearables.fitbit ? 'Synced' : 'Connect'}
            </button>
          </div>
        </div>
      </div>

      {/* AI Assistant Personality & Name Setting */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/30 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-extrabold text-white flex items-center gap-1.5">
            <Bot className="w-4 h-4 text-cyan-400" /> AI Assistant Persona Name
          </span>
          <button
            onClick={() => {
              setAssistantInput(assistantName);
              setEditingAssistantName(!editingAssistantName);
            }}
            className="text-[11px] font-bold text-cyan-300 hover:text-white flex items-center gap-1 bg-cyan-500/10 px-2 py-0.5 rounded-lg border border-cyan-500/30"
          >
            <Edit2 className="w-3 h-3" />
            {editingAssistantName ? 'Cancel' : 'Edit Name'}
          </button>
        </div>

        {!editingAssistantName ? (
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
            <div>
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Current Name</div>
              <div className="text-xs font-extrabold text-cyan-300 flex items-center gap-1.5 mt-0.5">
                {assistantName}
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>
            </div>
            <button
              onClick={() => setActiveScreen('aiAssistant')}
              className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 text-xs font-bold transition-all"
            >
              Test Chat →
            </button>
          </div>
        ) : (
          <div className="space-y-2 p-3 rounded-xl bg-slate-950 border border-slate-800">
            <label className="text-[11px] font-bold text-slate-300 block">Set AI Assistant Name</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={assistantInput}
                onChange={(e) => setAssistantInput(e.target.value)}
                placeholder="e.g. Aura Health AI, Dr. Sarah..."
                className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
              />
              <button
                onClick={() => {
                  const trimmed = assistantInput.trim() || 'Aura Health AI';
                  setAssistantName(trimmed);
                  localStorage.setItem('mediflow_assistant_name', trimmed);
                  setEditingAssistantName(false);
                  setAssistantSavedNotice(true);
                  setTimeout(() => setAssistantSavedNotice(false), 3000);
                }}
                className="px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold text-xs shrink-0"
              >
                Save
              </button>
            </div>
            <div className="flex flex-wrap gap-1 mt-1">
              {['Aura Health AI', 'Dr. MediFlow AI', 'MediPulse AI', 'CareBot Pro'].map((preset) => (
                <button
                  key={preset}
                  onClick={() => setAssistantInput(preset)}
                  className="px-2 py-0.5 rounded-md text-[10px] bg-slate-900 border border-slate-700 text-slate-400 hover:text-cyan-300"
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>
        )}

        {assistantSavedNotice && (
          <div className="text-[11px] font-bold text-emerald-400 flex items-center gap-1.5 bg-emerald-500/10 p-2 rounded-lg border border-emerald-500/30">
            <Check className="w-3.5 h-3.5" />
            Assistant name saved as "{assistantName}" across all screens and AI models!
          </div>
        )}
      </div>

      {/* App Preferences & Toggles */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <span className="text-xs font-extrabold text-white flex items-center gap-1.5">
          <Sliders className="w-4 h-4 text-cyan-400" /> Application Preferences
        </span>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
            <span className="font-semibold text-slate-200">Push Notifications & Queue Alerts</span>
            <button
              onClick={() => toggleNotif('queueAlerts')}
              className={`w-9 h-5 rounded-full p-0.5 transition-colors ${
                notifications.queueAlerts ? 'bg-cyan-500' : 'bg-slate-800'
              }`}
            >
              <div className={`w-4 h-4 rounded-full bg-slate-950 transition-transform ${
                notifications.queueAlerts ? 'translate-x-4' : ''
              }`} />
            </button>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
            <span className="font-semibold text-slate-200">Futuristic Neon Theme Mode</span>
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className={`w-9 h-5 rounded-full p-0.5 transition-colors ${
                isDarkMode ? 'bg-cyan-500' : 'bg-slate-800'
              }`}
            >
              <div className={`w-4 h-4 rounded-full bg-slate-950 transition-transform ${
                isDarkMode ? 'translate-x-4' : ''
              }`} />
            </button>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
            <span className="font-semibold text-slate-200">Biometric FaceID / Lock</span>
            <span className="text-[10px] text-emerald-400 font-bold">Active</span>
          </div>
        </div>
      </div>

    </div>
  );
};
