import React, { useState, useEffect } from 'react';
import { ScreenId, QueueItem } from '../../types';
import { INITIAL_QUEUE } from '../../data/mockData';
import { notificationService } from '../../services/notificationService';
import { Sparkles, Clock, Users, Bell, AlertTriangle, RefreshCw, ChevronRight, CheckCircle2, UserCheck, Calendar, Zap, RefreshCcw, Star } from 'lucide-react';

interface QueueTrackerScreenProps {
  setActiveScreen: (screen: ScreenId) => void;
  onOpenQr: () => void;
  onOpenFeedback?: () => void;
}

export const QueueTrackerScreen: React.FC<QueueTrackerScreenProps> = ({
  setActiveScreen,
  onOpenQr,
  onOpenFeedback,
}) => {
  const [patientsAhead, setPatientsAhead] = useState(2);
  const [estWaitMins, setEstWaitMins] = useState(11);
  const [doctorStatus, setDoctorStatus] = useState<'Available' | 'Busy' | 'Break'>('Available');
  const [notifications, setNotifications] = useState<string[]>([
    'Dr. Sarah Vance started consultation for Patient #A-101',
    'Vitals Kiosk 2 synced blood pressure data for token #A-104',
    'AI Queue Optimizer: +2 min buffer added for detailed ECG check',
  ]);
  const [isSwitchingDoctor, setIsSwitchingDoctor] = useState(false);

  // Live simulation tick
  useEffect(() => {
    const interval = setInterval(() => {
      if (patientsAhead > 0 && Math.random() > 0.7) {
        const nextPos = Math.max(0, patientsAhead - 1);
        setPatientsAhead(nextPos);
        setEstWaitMins((m) => Math.max(2, m - 4));
        setNotifications((prev) => [
          `Queue update: Patient finished consultation. You are now #${nextPos} in line!`,
          ...prev.slice(0, 3)
        ]);
        // Trigger Push Notification
        notificationService.triggerQueueUpdate('A-104', nextPos, 'Dr. Sarah Vance', 'Room 304');
      }
    }, 12000);
    return () => clearInterval(interval);
  }, [patientsAhead]);

  const handleSimulateAdvance = () => {
    if (patientsAhead > 0) {
      const nextPos = patientsAhead - 1;
      setPatientsAhead(nextPos);
      setEstWaitMins((m) => Math.max(2, m - 4));
      setNotifications((prev) => [
        `Manual Simulation: Patient called. You advanced to #${nextPos}!`,
        ...prev.slice(0, 3)
      ]);
      // Trigger Push Notification
      notificationService.triggerQueueUpdate('A-104', nextPos, 'Dr. Sarah Vance', 'Room 304');
    } else {
      notificationService.triggerQueueUpdate('A-104', 0, 'Dr. Sarah Vance', 'Room 304');
    }
  };

  return (
    <div className="min-h-full p-4 sm:p-6 text-white space-y-4 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 pb-20">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-widest">
            <Sparkles className="w-4 h-4" /> Screen 5
          </div>
          <h1 className="text-xl font-black text-white tracking-tight">
            Live Queue Tracker
          </h1>
        </div>
        <span className="px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-extrabold text-xs flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" /> Live Syncing
        </span>
      </div>

      {/* Main Live Queue Status Card */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-cyan-950/80 via-slate-900 to-slate-950 border-2 border-cyan-400/60 shadow-2xl space-y-4">
        
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Your Token</span>
            <span className="text-2xl font-mono font-black text-cyan-300">A-104</span>
          </div>

          <div className="text-right">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Doctor Status</span>
            <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${
              doctorStatus === 'Available' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
            }`}>
              {doctorStatus === 'Available' ? 'Consulting Patient #A-101' : 'On 5-min Break'}
            </span>
          </div>
        </div>

        {/* Patients Ahead & Est Wait Counter */}
        <div className="grid grid-cols-2 gap-3 text-center">
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800">
            <span className="text-xs text-slate-400 font-bold block flex items-center justify-center gap-1">
              <Users className="w-3.5 h-3.5 text-cyan-400" /> Patients Ahead
            </span>
            <span className="text-3xl font-black text-white mt-1 block">
              {patientsAhead}
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800">
            <span className="text-xs text-slate-400 font-bold block flex items-center justify-center gap-1">
              <Clock className="w-3.5 h-3.5 text-amber-400" /> Est. Waiting Time
            </span>
            <span className="text-3xl font-mono font-black text-amber-300 mt-1 block">
              ~{estWaitMins}m
            </span>
          </div>
        </div>

        {/* Queue Progress Bar */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs font-bold text-slate-300">
            <span>Overall Queue Journey</span>
            <span className="text-cyan-400">75% Complete</span>
          </div>
          <div className="w-full h-3 bg-slate-950 rounded-full p-0.5 border border-slate-800">
            <div className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all duration-500 w-[75%]" />
          </div>
        </div>

        {/* AI Delay Prediction Badge */}
        <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="font-medium">
            AI Queue Prediction: +2 mins added to allow detailed ECG analysis for preceding patient.
          </span>
        </div>

        {/* Post-Consultation Rating Trigger */}
        {onOpenFeedback && (
          <div className="pt-2 border-t border-slate-800">
            <button
              onClick={onOpenFeedback}
              className="w-full py-2.5 px-3 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition-all hover:scale-[1.01] active:scale-98"
            >
              <Star className="w-4 h-4 text-slate-950 fill-slate-950 animate-pulse" />
              <span>Rate Consultation & Doctor Feedback</span>
            </button>
          </div>
        )}

      </div>

      {/* Interactive Step Timeline */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <h3 className="text-xs font-extrabold text-slate-300 uppercase tracking-wide">
          Queue Journey Timeline
        </h3>

        <div className="space-y-3">
          {/* Step 1 */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-emerald-500 text-slate-950 font-bold text-xs flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h4 className="text-xs font-bold text-white">1. Arrived & QR Checked-In</h4>
              <p className="text-[10px] text-slate-400">Completed at 10:15 AM (Kiosk 1)</p>
            </div>
          </div>

          {/* Step 2 */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center shrink-0 animate-pulse">
              2
            </div>
            <div className="flex-1">
              <h4 className="text-xs font-bold text-cyan-300">2. Automated Vitals Kiosk</h4>
              <p className="text-[10px] text-slate-400">In Progress — BP & SpO2 logged</p>
            </div>
          </div>

          {/* Step 3 */}
          <div className="flex items-center gap-3 opacity-70">
            <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 font-bold text-xs flex items-center justify-center shrink-0">
              3
            </div>
            <div className="flex-1">
              <h4 className="text-xs font-bold text-slate-300">3. Next in Line (Waiting Pod B)</h4>
              <p className="text-[10px] text-slate-400">Pending patient #A-102</p>
            </div>
          </div>

          {/* Step 4 */}
          <div className="flex items-center gap-3 opacity-50">
            <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 font-bold text-xs flex items-center justify-center shrink-0">
              4
            </div>
            <div className="flex-1">
              <h4 className="text-xs font-bold text-slate-400">4. Doctor Consultation</h4>
              <p className="text-[10px] text-slate-400">Room 304 - Dr. Sarah Vance</p>
            </div>
          </div>
        </div>
      </div>

      {/* Live Notifications Feed */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="font-extrabold text-white flex items-center gap-1.5">
            <Bell className="w-4 h-4 text-cyan-400" /> Live Queue Feed
          </span>
          <button
            onClick={handleSimulateAdvance}
            className="text-[10px] font-bold text-cyan-400 underline hover:text-white"
          >
            [Simulate Queue Move]
          </button>
        </div>

        <div className="space-y-1.5 text-xs">
          {notifications.map((note, idx) => (
            <div key={idx} className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 text-[11px] leading-tight">
              {note}
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions Bar: Switch Doctor / Reschedule */}
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => {
            setIsSwitchingDoctor(true);
            setTimeout(() => {
              setIsSwitchingDoctor(false);
              setPatientsAhead(1);
              setEstWaitMins(4);
            }, 1500);
          }}
          className="py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-cyan-500/30 text-cyan-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
        >
          {isSwitchingDoctor ? (
            <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin" />
          ) : (
            <RefreshCcw className="w-4 h-4 text-cyan-400" />
          )}
          <span>Switch Available Doctor</span>
        </button>

        <button
          onClick={() => setActiveScreen('booking')}
          className="py-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
        >
          <Calendar className="w-4 h-4 text-amber-400" />
          <span>Reschedule Slot</span>
        </button>
      </div>

    </div>
  );
};
