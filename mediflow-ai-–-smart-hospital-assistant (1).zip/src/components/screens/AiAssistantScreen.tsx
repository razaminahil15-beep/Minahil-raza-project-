import React, { useState, useRef, useEffect } from 'react';
import { ScreenId, ChatMessage } from '../../types';
import { Sparkles, Send, Mic, MicOff, Volume2, VolumeX, Bot, User, Globe, Calendar, Pill, Utensils, ShieldCheck, Edit3, Check, RefreshCw } from 'lucide-react';

interface AiAssistantScreenProps {
  setActiveScreen: (screen: ScreenId) => void;
}

const PRESET_NAMES = [
  'Aura Health AI',
  'Dr. MediFlow AI',
  'MediPulse AI',
  'CareBot Pro',
  'Dr. Alex AI'
];

export const AiAssistantScreen: React.FC<AiAssistantScreenProps> = ({ setActiveScreen }) => {
  const [assistantName, setAssistantName] = useState<string>(() => {
    return localStorage.getItem('mediflow_assistant_name') || 'Aura Health AI';
  });
  const [isEditingName, setIsEditingName] = useState(false);
  const [customNameInput, setCustomNameInput] = useState(assistantName);
  const [nameChangeToast, setNameChangeToast] = useState<string | null>(null);

  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'msg-1',
      sender: 'ai',
      text: `Hello Alex! I am ${localStorage.getItem('mediflow_assistant_name') || 'Aura Health AI'}, your smart health assistant. Ask me about your prescriptions, symptom guidance, post-treatment recovery, or healthy diet plans.`,
      timestamp: 'Just now',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [speechEnabled, setSpeechEnabled] = useState(true);
  const [chatLanguage, setChatLanguage] = useState('English');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const saveAssistantName = (newName: string) => {
    const trimmed = newName.trim() || 'Aura Health AI';
    setAssistantName(trimmed);
    localStorage.setItem('mediflow_assistant_name', trimmed);
    setIsEditingName(false);
    
    // Add system notification message
    const sysMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'ai',
      text: `Assistant name successfully updated to "${trimmed}". How can I assist you today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, sysMsg]);

    setNameChangeToast(`Name updated to "${trimmed}"!`);
    setTimeout(() => setNameChangeToast(null), 3000);
  };

  const speakText = (text: string) => {
    if (!speechEnabled || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  };

  const handleSend = async (textToSend?: string) => {
    const messageText = textToSend || input;
    if (!messageText.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: messageText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: messageText,
          history: messages,
          language: chatLanguage,
          assistantName: assistantName,
        }),
      });

      const data = await response.json();
      const aiReply = data.reply || `I am analyzing your health question. Please consult a doctor for urgent symptoms.`;

      const aiMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'ai',
        text: aiReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);
      speakText(aiReply);
    } catch (err) {
      console.error(err);
      const fallbackMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'ai',
        text: `${assistantName} response: Based on clinical benchmarks, stay hydrated and follow your doctor's dosage instructions for Amoxicillin.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
      speakText(fallbackMsg.text);
    } finally {
      setLoading(false);
    }
  };

  const toggleVoiceInput = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }

    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.lang = 'en-US';
      setIsListening(true);
      recognition.start();

      recognition.onresult = (e: any) => {
        const transcript = e.results[0][0].transcript;
        setInput(transcript);
        setIsListening(false);
        handleSend(transcript);
      };

      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);
    } else {
      setIsListening(true);
      setTimeout(() => {
        const sample = "Can you explain my Amoxicillin 500mg prescription and when to take it?";
        setInput(sample);
        setIsListening(false);
        handleSend(sample);
      }, 2000);
    }
  };

  return (
    <div className="min-h-full flex flex-col justify-between p-4 sm:p-6 text-white bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 pb-20 relative">
      
      {/* Toast notification */}
      {nameChangeToast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-2xl bg-cyan-400 text-slate-950 font-black text-xs shadow-2xl flex items-center gap-2 animate-bounce border border-cyan-300">
          <Check className="w-4 h-4" />
          {nameChangeToast}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-widest">
            <Sparkles className="w-4 h-4" /> Screen 7
          </div>
          <h1 className="text-xl font-black text-white tracking-tight flex items-center gap-2">
            AI Health Assistant
          </h1>
        </div>

        {/* Voice Toggle & Language selector */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSpeechEnabled(!speechEnabled)}
            className={`p-2 rounded-xl border text-xs transition-all ${
              speechEnabled ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' : 'bg-slate-800 text-slate-500 border-slate-700'
            }`}
            title="Toggle Voice Output"
          >
            {speechEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <select
            value={chatLanguage}
            onChange={(e) => setChatLanguage(e.target.value)}
            className="bg-slate-900 border border-slate-700 rounded-xl px-2 py-1.5 text-xs text-slate-300 focus:outline-none"
          >
            <option value="English">English</option>
            <option value="Spanish">Español</option>
            <option value="French">Français</option>
            <option value="Mandarin">中文</option>
            <option value="Arabic">العربية</option>
          </select>
        </div>
      </div>

      {/* Assistant Name Bar & Quick Rename trigger */}
      <div className="my-2 p-2.5 rounded-2xl bg-slate-900/90 border border-cyan-500/30 flex items-center justify-between gap-2 shadow-md">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 text-cyan-300">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Active Assistant</div>
            <div className="text-xs font-black text-white flex items-center gap-1.5">
              {assistantName}
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </div>
          </div>
        </div>

        <button
          onClick={() => {
            setCustomNameInput(assistantName);
            setIsEditingName(true);
          }}
          className="px-2.5 py-1 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-all"
        >
          <Edit3 className="w-3.5 h-3.5" />
          Change Name
        </button>
      </div>

      {/* Customize Name Modal */}
      {isEditingName && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-sm bg-slate-900 border border-cyan-500/40 rounded-3xl p-5 text-white shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-cyan-400" />
                <h3 className="font-extrabold text-sm text-white">Change Assistant Name</h3>
              </div>
              <button onClick={() => setIsEditingName(false)} className="text-slate-400 hover:text-white font-bold text-xs p-1">
                ✕
              </button>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400">Quick Presets</label>
              <div className="flex flex-wrap gap-1.5">
                {PRESET_NAMES.map((pName) => (
                  <button
                    key={pName}
                    onClick={() => {
                      setCustomNameInput(pName);
                      saveAssistantName(pName);
                    }}
                    className={`px-2.5 py-1 rounded-xl text-xs font-semibold border transition-all ${
                      assistantName === pName
                        ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-bold'
                        : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-cyan-500/50'
                    }`}
                  >
                    {pName}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5 pt-1">
              <label className="text-xs font-bold text-slate-400">Or type custom assistant name</label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={customNameInput}
                  onChange={(e) => setCustomNameInput(e.target.value)}
                  placeholder="e.g. Dr. Sarah, HealthPal..."
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                />
                <button
                  onClick={() => saveAssistantName(customNameInput)}
                  className="px-3 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold text-xs shrink-0"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Suggested Quick Prompt Chips */}
      <div className="py-1 flex gap-1.5 overflow-x-auto no-scrollbar">
        {[
          { label: 'Explain Prescription', icon: Pill, prompt: 'Can you explain my Amoxicillin 500mg prescription dosage?' },
          { label: 'Healthy Diet Plan', icon: Utensils, prompt: 'Suggest a healthy diet plan for cardiovascular health.' },
          { label: 'Book Appointment', icon: Calendar, prompt: 'I want to book an appointment with a cardiologist.' },
          { label: 'Post-Treatment Care', icon: ShieldCheck, prompt: 'What are post-treatment guidelines for fever recovery?' },
        ].map((item, idx) => {
          const Icon = item.icon;
          return (
            <button
              key={idx}
              onClick={() => handleSend(item.prompt)}
              className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-xs font-semibold text-slate-300 hover:text-cyan-300 whitespace-nowrap flex items-center gap-1.5 transition-all"
            >
              <Icon className="w-3.5 h-3.5 text-cyan-400" />
              {item.label}
            </button>
          );
        })}
      </div>

      {/* Chat Messages Stream */}
      <div className="flex-1 overflow-y-auto space-y-3 py-3 pr-1 my-2">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start gap-2.5 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${
              msg.sender === 'user'
                ? 'bg-gradient-to-tr from-cyan-500 to-blue-600 text-slate-950 shadow-md'
                : 'bg-slate-800 border border-cyan-500/40 text-cyan-400 shadow-md'
            }`}>
              {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            <div className={`max-w-[80%] p-3.5 rounded-2xl text-xs leading-relaxed space-y-1 ${
              msg.sender === 'user'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-medium'
                : 'bg-slate-900 border border-slate-800 text-slate-100 shadow-lg'
            }`}>
              <p className="whitespace-pre-wrap">{msg.text}</p>
              <span className={`text-[9px] block text-right font-mono ${
                msg.sender === 'user' ? 'text-slate-900 font-semibold' : 'text-slate-500'
              }`}>
                {msg.timestamp}
              </span>
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-2 text-xs text-cyan-400 animate-pulse">
            <Bot className="w-4 h-4" />
            <span>{assistantName} is thinking...</span>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Input Field Bar */}
      <div className="pt-2">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2 p-2 rounded-2xl bg-slate-900 border border-cyan-500/30 shadow-xl"
        >
          <button
            type="button"
            onClick={toggleVoiceInput}
            className={`p-2.5 rounded-xl transition-all ${
              isListening
                ? 'bg-rose-500 text-white animate-pulse'
                : 'bg-slate-800 text-cyan-300 hover:bg-slate-700'
            }`}
            title="Voice Assistant Mic"
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask AI anything about your health or medicines..."
            className="flex-1 bg-transparent text-xs text-white placeholder-slate-500 focus:outline-none"
          />

          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="p-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold disabled:opacity-40 transition-all"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>

    </div>
  );
};
