import React, { useState, useEffect, useMemo } from 'react';
import { ScreenId } from '../../types';
import { 
  Sparkles, 
  Users, 
  Clock, 
  ShieldAlert, 
  Activity, 
  DollarSign, 
  Star, 
  TrendingUp, 
  Cpu, 
  Building2, 
  Calendar, 
  Filter, 
  RefreshCw, 
  Play, 
  Pause, 
  AlertTriangle, 
  ArrowDownRight, 
  CheckCircle2, 
  Sliders, 
  Download, 
  Zap, 
  ChevronRight, 
  Layers,
  HeartPulse
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  ComposedChart, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid, 
  ReferenceLine, 
  Legend, 
  Brush,
  Line
} from 'recharts';

interface AnalyticsScreenProps {
  setActiveScreen: (screen: ScreenId) => void;
}

type TimeHorizon = '24h' | '7d' | '30d';
type DepartmentFilter = 'All' | 'Emergency' | 'Cardiology' | 'Neurology' | 'Orthopedics' | 'Pediatrics';

// 24-Hour Detailed Time-Series Data
const INITIAL_HOURLY_DATA = [
  { time: '00:00', aiWait: 4, traditionalWait: 18, arrivals: 12, triageEmergency: 3, capacityLoad: 30 },
  { time: '02:00', aiWait: 3, traditionalWait: 15, arrivals: 8, triageEmergency: 2, capacityLoad: 25 },
  { time: '04:00', aiWait: 5, traditionalWait: 22, arrivals: 10, triageEmergency: 4, capacityLoad: 35 },
  { time: '06:00', aiWait: 7, traditionalWait: 28, arrivals: 22, triageEmergency: 5, capacityLoad: 50 },
  { time: '08:00', aiWait: 12, traditionalWait: 45, arrivals: 48, triageEmergency: 8, capacityLoad: 78 },
  { time: '10:00', aiWait: 16, traditionalWait: 62, arrivals: 65, triageEmergency: 12, capacityLoad: 92 },
  { time: '12:00', aiWait: 18, traditionalWait: 70, arrivals: 72, triageEmergency: 14, capacityLoad: 96 },
  { time: '14:00', aiWait: 14, traditionalWait: 58, arrivals: 58, triageEmergency: 10, capacityLoad: 84 },
  { time: '16:00', aiWait: 11, traditionalWait: 42, arrivals: 44, triageEmergency: 7, capacityLoad: 70 },
  { time: '18:00', aiWait: 9, traditionalWait: 35, arrivals: 36, triageEmergency: 6, capacityLoad: 60 },
  { time: '20:00', aiWait: 6, traditionalWait: 26, arrivals: 24, triageEmergency: 4, capacityLoad: 45 },
  { time: '22:00', aiWait: 5, traditionalWait: 20, arrivals: 16, triageEmergency: 3, capacityLoad: 35 },
];

// 7-Day Weekly Trend Data
const WEEKLY_DATA = [
  { time: 'Mon', aiWait: 11.2, traditionalWait: 48.5, arrivals: 380, triageEmergency: 28, capacityLoad: 82 },
  { time: 'Tue', aiWait: 12.8, traditionalWait: 52.0, arrivals: 410, triageEmergency: 32, capacityLoad: 88 },
  { time: 'Wed', aiWait: 10.5, traditionalWait: 44.2, arrivals: 360, triageEmergency: 24, capacityLoad: 78 },
  { time: 'Thu', aiWait: 13.4, traditionalWait: 56.8, arrivals: 435, triageEmergency: 35, capacityLoad: 91 },
  { time: 'Fri', aiWait: 15.1, traditionalWait: 64.0, arrivals: 482, triageEmergency: 41, capacityLoad: 95 },
  { time: 'Sat', aiWait: 8.4, traditionalWait: 32.1, arrivals: 290, triageEmergency: 18, capacityLoad: 62 },
  { time: 'Sun', aiWait: 7.2, traditionalWait: 28.5, arrivals: 240, triageEmergency: 15, capacityLoad: 55 },
];

// 30-Day Monthly Trend Data
const MONTHLY_DATA = Array.from({ length: 30 }, (_, i) => {
  const day = i + 1;
  const isWeekend = day % 7 === 6 || day % 7 === 0;
  const baseWait = isWeekend ? 8 : 12;
  const tradWait = isWeekend ? 30 : 54;
  return {
    time: `Day ${day}`,
    aiWait: parseFloat((baseWait + Math.sin(i) * 2.5).toFixed(1)),
    traditionalWait: parseFloat((tradWait + Math.cos(i) * 6).toFixed(1)),
    arrivals: Math.floor(320 + Math.sin(i) * 120),
    triageEmergency: Math.floor(20 + Math.cos(i) * 10),
    capacityLoad: Math.floor(70 + Math.sin(i) * 18),
  };
});

// Department Breakdown Data
const DEPARTMENT_ANALYTICS = [
  { dept: 'Emergency', activeQueue: 28, avgWait: 4.2, capacity: 40, status: 'Optimal', color: '#f43f5e' },
  { dept: 'Cardiology', activeQueue: 18, avgWait: 11.8, capacity: 25, status: 'Normal', color: '#00F2FE' },
  { dept: 'Neurology', activeQueue: 15, avgWait: 14.5, capacity: 20, status: 'Normal', color: '#6366f1' },
  { dept: 'Orthopedics', activeQueue: 19, avgWait: 16.2, capacity: 22, status: 'Busy', color: '#eab308' },
  { dept: 'Pediatrics', activeQueue: 21, avgWait: 9.6, capacity: 30, status: 'Normal', color: '#10b981' },
];

// Triage Severity Breakdown Data
const TRIAGE_SEVERITY_DATA = [
  { name: 'Level 1: Critical ER', value: 12, avgWait: 1.5, color: '#f43f5e' },
  { name: 'Level 2: Urgent', value: 28, avgWait: 6.8, color: '#f97316' },
  { name: 'Level 3: Standard', value: 45, avgWait: 14.2, color: '#00F2FE' },
  { name: 'Level 4: Routine', value: 15, avgWait: 21.0, color: '#10b981' },
];

export const AnalyticsScreen: React.FC<AnalyticsScreenProps> = () => {
  const [timeHorizon, setTimeHorizon] = useState<TimeHorizon>('24h');
  const [departmentFilter, setDepartmentFilter] = useState<DepartmentFilter>('All');
  const [isLiveTelemetry, setIsLiveTelemetry] = useState(false);
  const [liveData, setLiveData] = useState(INITIAL_HOURLY_DATA);
  const [doctorStaffing, setDoctorStaffing] = useState(14);
  const [surgeMultiplier, setSurgeMultiplier] = useState(1.0);
  const [selectedDeptDetail, setSelectedDeptDetail] = useState<string | null>('Emergency');

  // Simulated Live Telemetry Feed
  useEffect(() => {
    if (!isLiveTelemetry) return;

    const interval = setInterval(() => {
      setLiveData((prev) => {
        return prev.map((item, index) => {
          if (index === prev.length - 1 || index === Math.floor(prev.length / 2)) {
            const jitter = (Math.random() - 0.45) * 2;
            const newAiWait = Math.max(2, parseFloat((item.aiWait + jitter * 0.5).toFixed(1)));
            const newTradWait = Math.max(15, parseFloat((item.traditionalWait + jitter * 1.5).toFixed(1)));
            return {
              ...item,
              aiWait: newAiWait,
              traditionalWait: newTradWait,
              arrivals: Math.max(5, item.arrivals + Math.floor(jitter * 3)),
            };
          }
          return item;
        });
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [isLiveTelemetry]);

  // Choose Dataset based on time horizon
  const rawChartData = useMemo(() => {
    if (timeHorizon === '24h') return liveData;
    if (timeHorizon === '7d') return WEEKLY_DATA;
    return MONTHLY_DATA;
  }, [timeHorizon, liveData]);

  // Adjust chart data based on Department Filter & Simulator
  const processedChartData = useMemo(() => {
    const staffingFactor = 14 / doctorStaffing; // baseline 14 doctors
    
    return rawChartData.map((d) => {
      let deptMult = 1.0;
      if (departmentFilter === 'Emergency') deptMult = 0.4;
      else if (departmentFilter === 'Cardiology') deptMult = 0.9;
      else if (departmentFilter === 'Neurology') deptMult = 1.1;
      else if (departmentFilter === 'Orthopedics') deptMult = 1.25;
      else if (departmentFilter === 'Pediatrics') deptMult = 0.8;

      const simulatedAiWait = Math.max(1, parseFloat((d.aiWait * deptMult * staffingFactor * surgeMultiplier).toFixed(1)));
      const simulatedTradWait = Math.max(10, parseFloat((d.traditionalWait * deptMult * surgeMultiplier).toFixed(1)));

      return {
        ...d,
        aiWait: simulatedAiWait,
        traditionalWait: simulatedTradWait,
        timeSavedPct: Math.round(((simulatedTradWait - simulatedAiWait) / simulatedTradWait) * 100),
      };
    });
  }, [rawChartData, departmentFilter, doctorStaffing, surgeMultiplier]);

  // Dynamic KPI Calculations
  const metrics = useMemo(() => {
    const totalArrivals = processedChartData.reduce((acc, curr) => acc + curr.arrivals, 0);
    const avgAiWait = (processedChartData.reduce((acc, curr) => acc + curr.aiWait, 0) / processedChartData.length).toFixed(1);
    const avgTradWait = (processedChartData.reduce((acc, curr) => acc + curr.traditionalWait, 0) / processedChartData.length).toFixed(1);
    const maxWait = Math.max(...processedChartData.map((d) => d.aiWait));
    const totalSavedMins = processedChartData.reduce((acc, curr) => acc + (curr.traditionalWait - curr.aiWait) * curr.arrivals, 0);
    const slaMetCount = processedChartData.filter((d) => d.aiWait <= 15).length;
    const slaMetPct = Math.round((slaMetCount / processedChartData.length) * 100);

    return {
      totalArrivals,
      avgAiWait,
      avgTradWait,
      maxWait,
      totalSavedHours: Math.round(totalSavedMins / 60),
      slaMetPct,
    };
  }, [processedChartData]);

  return (
    <div className="min-h-full p-3 sm:p-6 text-white space-y-4 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 pb-24">
      
      {/* Top Header & Telemetry Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-cyan-500/20">
        <div>
          <div className="flex items-center gap-2 text-xs font-black text-cyan-400 uppercase tracking-widest">
            <Sparkles className="w-4 h-4 text-cyan-300 animate-pulse" /> Telemetry Intelligence Engine
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            Patient Waiting Trends & Analytics
          </h1>
        </div>

        {/* Live Telemetry Feed Toggle */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsLiveTelemetry(!isLiveTelemetry)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-2 transition-all shadow-lg ${
              isLiveTelemetry
                ? 'bg-emerald-950/80 border-emerald-400/60 text-emerald-300 shadow-emerald-500/20 animate-pulse'
                : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
            }`}
          >
            {isLiveTelemetry ? <Pause className="w-3.5 h-3.5 text-emerald-400" /> : <Play className="w-3.5 h-3.5 text-cyan-400" />}
            <span>{isLiveTelemetry ? 'Live Feed Streaming' : 'Start Live Telemetry'}</span>
            <span className={`w-2 h-2 rounded-full ${isLiveTelemetry ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`} />
          </button>

          <button
            onClick={() => {
              setLiveData([...INITIAL_HOURLY_DATA]);
              setDoctorStaffing(14);
              setSurgeMultiplier(1.0);
            }}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-400 hover:text-white transition-colors"
            title="Reset Filters & Simulation"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Interactive Controls Bar: Time Horizon & Department Filter */}
      <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 backdrop-blur-md shadow-lg">
        
        {/* Time Horizon Pills */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 font-bold px-2 uppercase tracking-wider flex items-center gap-1">
            <Calendar className="w-3 h-3 text-cyan-400" /> Range:
          </span>
          {(['24h', '7d', '30d'] as TimeHorizon[]).map((horizon) => (
            <button
              key={horizon}
              onClick={() => setTimeHorizon(horizon)}
              className={`px-3 py-1 rounded-lg text-xs font-black transition-all ${
                timeHorizon === horizon
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30 font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {horizon === '24h' ? '24 Hours' : horizon === '7d' ? '7 Days' : '30 Days'}
            </button>
          ))}
        </div>

        {/* Department Filter Selector */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-xs text-slate-300 font-bold bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-xl w-full sm:w-auto">
            <Filter className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-[11px] text-slate-400">Dept:</span>
            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value as DepartmentFilter)}
              className="bg-transparent text-xs font-bold text-cyan-300 focus:outline-none cursor-pointer pr-1"
            >
              <option value="All" className="bg-slate-900">All Departments</option>
              <option value="Emergency" className="bg-slate-900">Emergency (ER)</option>
              <option value="Cardiology" className="bg-slate-900">Cardiology</option>
              <option value="Neurology" className="bg-slate-900">Neurology</option>
              <option value="Orthopedics" className="bg-slate-900">Orthopedics</option>
              <option value="Pediatrics" className="bg-slate-900">Pediatrics</option>
            </select>
          </div>
        </div>

      </div>

      {/* Primary KPI Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        
        {/* KPI 1: AI Avg Wait Time */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-cyan-950/80 border border-cyan-500/40 shadow-xl space-y-1 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-cyan-500/10 rounded-full blur-xl pointer-events-none" />
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wide flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-cyan-400" /> MediFlow Avg Wait
          </span>
          <div className="text-2xl sm:text-3xl font-mono font-black text-cyan-300">
            {metrics.avgAiWait} <span className="text-xs font-normal text-slate-400">mins</span>
          </div>
          <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-bold">
            <ArrowDownRight className="w-3.5 h-3.5" />
            <span>vs Trad: {metrics.avgTradWait}m ({Math.round(((parseFloat(metrics.avgTradWait) - parseFloat(metrics.avgAiWait)) / parseFloat(metrics.avgTradWait)) * 100)}% faster)</span>
          </div>
        </div>

        {/* KPI 2: Patient Volume */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-blue-950/80 border border-blue-500/40 shadow-xl space-y-1 relative overflow-hidden">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wide flex items-center gap-1">
            <Users className="w-3.5 h-3.5 text-blue-400" /> Patient Arrivals
          </span>
          <div className="text-2xl sm:text-3xl font-mono font-black text-white">
            {metrics.totalArrivals.toLocaleString()}
          </div>
          <span className="text-[10px] text-cyan-300 font-semibold block">
            Peak Wait: {metrics.maxWait} mins
          </span>
        </div>

        {/* KPI 3: Total Hours Saved */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/80 border border-emerald-500/40 shadow-xl space-y-1 relative overflow-hidden">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wide flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 text-emerald-400" /> Patient Hours Saved
          </span>
          <div className="text-2xl sm:text-3xl font-mono font-black text-emerald-300">
            {metrics.totalSavedHours.toLocaleString()} <span className="text-xs font-normal text-slate-400">hrs</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-bold block flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Reduced ER Congestion
          </span>
        </div>

        {/* KPI 4: SLA Target Compliance */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/80 border border-indigo-500/40 shadow-xl space-y-1 relative overflow-hidden">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wide flex items-center gap-1">
            <ShieldAlert className="w-3.5 h-3.5 text-indigo-400" /> &lt;15m SLA Compliance
          </span>
          <div className="text-2xl sm:text-3xl font-mono font-black text-indigo-300">
            {metrics.slaMetPct}%
          </div>
          <span className="text-[10px] text-slate-400 font-medium block">
            Target SLA: 15 Mins Max
          </span>
        </div>

      </div>

      {/* Main Interactive Chart 1: Patient Waiting Trends Over Time (Composed Area + Line + Bar) */}
      <div className="p-4 rounded-3xl bg-slate-900/95 border border-slate-800 shadow-2xl space-y-3 relative">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
          <div>
            <h3 className="text-sm font-black text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" /> Patient Wait Times Over Time
            </h3>
            <p className="text-[11px] text-slate-400">
              Interactive time-series comparison between AI Smart Queue allocation vs Traditional Walk-in wait times.
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs font-bold">
            <div className="flex items-center gap-1.5 text-cyan-300">
              <div className="w-3 h-3 rounded bg-cyan-400 border border-cyan-200" />
              <span>MediFlow AI (mins)</span>
            </div>
            <div className="flex items-center gap-1.5 text-rose-400">
              <div className="w-3 h-0.5 bg-rose-500" />
              <span>Traditional Wait</span>
            </div>
            <div className="flex items-center gap-1.5 text-blue-400/60">
              <div className="w-2.5 h-2.5 bg-blue-600/40 rounded-sm" />
              <span>Queue Load</span>
            </div>
          </div>
        </div>

        {/* Recharts Composed Area & Line Chart with Brush Zoom */}
        <div className="h-64 sm:h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={processedChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="aiWaitGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00F2FE" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#00F2FE" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="arrivalsGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.05} />
                </linearGradient>
              </defs>

              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
              
              <XAxis 
                dataKey="time" 
                stroke="#64748b" 
                fontSize={11} 
                tickLine={false}
                axisLine={{ stroke: '#334155' }}
              />
              
              <YAxis 
                yAxisId="left"
                stroke="#64748b" 
                fontSize={11} 
                tickLine={false}
                axisLine={{ stroke: '#334155' }}
                unit="m"
              />

              <YAxis 
                yAxisId="right"
                orientation="right"
                stroke="#475569" 
                fontSize={10} 
                tickLine={false}
                axisLine={false}
                hide={true}
              />

              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="p-3 rounded-2xl bg-slate-950 border border-cyan-500/40 text-xs shadow-2xl space-y-1.5 backdrop-blur-md">
                        <div className="font-extrabold text-cyan-300 border-b border-slate-800 pb-1 flex items-center justify-between gap-4">
                          <span>Timeframe: {label}</span>
                          <span className="text-[10px] text-emerald-400 px-1.5 py-0.5 rounded bg-emerald-950 border border-emerald-500/30">
                            {data.timeSavedPct}% Time Saved
                          </span>
                        </div>

                        <div className="space-y-1 text-slate-200">
                          <div className="flex items-center justify-between gap-4">
                            <span className="text-cyan-400 font-bold">⚡ MediFlow AI Queue:</span>
                            <strong className="font-mono text-cyan-300 text-sm">{data.aiWait} mins</strong>
                          </div>

                          <div className="flex items-center justify-between gap-4">
                            <span className="text-rose-400">⏱️ Traditional Wait:</span>
                            <strong className="font-mono text-rose-300">{data.traditionalWait} mins</strong>
                          </div>

                          <div className="flex items-center justify-between gap-4 pt-1 border-t border-slate-800">
                            <span className="text-blue-400">👥 Patient Arrivals:</span>
                            <strong className="font-mono text-white">{data.arrivals} patients</strong>
                          </div>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />

              {/* 15 Minute Target SLA Line */}
              <ReferenceLine 
                yAxisId="left" 
                y={15} 
                stroke="#eab308" 
                strokeDasharray="4 4" 
                label={{ value: '15m Target SLA', fill: '#eab308', fontSize: 10, position: 'insideTopRight' }} 
              />

              {/* Patient Arrivals Bar */}
              <Bar 
                yAxisId="right"
                dataKey="arrivals" 
                fill="url(#arrivalsGradient)" 
                radius={[4, 4, 0, 0]} 
                maxBarSize={28}
              />

              {/* AI Smart Queue Area */}
              <Area 
                yAxisId="left"
                type="monotone" 
                dataKey="aiWait" 
                name="MediFlow AI Wait (mins)" 
                stroke="#00F2FE" 
                fill="url(#aiWaitGradient)" 
                strokeWidth={3}
                activeDot={{ r: 6, fill: '#00F2FE', stroke: '#ffffff', strokeWidth: 2 }}
              />

              {/* Traditional Walk-in Line */}
              <Line 
                yAxisId="left"
                type="monotone" 
                dataKey="traditionalWait" 
                name="Traditional Wait (mins)" 
                stroke="#f43f5e" 
                strokeWidth={2}
                strokeDasharray="5 5"
                dot={false}
              />

              <Brush 
                dataKey="time" 
                height={20} 
                stroke="#00F2FE" 
                fill="#0f172a" 
                tickFormatter={() => ''}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Row 2: Interactive Department Distribution & Triage Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Chart 2: Department Queue & Wait Comparison */}
        <div className="p-4 rounded-3xl bg-slate-900/95 border border-slate-800 shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <Building2 className="w-4 h-4 text-indigo-400" /> Department Queue & Wait Times
              </h3>
              <p className="text-[11px] text-slate-400">Click a department bar to inspect details</p>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              5 Medical Wings
            </span>
          </div>

          <div className="h-52 w-full pt-1">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart 
                data={DEPARTMENT_ANALYTICS}
                onClick={(e: any) => {
                  if (e && e.activePayload && e.activePayload[0]) {
                    setSelectedDeptDetail(e.activePayload[0].payload.dept);
                  }
                }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="dept" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} unit="m" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '11px' }}
                />
                <Bar dataKey="avgWait" name="Avg Wait (Mins)" radius={[6, 6, 0, 0]}>
                  {DEPARTMENT_ANALYTICS.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={selectedDeptDetail === entry.dept ? '#00F2FE' : entry.color} 
                      opacity={selectedDeptDetail && selectedDeptDetail !== entry.dept ? 0.4 : 1}
                      cursor="pointer"
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Department Detail Pill Banner */}
          {selectedDeptDetail && (
            <div className="p-2.5 rounded-2xl bg-slate-950 border border-cyan-500/30 text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
                <span className="font-extrabold text-white">{selectedDeptDetail} Department:</span>
                <span className="text-slate-400">
                  {DEPARTMENT_ANALYTICS.find((d) => d.dept === selectedDeptDetail)?.activeQueue} Active Patients in Queue
                </span>
              </div>
              <span className="text-cyan-300 font-mono font-bold">
                Avg Wait: {DEPARTMENT_ANALYTICS.find((d) => d.dept === selectedDeptDetail)?.avgWait}m
              </span>
            </div>
          )}
        </div>

        {/* Chart 3: Triage Severity Breakdown (Pie Chart + Donut Legend) */}
        <div className="p-4 rounded-3xl bg-slate-900/95 border border-slate-800 shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <HeartPulse className="w-4 h-4 text-rose-400" /> Patient Triage Severity Mix
              </h3>
              <p className="text-[11px] text-slate-400">Real-time breakdown by triage urgency level</p>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
              AI Priority Routing
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 items-center">
            {/* Pie Chart */}
            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={TRIAGE_SEVERITY_DATA}
                    cx="50%"
                    cy="50%"
                    innerRadius={42}
                    outerRadius={65}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {TRIAGE_SEVERITY_DATA.map((entry, index) => (
                      <Cell key={`pie-cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '11px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Triage Legend List */}
            <div className="space-y-1.5 text-xs">
              {TRIAGE_SEVERITY_DATA.map((item) => (
                <div key={item.name} className="p-2 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="font-bold text-slate-200">{item.name}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono text-cyan-300 font-bold block">{item.value}%</span>
                    <span className="text-[9px] text-slate-400">Avg {item.avgWait}m wait</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

      {/* Interactive Scenario Simulator / What-If Staffing Tool */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/90 border border-indigo-500/30 shadow-2xl space-y-3">
        <div className="flex items-center justify-between border-b border-indigo-500/20 pb-2">
          <div>
            <h3 className="text-sm font-black text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" /> Interactive Hospital Staffing & Surge Simulator
            </h3>
            <p className="text-[11px] text-slate-400">
              Adjust physician staffing or simulate emergency surge to preview wait time impact in real time.
            </p>
          </div>
          <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
            Predictive AI Modeling
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
          {/* Slider 1: Active Doctor Staffing */}
          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-cyan-400" /> Active Doctors On Duty:
              </span>
              <strong className="font-mono text-cyan-300 text-sm">{doctorStaffing} Physicians</strong>
            </div>
            <input
              type="range"
              min="6"
              max="24"
              step="1"
              value={doctorStaffing}
              onChange={(e) => setDoctorStaffing(Number(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>6 (Low Staffing)</span>
              <span>14 (Baseline)</span>
              <span>24 (Maximum)</span>
            </div>
          </div>

          {/* Slider 2: Patient Emergency Surge */}
          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" /> Emergency Surge Multiplier:
              </span>
              <strong className="font-mono text-amber-300 text-sm">{surgeMultiplier.toFixed(1)}x Inflow</strong>
            </div>
            <input
              type="range"
              min="0.5"
              max="2.5"
              step="0.1"
              value={surgeMultiplier}
              onChange={(e) => setSurgeMultiplier(Number(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>0.5x (Quiet)</span>
              <span>1.0x (Normal)</span>
              <span>2.5x (Severe Surge)</span>
            </div>
          </div>
        </div>

        {/* Simulation Output Banner */}
        <div className="p-3 rounded-2xl bg-slate-950 border border-cyan-500/30 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>Simulated AI Avg Wait: <strong className="font-mono text-cyan-300 text-sm">{metrics.avgAiWait} mins</strong></span>
          </div>
          <span className="text-[11px] text-slate-400">
            vs Traditional Unassisted: <span className="font-mono text-rose-400">{metrics.avgTradWait} mins</span>
          </span>
        </div>
      </div>

      {/* Financial & Operational Efficiency Footer */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-slate-950 border border-emerald-500/30 text-xs space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="font-extrabold text-emerald-300 flex items-center gap-1.5">
            <DollarSign className="w-4 h-4 text-emerald-400" /> Administrative & Economic ROI Summary
          </span>
          <button
            onClick={() => alert("Downloading MediFlow Telemetry Report (PDF/CSV)...")}
            className="px-3 py-1 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-[11px] font-bold flex items-center gap-1 transition-all"
          >
            <Download className="w-3.5 h-3.5" /> Export Report
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-300">
          <div className="p-2.5 rounded-2xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block">Monthly Operational Savings:</span>
            <strong className="text-emerald-400 font-mono text-base">$184,000 / month</strong>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 block">No-Show & Abandoned Queue Reduction:</span>
            <strong className="text-cyan-300 font-mono text-base">-84.2% Drop</strong>
          </div>
        </div>
      </div>

    </div>
  );
};
