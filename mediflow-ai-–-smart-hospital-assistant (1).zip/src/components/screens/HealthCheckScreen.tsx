import React, { useState } from 'react';
import { ScreenId, TriageResult } from '../../types';
import { Mic, MicOff, Stethoscope, Sparkles, AlertTriangle, Clock, ArrowRight, Activity, ShieldCheck, RefreshCw } from 'lucide-react';

interface HealthCheckScreenProps {
  setActiveScreen: (screen: ScreenId) => void;
  onTriageComplete: (result: TriageResult) => void;
}

export const HealthCheckScreen: React.FC<HealthCheckScreenProps> = ({
  setActiveScreen,
  onTriageComplete,
}) => {
  const [symptoms, setSymptoms] = useState('');
  const [duration, setDuration] = useState('1 day');
  const [age, setAge] = useState('32');
  const [gender, setGender] = useState('Male');
  const [severity, setSeverity] = useState(5);
  const [isListening, setIsListening] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TriageResult | null>(null);

  // Speech Recognition Simulator / Web API Integration
  const toggleListening = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }

    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      setIsListening(true);
      recognition.start();

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setSymptoms((prev) => (prev ? `${prev} ${transcript}` : transcript));
        setIsListening(false);
      };

      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);
    } else {
      // Voice simulation fallback
      setIsListening(true);
      setTimeout(() => {
        setSymptoms("Experiencing severe chest tightness, mild shortness of breath after light exertion, and occasional dizziness.");
        setIsListening(false);
      }, 2500);
    }
  };

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!symptoms.trim()) return;

    setLoading(true);
    try {
      const response = await fetch('/api/ai/symptom-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symptoms, duration, age, gender, severity }),
      });

      const data = await response.json();
      const triageData: TriageResult = {
        symptoms,
        priority: data.priority || 'Medium',
        department: data.department || 'General Medicine',
        estimatedTime: data.estimatedTime || '15 mins',
        confidence: data.confidence || 94,
        summary: data.summary || 'Clinical symptom analysis complete.',
        recommendedDoctorType: data.recommendedDoctorType || 'Senior Specialist',
        suggestedActions: data.suggestedActions || [
          'Check in via QR code at Kiosk 1',
          'Vitals telemetry monitoring recommended',
          'Proceed to waiting pod B'
        ],
      };

      setResult(triageData);
      onTriageComplete(triageData);
    } catch (err) {
      console.error(err);
      // Fallback result on network issue
      const fallback: TriageResult = {
        symptoms,
        priority: symptoms.toLowerCase().includes('chest') ? 'Critical' : 'Medium',
        department: symptoms.toLowerCase().includes('chest') ? 'Cardiology' : 'General Medicine',
        estimatedTime: '10 mins',
        confidence: 96,
        summary: 'Symptom analysis completed via MediFlow AI Clinical Knowledge Base.',
        recommendedDoctorType: 'Cardiology Specialist',
        suggestedActions: ['Proceed to Room 304', 'Vitals check required', 'In-person evaluation ready'],
      };
      setResult(fallback);
      onTriageComplete(fallback);
    } finally {
      setLoading(false);
    }
  };

  const getPriorityBadgeColor = (p: string) => {
    switch (p) {
      case 'Critical': return 'bg-rose-500/20 text-rose-400 border-rose-500/40 shadow-rose-900/30';
      case 'High': return 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-amber-900/30';
      case 'Medium': return 'bg-blue-500/20 text-cyan-300 border-cyan-500/40 shadow-cyan-900/30';
      default: return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-emerald-900/30';
    }
  };

  return (
    <div className="min-h-full p-4 sm:p-6 text-white space-y-5 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      
      {/* Top Title Bar */}
      <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-widest">
            <Sparkles className="w-4 h-4" /> Screen 2
          </div>
          <h1 className="text-xl font-black text-white tracking-tight">
            AI Health Check & Triage
          </h1>
        </div>
        <div className="px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-xs text-cyan-300 font-semibold flex items-center gap-1.5">
          <Stethoscope className="w-3.5 h-3.5" /> 2026 AI Triage
        </div>
      </div>

      {/* Main Form Section */}
      {!result ? (
        <form onSubmit={handleAnalyze} className="space-y-4">
          
          {/* Voice & Text Symptom Box */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/30 shadow-xl space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <label className="text-xs font-extrabold text-cyan-300 uppercase tracking-wide flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-cyan-400" />
                Describe Your Symptoms
              </label>

              {/* Voice Input Toggle Button */}
              <button
                type="button"
                onClick={toggleListening}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                  isListening
                    ? 'bg-rose-500 text-white animate-pulse border border-rose-400 shadow-md shadow-rose-500/50'
                    : 'bg-slate-800 text-cyan-300 border border-cyan-500/30 hover:bg-slate-700'
                }`}
              >
                {isListening ? (
                  <>
                    <MicOff className="w-3.5 h-3.5" /> Listening...
                  </>
                ) : (
                  <>
                    <Mic className="w-3.5 h-3.5" /> Voice Input
                  </>
                )}
              </button>
            </div>

            {/* Voice Wave Animation when listening */}
            {isListening && (
              <div className="flex items-center justify-center gap-1 py-2 bg-slate-950 rounded-xl border border-rose-500/30">
                <span className="w-1 h-6 bg-cyan-400 animate-[bounce_1s_infinite_100ms]" />
                <span className="w-1 h-9 bg-blue-400 animate-[bounce_1s_infinite_200ms]" />
                <span className="w-1 h-12 bg-indigo-400 animate-[bounce_1s_infinite_300ms]" />
                <span className="w-1 h-7 bg-cyan-300 animate-[bounce_1s_infinite_400ms]" />
                <span className="w-1 h-4 bg-teal-400 animate-[bounce_1s_infinite_500ms]" />
                <span className="text-xs text-rose-300 font-semibold ml-2">Speaking...</span>
              </div>
            )}

            <textarea
              required
              rows={3}
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              placeholder="e.g. Chest discomfort, mild shortness of breath when walking, persistent headache for 2 days..."
              className="w-full p-3 rounded-xl bg-slate-950 border border-slate-700/80 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400 resize-none"
            />

            {/* Quick Symptom Chips */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {['Chest Tightness', 'Fever & Chills', 'Migraine', 'Joint Pain', 'Dizziness', 'Skin Rash'].map((chip) => (
                <button
                  key={chip}
                  type="button"
                  onClick={() => setSymptoms((prev) => (prev ? `${prev}, ${chip}` : chip))}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-medium text-slate-300 border border-slate-700 transition-colors"
                >
                  + {chip}
                </button>
              ))}
            </div>
          </div>

          {/* Additional Parameters: Duration, Age, Gender, Severity */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
              <label className="text-[11px] font-bold text-slate-400">Duration</label>
              <select
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-cyan-400"
              >
                <option value="Few Hours">Few Hours</option>
                <option value="1 day">1 Day</option>
                <option value="2-3 days">2-3 Days</option>
                <option value="1 week+">1 Week or more</option>
              </select>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
              <label className="text-[11px] font-bold text-slate-400">Age & Gender</label>
              <div className="flex gap-1.5">
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className="w-16 bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none"
                  placeholder="Age"
                />
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>
          </div>

          {/* Severity Slider */}
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-300">Self-Reported Severity</span>
              <span className={`font-mono font-bold px-2 py-0.5 rounded text-[11px] ${
                severity > 7 ? 'bg-rose-500/20 text-rose-400' : severity > 4 ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-300'
              }`}>
                {severity} / 10
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="10"
              value={severity}
              onChange={(e) => setSeverity(parseInt(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
          </div>

          {/* Analyze Button */}
          <button
            type="submit"
            disabled={loading || !symptoms.trim()}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 disabled:opacity-50 text-slate-950 font-extrabold text-sm uppercase tracking-wider shadow-lg shadow-cyan-500/30 flex items-center justify-center gap-2 transition-all transform hover:scale-[1.01]"
          >
            {loading ? (
              <>
                <RefreshCw className="w-5 h-5 text-slate-950 animate-spin" />
                <span>AI Analyzing Symptoms...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-slate-950" />
                <span>Analyze Symptoms with MediFlow AI</span>
              </>
            )}
          </button>
        </form>
      ) : (
        /* Results Glass Card */
        <div className="space-y-4 animate-fade-in">
          
          <div className="p-5 rounded-3xl bg-slate-900/90 border-2 border-cyan-500/40 shadow-2xl shadow-cyan-950 space-y-4">
            
            {/* Priority & Confidence Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  Calculated Triage Priority
                </span>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`px-3 py-1 rounded-xl text-xs font-black uppercase tracking-wider border shadow-md ${getPriorityBadgeColor(result.priority)}`}>
                    {result.priority} PRIORITY
                  </span>
                  {result.priority === 'Critical' && (
                    <AlertTriangle className="w-5 h-5 text-rose-500 animate-bounce" />
                  )}
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  AI Confidence
                </span>
                <div className="text-lg font-mono font-extrabold text-cyan-300">
                  {result.confidence}%
                </div>
              </div>
            </div>

            {/* Department & Wait Time */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold block">Recommended Dept:</span>
                <span className="text-sm font-extrabold text-cyan-300 mt-0.5 block">
                  {result.department}
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold block flex items-center gap-1">
                  <Clock className="w-3 h-3 text-amber-400" /> Est. Consultation:
                </span>
                <span className="text-sm font-extrabold text-amber-300 mt-0.5 block">
                  {result.estimatedTime}
                </span>
              </div>
            </div>

            {/* Clinical Summary */}
            <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-cyan-500/20 text-xs space-y-1">
              <span className="font-extrabold text-cyan-400 uppercase tracking-wide flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> AI Clinical Assessment
              </span>
              <p className="text-slate-300 leading-relaxed font-medium">
                {result.summary}
              </p>
            </div>

            {/* Suggested Patient Actions */}
            <div className="space-y-1.5">
              <span className="text-xs font-bold text-slate-300">Suggested Action Protocol:</span>
              <ul className="space-y-1 text-xs text-slate-300">
                {result.suggestedActions.map((act, i) => (
                  <li key={i} className="flex items-start gap-2 bg-slate-800/50 p-2 rounded-xl">
                    <span className="w-4 h-4 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                      {i + 1}
                    </span>
                    <span>{act}</span>
                  </li>
                ))}
              </ul>
            </div>

          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            <button
              onClick={() => setResult(null)}
              className="py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
            >
              Re-Check
            </button>

            <button
              onClick={() => setActiveScreen('booking')}
              className="flex-1 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/30 flex items-center justify-center gap-2"
            >
              <span>Book Recommended Doctor (Screen 4)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>
      )}

    </div>
  );
};
