import React, { useState, useEffect } from 'react';
import { AppNotification, ScreenId, NotificationType } from '../types';
import { notificationService } from '../services/notificationService';
import { 
  Bell, 
  X, 
  Check, 
  Trash2, 
  Zap, 
  Calendar, 
  AlertTriangle, 
  Sparkles, 
  Play, 
  Pause, 
  ChevronRight, 
  Clock, 
  Smartphone, 
  Volume2, 
  CheckCheck,
  RefreshCw
} from 'lucide-react';

interface NotificationCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  setActiveScreen: (screen: ScreenId) => void;
}

export const NotificationCenterModal: React.FC<NotificationCenterModalProps> = ({
  isOpen,
  onClose,
  setActiveScreen,
}) => {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [filter, setFilter] = useState<'all' | NotificationType>('all');
  const [isDaemonActive, setIsDaemonActive] = useState(false);
  const [browserPermission, setBrowserPermission] = useState<string>('default');

  useEffect(() => {
    const unsub = notificationService.subscribe((list) => {
      setNotifications(list);
    });
    setIsDaemonActive(notificationService.isPushDaemonRunning());

    if (typeof window !== 'undefined' && 'Notification' in window) {
      setBrowserPermission(Notification.permission);
    }

    return () => unsub();
  }, []);

  if (!isOpen) return null;

  const filteredNotifications = notifications.filter((n) => {
    if (filter === 'all') return true;
    return n.type === filter;
  });

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleRequestPermission = async () => {
    const perm = await notificationService.requestBrowserPushPermission();
    setBrowserPermission(perm);
  };

  const handleToggleDaemon = () => {
    if (isDaemonActive) {
      notificationService.stopMockPushDaemon();
      setIsDaemonActive(false);
    } else {
      notificationService.startMockPushDaemon();
      setIsDaemonActive(true);
    }
  };

  const handleNotificationClick = (notif: AppNotification) => {
    notificationService.markAsRead(notif.id);
    if (notif.actionScreen) {
      setActiveScreen(notif.actionScreen);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      
      {/* Drawer / Modal Container */}
      <div className="w-full max-w-lg rounded-3xl bg-slate-900 border-2 border-cyan-500/40 text-white shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-cyan-500/20 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 relative">
              <Bell className="w-5 h-5 text-cyan-400" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-black flex items-center justify-center animate-pulse">
                  {unreadCount}
                </span>
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white tracking-tight">Push Notification Center</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
                  Real-Time Mock Handler
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {unreadCount} unread alerts • Live queue & appointment updates
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Controls: Web Push & Mock Daemon */}
        <div className="p-3 bg-slate-950/90 border-b border-slate-800 space-y-2">
          
          {/* Web Push Permission Banner */}
          <div className="flex items-center justify-between p-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              <div>
                <span className="font-bold text-slate-200 block">Desktop/Mobile Web Push:</span>
                <span className="text-[10px] text-slate-400">
                  Status: {browserPermission === 'granted' ? 'Enabled (Active)' : browserPermission === 'denied' ? 'Blocked in Browser' : 'Click to Enable'}
                </span>
              </div>
            </div>

            {browserPermission !== 'granted' && (
              <button
                onClick={handleRequestPermission}
                className="px-3 py-1 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-[10px] font-black uppercase tracking-wider transition-all"
              >
                Enable Push
              </button>
            )}
          </div>

          {/* Background Auto Simulation Daemon */}
          <div className="flex items-center justify-between p-2.5 rounded-2xl bg-gradient-to-r from-indigo-950/80 to-slate-900 border border-indigo-500/30 text-xs">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <div>
                <span className="font-bold text-white block">Auto Push Simulator Daemon</span>
                <span className="text-[10px] text-slate-400">Fires realistic push alerts every 25 seconds</span>
              </div>
            </div>

            <button
              onClick={handleToggleDaemon}
              className={`px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-md ${
                isDaemonActive
                  ? 'bg-rose-500 hover:bg-rose-400 text-white shadow-rose-500/30'
                  : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/30'
              }`}
            >
              {isDaemonActive ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              <span>{isDaemonActive ? 'Stop Auto Push' : 'Start Auto Push'}</span>
            </button>
          </div>

        </div>

        {/* Simulation Trigger Bar (Instant Push Testers) */}
        <div className="p-3 bg-slate-900 border-b border-slate-800 space-y-1.5">
          <span className="text-[10px] font-black text-cyan-400 uppercase tracking-widest block">
            ⚡ Instant Push Simulation Testers:
          </span>

          <div className="grid grid-cols-2 gap-1.5 text-xs">
            {/* Trigger 1: Queue Status Advance */}
            <button
              onClick={() => notificationService.triggerQueueUpdate('A-104', 2, 'Dr. Sarah Vance', 'Room 304')}
              className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-cyan-500/30 text-cyan-300 text-[11px] font-bold text-left flex items-center gap-1.5 transition-all"
            >
              <Zap className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="truncate">Queue Move (#2 in Line)</span>
            </button>

            {/* Trigger 2: Next in Line / Ready */}
            <button
              onClick={() => notificationService.triggerQueueUpdate('A-104', 0, 'Dr. Sarah Vance', 'Room 304')}
              className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-emerald-500/30 text-emerald-300 text-[11px] font-bold text-left flex items-center gap-1.5 transition-all"
            >
              <CheckCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="truncate">Doctor Ready (Room 304)</span>
            </button>

            {/* Trigger 3: Appointment Approaching */}
            <button
              onClick={() => notificationService.triggerAppointmentApproaching('Dr. Marcus Thorne', 'Room 102', '10 mins')}
              className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-amber-500/30 text-amber-300 text-[11px] font-bold text-left flex items-center gap-1.5 transition-all"
            >
              <Calendar className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="truncate">Apt Starts in 10 mins</span>
            </button>

            {/* Trigger 4: Emergency Triage Alert */}
            <button
              onClick={() => notificationService.triggerTriageAlert('urgent', 'Cardiology')}
              className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-rose-500/30 text-rose-300 text-[11px] font-bold text-left flex items-center gap-1.5 transition-all"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
              <span className="truncate">Triage Priority Alert</span>
            </button>
          </div>
        </div>

        {/* Filter Tabs & Bulk Actions */}
        <div className="p-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1">
            {(['all', 'queue_update', 'appointment_reminder', 'triage_alert'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setFilter(t)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                  filter === t
                    ? 'bg-cyan-500 text-slate-950 font-black'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                {t === 'all' ? 'All' : t === 'queue_update' ? 'Queue' : t === 'appointment_reminder' ? 'Appointments' : 'Triage'}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => notificationService.markAllAsRead()}
              className="text-[10px] text-cyan-400 hover:underline font-bold"
              title="Mark all as read"
            >
              Mark All Read
            </button>
            <span className="text-slate-700">•</span>
            <button
              onClick={() => notificationService.clearAll()}
              className="text-[10px] text-rose-400 hover:underline font-bold"
              title="Clear notification list"
            >
              Clear All
            </button>
          </div>
        </div>

        {/* Notification Scrollable List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {filteredNotifications.length === 0 ? (
            <div className="py-12 text-center text-slate-500 space-y-2">
              <Bell className="w-8 h-8 text-slate-600 mx-auto" />
              <p className="text-xs font-semibold">No push notifications found</p>
              <p className="text-[11px] text-slate-600">Use the buttons above to test live push alerts!</p>
            </div>
          ) : (
            filteredNotifications.map((notif) => (
              <div
                key={notif.id}
                onClick={() => handleNotificationClick(notif)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer relative ${
                  !notif.read
                    ? 'bg-slate-950 border-cyan-500/50 hover:border-cyan-400 shadow-lg shadow-cyan-500/10'
                    : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900 text-slate-400'
                }`}
              >
                {!notif.read && (
                  <span className="absolute top-3 right-3 w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
                )}

                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-xl shrink-0 border ${
                    notif.type === 'queue_update' 
                      ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300' 
                      : notif.type === 'appointment_reminder'
                      ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                      : 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                  }`}>
                    {notif.type === 'queue_update' ? <Zap className="w-4 h-4" /> : notif.type === 'appointment_reminder' ? <Calendar className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                  </div>

                  <div className="flex-1 space-y-1 pr-4">
                    <div className="flex items-center gap-2">
                      <h4 className={`text-xs font-black ${!notif.read ? 'text-white' : 'text-slate-300'}`}>
                        {notif.title}
                      </h4>
                      <span className="text-[10px] text-slate-500 font-mono">{notif.timestamp}</span>
                    </div>

                    <p className="text-[11px] text-slate-300 leading-snug">
                      {notif.message}
                    </p>

                    {notif.metadata && (
                      <div className="pt-1 flex flex-wrap gap-2 text-[10px] text-slate-400">
                        {notif.metadata.doctorName && (
                          <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-cyan-300 font-bold">
                            👨‍⚕️ {notif.metadata.doctorName}
                          </span>
                        )}
                        {notif.metadata.roomNumber && (
                          <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300 font-bold">
                            🚪 {notif.metadata.roomNumber}
                          </span>
                        )}
                        {notif.metadata.tokenNumber && (
                          <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-amber-300 font-bold">
                            🎟️ Token #{notif.metadata.tokenNumber}
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  <ChevronRight className="w-4 h-4 text-slate-600 self-center shrink-0" />
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 text-center text-[10px] text-slate-500">
          MediFlow AI Push Handler • Real-time queue telemetry & appointment synchronization
        </div>

      </div>
    </div>
  );
};
