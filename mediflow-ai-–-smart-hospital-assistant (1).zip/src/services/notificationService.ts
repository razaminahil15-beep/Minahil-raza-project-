import { AppNotification, ScreenId, NotificationType, NotificationPriority } from '../types';

type NotificationListener = (notifications: AppNotification[], latestPush?: AppNotification) => void;

// Initial mock notifications seed data
const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif-101',
    title: '⚡ Queue Advance Alert',
    message: 'Your token #A-104 is now #2 in line for Dr. Sarah Vance (Room 304). Est wait: 11 mins.',
    type: 'queue_update',
    timestamp: 'Just now',
    read: false,
    actionScreen: 'queueTracker',
    priority: 'high',
    metadata: {
      tokenNumber: 'A-104',
      position: 2,
      doctorName: 'Dr. Sarah Vance',
      roomNumber: 'Room 304',
    }
  },
  {
    id: 'notif-102',
    title: '📅 Appointment Approaching',
    message: 'Upcoming consultation with Dr. Marcus Thorne starts in 15 minutes (Room 102).',
    type: 'appointment_reminder',
    timestamp: '10 mins ago',
    read: false,
    actionScreen: 'booking',
    priority: 'medium',
    metadata: {
      doctorName: 'Dr. Marcus Thorne',
      roomNumber: 'Room 102',
      timeUntil: '15 mins'
    }
  },
  {
    id: 'notif-103',
    title: '🩺 AI Triage Priority Assigned',
    message: 'Level 2 Urgent status verified for Cardiology wing. Priority queue routing enabled.',
    type: 'triage_alert',
    timestamp: '25 mins ago',
    read: true,
    actionScreen: 'healthCheck',
    priority: 'urgent',
    metadata: {
      department: 'Cardiology'
    }
  }
];

class NotificationService {
  private notifications: AppNotification[] = [...INITIAL_NOTIFICATIONS];
  private listeners: Set<NotificationListener> = new Set();
  private autoSimInterval: any = null;

  constructor() {
    // Attempt to register browser push permission if already granted
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'granted') {
        console.log('Browser Push Notifications are enabled.');
      }
    }
  }

  public getNotifications(): AppNotification[] {
    return [...this.notifications];
  }

  public getUnreadCount(): number {
    return this.notifications.filter((n) => !n.read).length;
  }

  public subscribe(listener: NotificationListener): () => void {
    this.listeners.add(listener);
    // Initial emission
    listener(this.getNotifications());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(latestPush?: AppNotification) {
    const list = this.getNotifications();
    this.listeners.forEach((listener) => listener(list, latestPush));
  }

  // Request native web push notification permissions
  public async requestBrowserPushPermission(): Promise<'granted' | 'denied' | 'default'> {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
          this.pushNativeBrowserNotification(
            '🔔 MediFlow Push Enabled',
            'You will now receive real-time queue status changes & appointment reminders on your desktop!'
          );
        }
        return permission;
      } catch (err) {
        console.error('Error requesting push permission:', err);
      }
    }
    return 'default';
  }

  // Native Web Browser Notification Trigger
  private pushNativeBrowserNotification(title: string, body: string) {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body,
          icon: '/favicon.ico',
        });
      } catch (e) {
        console.warn('Native notification failed:', e);
      }
    }
  }

  // Play audio ping for incoming push notification
  private playNotificationAudio() {
    try {
      if ('speechSynthesis' in window && window.speechSynthesis) {
        // Optional subtle chime or web audio pulse
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
        osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.15); // A5
        gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.3);
      }
    } catch (e) {
      // Audio context silenced or blocked
    }
  }

  // Add new notification and emit push
  public addNotification(payload: {
    title: string;
    message: string;
    type: NotificationType;
    actionScreen?: ScreenId;
    priority?: NotificationPriority;
    metadata?: AppNotification['metadata'];
  }): AppNotification {
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      title: payload.title,
      message: payload.message,
      type: payload.type,
      timestamp: 'Just now',
      read: false,
      actionScreen: payload.actionScreen || 'queueTracker',
      priority: payload.priority || 'medium',
      metadata: payload.metadata,
    };

    this.notifications = [newNotif, ...this.notifications];
    this.playNotificationAudio();
    this.pushNativeBrowserNotification(newNotif.title, newNotif.message);
    this.notify(newNotif);
    return newNotif;
  }

  public markAsRead(id: string) {
    this.notifications = this.notifications.map((n) =>
      n.id === id ? { ...n, read: true } : n
    );
    this.notify();
  }

  public markAllAsRead() {
    this.notifications = this.notifications.map((n) => ({ ...n, read: true }));
    this.notify();
  }

  public clearNotification(id: string) {
    this.notifications = this.notifications.filter((n) => n.id !== id);
    this.notify();
  }

  public clearAll() {
    this.notifications = [];
    this.notify();
  }

  // === SPECIFIC MOCK SERVICE HANDLERS ===

  // 1. Queue Status Push Notification Handler
  public triggerQueueUpdate(
    tokenNumber: string = 'A-104',
    position: number = 1,
    doctorName: string = 'Dr. Sarah Vance',
    roomNumber: string = 'Room 304'
  ) {
    let title = '⚡ Queue Status Changed';
    let message = `Token #${tokenNumber}: You advanced to #${position} in line for ${doctorName} (${roomNumber}).`;
    let priority: NotificationPriority = 'high';

    if (position === 1) {
      title = '🚨 NEXT IN LINE - Queue Alert';
      message = `Token #${tokenNumber}: You are NEXT in line! Please proceed to Waiting Pod B outside ${roomNumber}.`;
      priority = 'urgent';
    } else if (position === 0) {
      title = '🩺 Consultation Ready!';
      message = `Token #${tokenNumber}: ${doctorName} is ready for you now in ${roomNumber}. Please enter.`;
      priority = 'urgent';
    }

    return this.addNotification({
      title,
      message,
      type: 'queue_update',
      actionScreen: 'queueTracker',
      priority,
      metadata: {
        tokenNumber,
        position,
        doctorName,
        roomNumber
      }
    });
  }

  // 2. Appointment Approaching Push Notification Handler
  public triggerAppointmentApproaching(
    doctorName: string = 'Dr. Sarah Vance',
    roomNumber: string = 'Room 304',
    timeUntil: string = '10 mins'
  ) {
    return this.addNotification({
      title: '📅 Appointment Approaching',
      message: `Your appointment with ${doctorName} starts in ${timeUntil} (${roomNumber}). Tap to view your digital ticket.`,
      type: 'appointment_reminder',
      actionScreen: 'booking',
      priority: 'high',
      metadata: {
        doctorName,
        roomNumber,
        timeUntil
      }
    });
  }

  // 3. Emergency Triage Push Notification Handler
  public triggerTriageAlert(
    priority: NotificationPriority = 'urgent',
    department: string = 'Cardiology'
  ) {
    return this.addNotification({
      title: '🩺 AI Triage Status Updated',
      message: `AI symptom check completed for ${department}. Priority status level: ${priority.toUpperCase()}. Priority routing activated.`,
      type: 'triage_alert',
      actionScreen: 'healthCheck',
      priority,
      metadata: {
        department
      }
    });
  }

  // 4. System Notification
  public triggerSystemNotification(title: string, message: string) {
    return this.addNotification({
      title,
      message,
      type: 'system',
      actionScreen: 'dashboard',
      priority: 'low'
    });
  }

  // Background Auto-Simulation Handler (Mock push daemon)
  public startMockPushDaemon() {
    if (this.autoSimInterval) return;

    let step = 0;
    this.autoSimInterval = setInterval(() => {
      step++;
      if (step === 1) {
        this.triggerQueueUpdate('A-104', 2, 'Dr. Sarah Vance', 'Room 304');
      } else if (step === 2) {
        this.triggerAppointmentApproaching('Dr. Marcus Thorne', 'Room 102', '10 mins');
      } else if (step === 3) {
        this.triggerQueueUpdate('A-104', 1, 'Dr. Sarah Vance', 'Room 304');
      } else if (step === 4) {
        this.triggerTriageAlert('high', 'Emergency Care');
      } else if (step === 5) {
        this.triggerQueueUpdate('A-104', 0, 'Dr. Sarah Vance', 'Room 304');
        step = 0; // reset loop
      }
    }, 25000); // Trigger mock push every 25 seconds
  }

  public stopMockPushDaemon() {
    if (this.autoSimInterval) {
      clearInterval(this.autoSimInterval);
      this.autoSimInterval = null;
    }
  }

  public isPushDaemonRunning(): boolean {
    return this.autoSimInterval !== null;
  }
}

export const notificationService = new NotificationService();
