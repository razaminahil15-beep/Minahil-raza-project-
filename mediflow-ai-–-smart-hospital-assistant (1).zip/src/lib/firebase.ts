import { initializeApp, getApps, getApp } from "firebase/app";
import { 
  getFirestore, 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  onSnapshot,
  Firestore
} from "firebase/firestore";
import { 
  getAuth, 
  signInAnonymously, 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
  onAuthStateChanged, 
  User as FirebaseUser,
  signOut,
  GoogleAuthProvider,
  signInWithPopup
} from "firebase/auth";
import firebaseConfig from "../../firebase-applet-config.json";

// Initialize Firebase App
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore with custom database ID if specified in config
export const db: Firestore = firebaseConfig.firestoreDatabaseId 
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

export const auth = getAuth(app);

/**
 * Ensures user is authenticated if possible. Gracefully resolves with current user or null if anonymous auth is disabled.
 */
export const ensureAuthenticatedUser = (): Promise<FirebaseUser | null> => {
  if (auth.currentUser) {
    return Promise.resolve(auth.currentUser);
  }

  return new Promise((resolve) => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        unsubscribe();
        resolve(currentUser);
      } else {
        try {
          const userCred = await signInAnonymously(auth);
          unsubscribe();
          resolve(userCred.user);
        } catch (error: any) {
          unsubscribe();
          if (error?.code !== 'auth/admin-restricted-operation') {
            console.warn("Anonymous sign-in not available or failed:", error?.message || error);
          }
          resolve(null);
        }
      }
    });
  });
};

/**
 * Standard error handler for Firestore & Auth operations
 */
export function handleFirestoreError(error: unknown, contextMessage: string) {
  const errObj = error as { code?: string; message?: string };
  
  // Auth credential failures are expected user validation messages, handle gracefully
  if (errObj?.code?.startsWith('auth/')) {
    console.warn(`Firebase Auth Note [${contextMessage}]: ${errObj.code} - ${errObj.message || 'Authentication error'}`);
    return;
  }

  console.error(`Firebase Error [${contextMessage}]:`, error);
  if (errObj?.code === 'permission-denied') {
    console.warn("Firestore Permission Denied. Ensure user is authenticated and rules permit operation.");
  }
}

export { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  onSnapshot,
  signInAnonymously,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
  onAuthStateChanged,
  signOut,
  GoogleAuthProvider,
  signInWithPopup
};
